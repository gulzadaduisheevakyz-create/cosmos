import React, { useState } from 'react';
import { FileSpreadsheet, Download, Upload, CheckCircle2, AlertCircle, FileCheck } from 'lucide-react';
import { Employee } from '../types';
import { db } from '../services/db';
import { exportEmployeesToExcel, parseEmployeesFromExcel } from '../services/excel';

interface ExcelImportExportViewProps {
  employees: Employee[];
  onRefresh: () => void;
}

export const ExcelImportExportView: React.FC<ExcelImportExportViewProps> = ({
  employees,
  onRefresh,
}) => {
  const [importStatus, setImportStatus] = useState<{
    type: 'success' | 'error' | 'loading' | null;
    message: string;
  }>({ type: null, message: '' });

  const handleExport = () => {
    try {
      exportEmployeesToExcel(employees);
    } catch (err: unknown) {
      alert((err as Error).message);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportStatus({ type: 'loading', message: `Reading and parsing "${file.name}"...` });

    try {
      const result = await parseEmployeesFromExcel(file);
      let imported = 0;
      let updated = 0;

      for (const emp of result.employees) {
        const existing = db.getEmployee(emp.employeeId);
        if (existing) {
          await db.saveEmployee({ ...existing, ...emp });
          updated++;
        } else {
          await db.saveEmployee(emp);
          imported++;
        }
      }

      await db.logAudit(
        'EXCEL_IMPORTED',
        `Imported ${imported} new, updated ${updated} employees from Excel file ${file.name}`
      );

      setImportStatus({
        type: 'success',
        message: `Successfully processed Excel file! Added ${imported} new employee(s) and updated ${updated} existing record(s).`,
      });
      onRefresh();
    } catch (err: unknown) {
      console.error(err);
      setImportStatus({
        type: 'error',
        message: `Failed to import Excel file: ${(err as Error).message || 'Invalid sheet format'}`,
      });
    }

    // Reset input
    e.target.value = '';
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
        <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
          <span>Excel Import &amp; Export Center</span>
        </h2>
        <p className="text-xs text-slate-500 mt-0.5">
          Synchronize employee master data, contract dates, salary packages, and compliance data with Microsoft Excel (.xlsx).
        </p>
      </div>

      {/* Export Section */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
          <Download className="w-4 h-4 text-emerald-600" />
          <span>Export Master Employee Records to Excel</span>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed">
          Download all employee profiles formatted with the exact salon columns: No, Employer ID, Company, Duty, Accommodation, Contract No, Employee ID, Joining Date, End Contract (+2 years), Passport Expiry, QID Expiry, Qatar Payer Bank, IBAN, Basic Salary, Allowances, Sales Commissions, and Status.
        </p>

        <div className="pt-2">
          <button
            onClick={handleExport}
            className="px-4 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors flex items-center gap-2 shadow-xs"
          >
            <Download className="w-4 h-4" />
            <span>Download All ({employees.length}) Employees (.xlsx)</span>
          </button>
        </div>
      </div>

      {/* Import Section */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
          <Upload className="w-4 h-4 text-blue-600" />
          <span>Import / Update Employees from Excel Sheet</span>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed">
          Upload an Excel file (.xlsx or .xls) to batch register or update employees. The system matches existing records by <strong>Employee ID</strong>, automatically calculating remaining passport and residency days, total salary packages, and contract dates.
        </p>

        {/* Drag & Drop Upload Zone */}
        <label className="border-2 border-dashed border-slate-200 hover:border-blue-500 bg-slate-50 hover:bg-blue-50/40 rounded-xl p-8 flex flex-col items-center justify-center cursor-pointer transition-all group">
          <input
            type="file"
            accept=".xlsx, .xls"
            onChange={handleFileUpload}
            className="hidden"
          />
          <div className="w-12 h-12 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
            <Upload className="w-6 h-6" />
          </div>
          <span className="text-sm font-bold text-slate-800">
            Click to Select or Drop Excel File Here
          </span>
          <span className="text-xs text-slate-400 mt-1">
            Supports Microsoft Excel (.xlsx, .xls) spreadsheets
          </span>
        </label>

        {/* Status Message */}
        {importStatus.type && (
          <div
            className={`p-3.5 rounded-lg border text-xs flex items-center gap-2.5 ${
              importStatus.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                : importStatus.type === 'error'
                ? 'bg-rose-50 text-rose-800 border-rose-200'
                : 'bg-blue-50 text-blue-800 border-blue-200'
            }`}
          >
            {importStatus.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : importStatus.type === 'error' ? (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            ) : (
              <FileCheck className="w-4 h-4 text-blue-600 shrink-0 animate-pulse" />
            )}
            <span>{importStatus.message}</span>
          </div>
        )}
      </div>
    </div>
  );
};
