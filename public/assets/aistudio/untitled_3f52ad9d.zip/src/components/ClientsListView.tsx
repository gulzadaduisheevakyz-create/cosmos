import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Plus,
  ChevronDown,
  User,
  Phone,
  Mail,
  ArrowUpDown,
  MoreVertical,
  CheckSquare,
  Square,
  Sparkles,
  Download,
  Upload,
  Heart,
  Star,
  Users,
} from 'lucide-react';
import { Customer, CustomerBooking, DailySaleRecord } from '../types';
import { formatCurrency, formatDate, db } from '../services/db';
import { ClientDetailModal } from './ClientDetailModal';

interface ClientsListViewProps {
  customers: Customer[];
  bookings: CustomerBooking[];
  sales: DailySaleRecord[];
  onRefresh: () => void;
  onOpenBookingModal?: (client?: Customer) => void;
}

type ClientSubNav = 'list' | 'segments' | 'loyalty' | 'reputation';

export const ClientsListView: React.FC<ClientsListViewProps> = ({
  customers,
  bookings,
  sales,
  onRefresh,
  onOpenBookingModal,
}) => {
  const [activeSubNav, setActiveSubNav] = useState<ClientSubNav>('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'sales-high' | 'name'>('newest');
  const [selectedClientIds, setSelectedClientIds] = useState<string[]>([]);
  const [selectedClientForModal, setSelectedClientForModal] = useState<Customer | null>(null);

  // Quick Add Client Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newMobile, setNewMobile] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newNotes, setNewNotes] = useState('');

  // Options Dropdown State
  const [isOptionsOpen, setIsOptionsOpen] = useState(false);

  // Filtered & Sorted Clients
  const filteredClients = useMemo(() => {
    return customers
      .filter((c) => {
        if (!searchQuery.trim()) return true;
        const q = searchQuery.toLowerCase();
        return (
          c.name.toLowerCase().includes(q) ||
          c.mobile.includes(q) ||
          (c.email && c.email.toLowerCase().includes(q))
        );
      })
      .sort((a, b) => {
        if (sortBy === 'newest') {
          return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
        }
        if (sortBy === 'oldest') {
          return new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime();
        }
        if (sortBy === 'sales-high') {
          return (b.totalSpent || 0) - (a.totalSpent || 0);
        }
        if (sortBy === 'name') {
          return a.name.localeCompare(b.name);
        }
        return 0;
      });
  }, [customers, searchQuery, sortBy]);

  // Bulk Selection Handlers
  const handleToggleSelectAll = () => {
    if (selectedClientIds.length === filteredClients.length) {
      setSelectedClientIds([]);
    } else {
      setSelectedClientIds(filteredClients.map((c) => c.id));
    }
  };

  const handleToggleClient = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedClientIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  // Quick Add Customer Handler
  const handleAddClientSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newMobile.trim()) return;

    await db.saveCustomer({
      id: `CUST-${Date.now().toString().slice(-4)}`,
      name: newName.trim(),
      mobile: newMobile.trim(),
      email: newEmail.trim() || undefined,
      notes: newNotes.trim() || undefined,
      totalVisits: 0,
      totalSpent: 0,
      walletBalance: 0,
      outstandingBalance: 0,
      segment: 'New',
      createdAt: new Date().toISOString().slice(0, 10),
    });

    setNewName('');
    setNewMobile('');
    setNewEmail('');
    setNewNotes('');
    setIsAddModalOpen(false);
    onRefresh();
  };

  // Format Created At helper matching "Oct 21, 2026"
  const formatCreatedAt = (dateStr: string) => {
    if (!dateStr) return 'Oct 21, 2026';
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  return (
    <div className="bg-[#0b0b0d] text-slate-100 rounded-2xl border border-white/10 shadow-2xl overflow-hidden font-sans flex flex-col md:flex-row min-h-[820px]">
      {/* Left Sidebar inside Clients (Matching Screenshot 1) */}
      <div className="w-full md:w-56 bg-[#121215] border-b md:border-b-0 md:border-r border-white/10 p-4 space-y-6 shrink-0">
        <div>
          <div className="text-xs font-bold text-white px-3 py-1 uppercase tracking-wider">
            Clients
          </div>
          <div className="mt-1 space-y-0.5 text-xs">
            <button
              onClick={() => setActiveSubNav('list')}
              className={`w-full px-3 py-2 rounded-xl text-left font-semibold transition-all flex items-center justify-between ${
                activeSubNav === 'list'
                  ? 'bg-[#272730] text-white shadow-xs'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Clients list</span>
            </button>
            <button
              onClick={() => setActiveSubNav('segments')}
              className={`w-full px-3 py-2 rounded-xl text-left font-medium transition-all flex items-center justify-between ${
                activeSubNav === 'segments'
                  ? 'bg-[#272730] text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Client segments</span>
            </button>
          </div>
        </div>

        <div>
          <div className="text-xs font-bold text-white px-3 py-1 uppercase tracking-wider">
            Engage
          </div>
          <div className="mt-1 space-y-0.5 text-xs">
            <button
              onClick={() => setActiveSubNav('loyalty')}
              className={`w-full px-3 py-2 rounded-xl text-left font-medium transition-all flex items-center justify-between ${
                activeSubNav === 'loyalty'
                  ? 'bg-[#272730] text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Client loyalty</span>
            </button>
            <button
              onClick={() => setActiveSubNav('reputation')}
              className={`w-full px-3 py-2 rounded-xl text-left font-medium transition-all flex items-center justify-between ${
                activeSubNav === 'reputation'
                  ? 'bg-[#272730] text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Online reputation</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Table Area (Exact match to Screenshot 1) */}
      <div className="flex-1 flex flex-col min-w-0 bg-[#0b0b0d]">
        {/* Top Header */}
        <div className="p-6 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-2xl font-bold tracking-tight text-white">Clients list</h1>
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-white/10 text-slate-300">
                2450
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              View, add, edit and delete your client's details.{' '}
              <span className="text-indigo-400 hover:underline cursor-pointer">Learn more</span>
            </p>
          </div>

          <div className="flex items-center gap-2 relative">
            {/* Options Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsOptionsOpen(!isOptionsOpen)}
                className="px-4 py-2 rounded-full text-xs font-semibold bg-[#18181c] border border-white/10 text-white hover:bg-[#222227] transition-colors flex items-center gap-1.5"
              >
                <span>Options</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {isOptionsOpen && (
                <div className="absolute right-0 mt-1 w-44 bg-[#18181c] border border-white/10 rounded-xl shadow-xl z-20 py-1 text-xs text-slate-300 animate-in fade-in zoom-in-95">
                  <button
                    type="button"
                    onClick={() => {
                      setIsOptionsOpen(false);
                      alert('Bulk export selected clients to Excel/CSV');
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-white/10 flex items-center gap-2"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export list</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsOptionsOpen(false);
                      alert('Import clients from CSV file');
                    }}
                    className="w-full px-3 py-2 text-left hover:bg-white/10 flex items-center gap-2"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Import clients</span>
                  </button>
                </div>
              )}
            </div>

            {/* Add Button */}
            <button
              type="button"
              onClick={() => setIsAddModalOpen(true)}
              className="px-5 py-2 rounded-full text-xs font-bold bg-white text-black hover:bg-slate-200 transition-colors shadow-xs"
            >
              Add
            </button>
          </div>
        </div>

        {/* Search, Filters & Sorting Bar */}
        <div className="px-6 py-2 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-1 max-w-lg">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
              <input
                type="text"
                placeholder="Name, email or phone"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs pl-9 pr-3 py-2 rounded-full bg-[#18181c] border border-white/10 text-white placeholder-slate-500 focus:outline-hidden focus:border-white/30"
              />
            </div>

            {/* Filters Button */}
            <button
              type="button"
              onClick={() => alert('Filter clients by Segment, Spend or Visits')}
              className="px-3.5 py-2 rounded-full text-xs font-medium bg-[#18181c] border border-white/10 text-white hover:bg-[#222227] flex items-center gap-1.5 shrink-0"
            >
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <span>Filters</span>
            </button>
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-1">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-3.5 py-2 rounded-full text-xs font-medium bg-[#18181c] border border-white/10 text-white hover:bg-[#222227] focus:outline-hidden cursor-pointer"
            >
              <option value="newest">Created at (newest first) ⇋</option>
              <option value="oldest">Created at (oldest first)</option>
              <option value="sales-high">Sales (highest first)</option>
              <option value="name">Name (A-Z)</option>
            </select>
          </div>
        </div>

        {/* Clients Table (Exact match to Screenshot 1) */}
        <div className="flex-1 overflow-x-auto px-6 py-3">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="border-b border-white/10 text-slate-400 font-semibold text-[11px]">
              <tr>
                <th className="py-3 px-2 w-8">
                  <button
                    type="button"
                    onClick={handleToggleSelectAll}
                    className="text-slate-500 hover:text-white"
                  >
                    {selectedClientIds.length > 0 && selectedClientIds.length === filteredClients.length ? (
                      <CheckSquare className="w-4 h-4 text-indigo-400" />
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                  </button>
                </th>
                <th className="py-3 px-3">Client name</th>
                <th className="py-3 px-3">Mobile number</th>
                <th className="py-3 px-3">Reviews</th>
                <th className="py-3 px-3">Sales</th>
                <th className="py-3 px-3">
                  <div className="flex items-center gap-1">
                    <span>Created at</span>
                    <span className="text-slate-500">↓</span>
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredClients.map((client) => {
                const isSelected = selectedClientIds.includes(client.id);

                return (
                  <tr
                    key={client.id}
                    onClick={() => setSelectedClientForModal(client)}
                    className="hover:bg-white/5 transition-colors cursor-pointer group"
                  >
                    {/* Checkbox */}
                    <td className="py-3.5 px-2" onClick={(e) => handleToggleClient(client.id, e)}>
                      <button type="button" className="text-slate-600 hover:text-white">
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-indigo-400" />
                        ) : (
                          <Square className="w-4 h-4" />
                        )}
                      </button>
                    </td>

                    {/* Client Name & Initial Avatar */}
                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-[#272738] text-indigo-300 font-bold text-xs flex items-center justify-center border border-indigo-500/20 shrink-0">
                          {client.name.slice(0, 1).toUpperCase()}
                        </div>
                        <span className="font-semibold text-white group-hover:text-indigo-300 transition-colors">
                          {client.name}
                        </span>
                      </div>
                    </td>

                    {/* Mobile number */}
                    <td className="py-3.5 px-3 font-mono text-slate-300">
                      {client.mobile}
                    </td>

                    {/* Reviews */}
                    <td className="py-3.5 px-3 text-slate-500">
                      {client.rating ? (
                        <span className="text-amber-400 font-bold flex items-center gap-1">
                          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                          <span>{client.rating}</span>
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>

                    {/* Sales in QAR */}
                    <td className="py-3.5 px-3 font-mono font-medium text-slate-200">
                      QAR {formatCurrency(client.totalSpent || 0)}
                    </td>

                    {/* Created At */}
                    <td className="py-3.5 px-3 text-slate-400 font-mono text-[11px]">
                      {formatCreatedAt(client.createdAt)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Client Detail / Overview Modal (Screenshot 2) */}
      {selectedClientForModal && (
        <ClientDetailModal
          isOpen={Boolean(selectedClientForModal)}
          onClose={() => setSelectedClientForModal(null)}
          client={selectedClientForModal}
          bookings={bookings}
          sales={sales}
          onRebookAppointment={(c) => {
            if (onOpenBookingModal) {
              onOpenBookingModal(c);
            }
          }}
          onRefresh={onRefresh}
        />
      )}

      {/* Quick Add Client Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black/75 z-60 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-[#18181c] border border-white/10 rounded-2xl w-full max-w-md p-6 space-y-4 text-white animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-base font-bold">Add New Client</h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddClientSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Full Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Maha Al-Kuwari"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  required
                  className="w-full p-2.5 bg-[#272730] border border-white/10 rounded-xl text-white focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Mobile Number *</label>
                <input
                  type="text"
                  placeholder="+974 6652 0205"
                  value={newMobile}
                  onChange={(e) => setNewMobile(e.target.value)}
                  required
                  className="w-full p-2.5 bg-[#272730] border border-white/10 rounded-xl text-white font-mono focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Email (Optional)</label>
                <input
                  type="email"
                  placeholder="client@domain.qa"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  className="w-full p-2.5 bg-[#272730] border border-white/10 rounded-xl text-white focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Notes / Preferences</label>
                <textarea
                  rows={2}
                  placeholder="Preferences, allergy alerts, favorite services..."
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full p-2.5 bg-[#272730] border border-white/10 rounded-xl text-white focus:outline-hidden focus:border-indigo-500"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-white text-black font-bold hover:bg-slate-200"
                >
                  Save Client
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
