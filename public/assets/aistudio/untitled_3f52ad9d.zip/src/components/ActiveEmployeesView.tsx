import React, { useState, useMemo } from 'react';
import { Search, Eye, UserMinus, Plus, Users } from 'lucide-react';
import { Employee } from '../types';
import { formatCurrency, calculateDaysRemaining } from '../services/db';

interface ActiveEmployeesViewProps {
  employees: Employee[];
  onOpenEmployee: (empId: string) => void;
  onNavigateAdd: () => void;
  onToggleStatus: (empId: string) => void;
}

export const ActiveEmployeesView: React.FC<ActiveEmployeesViewProps> = ({
  employees,
  onOpenEmployee,
  onNavigateAdd,
  onToggleStatus,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const activeEmployees = useMemo(() => {
    return employees.filter((emp) => emp.status !== 'Unemployed');
  }, [employees]);

  const filtered = useMemo(() => {
    if (!searchTerm) return activeEmployees;
    const term = searchTerm.toLowerCase();
    return activeEmployees.filter(
      (e) =>
        e.employeeName.toLowerCase().includes(term) ||
        e.employeeId.toLowerCase().includes(term) ||
        e.position.toLowerCase().includes(term) ||
        e.residencyQid.toLowerCase().includes(term) ||
        e.passportNumber.toLowerCase().includes(term) ||
        e.nationality.toLowerCase().includes(term) ||
        e.payerBank.toLowerCase().includes(term)
    );
  }, [activeEmployees, searchTerm]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            <span>Active Employees Directory</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Managing {activeEmployees.length} active staff members across COSMOS Beauty Salon facilities.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search active staff..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
            />
          </div>

          <button
            onClick={onNavigateAdd}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Employee</span>
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto max-h-[650px] custom-scrollbar">
          <table className="w-full text-xs text-left border-collapse min-w-[1400px]">
            <thead className="bg-slate-50 text-slate-600 font-semibold sticky top-0 z-10 border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">No</th>
                <th className="py-2.5 px-3">Employee ID</th>
                <th className="py-2.5 px-3">Name</th>
                <th className="py-2.5 px-3">Company</th>
                <th className="py-2.5 px-3">Position</th>
                <th className="py-2.5 px-3">Nationality</th>
                <th className="py-2.5 px-3">Mobile</th>
                <th className="py-2.5 px-3">Joining Date</th>
                <th className="py-2.5 px-3">End Contract</th>
                <th className="py-2.5 px-3">Duty</th>
                <th className="py-2.5 px-3">Passport Expiry</th>
                <th className="py-2.5 px-3">QID Expiry</th>
                <th className="py-2.5 px-3 text-right">Basic Salary</th>
                <th className="py-2.5 px-3 text-right">Total Package</th>
                <th className="py-2.5 px-3 text-right">Outstanding</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right sticky right-0 bg-slate-50">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((emp, idx) => {
                const pDays = calculateDaysRemaining(emp.passportExpiry);
                const qDays = calculateDaysRemaining(emp.residencyExpiry);

                return (
                  <tr
                    key={emp.employeeId}
                    onClick={() => onOpenEmployee(emp.employeeId)}
                    className="hover:bg-blue-50/40 cursor-pointer transition-colors"
                  >
                    <td className="py-2.5 px-3 font-mono text-slate-500">{emp.no || idx + 1}</td>
                    <td className="py-2.5 px-3 font-bold font-mono text-slate-900">{emp.employeeId}</td>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">{emp.employeeName}</td>
                    <td className="py-2.5 px-3 text-slate-700">{emp.company}</td>
                    <td className="py-2.5 px-3 text-slate-800">{emp.position}</td>
                    <td className="py-2.5 px-3 text-slate-700">{emp.nationality}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-600">{emp.mobile || '-'}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-600">{emp.joiningDate}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-600">{emp.endContract}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
                        {emp.duty}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                          pDays < 90
                            ? 'bg-rose-100 text-rose-800'
                            : pDays < 180
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {emp.passportExpiry || 'N/A'} (Day {pDays})
                      </span>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                          qDays < 90
                            ? 'bg-rose-100 text-rose-800'
                            : qDays < 180
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {emp.residencyExpiry || 'N/A'} (Day {qDays})
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums">
                      QAR {formatCurrency(emp.basicSalary)}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-bold text-slate-900 bg-slate-50/60">
                      QAR {formatCurrency(emp.totalSalary)}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-semibold text-rose-600">
                      QAR {formatCurrency(emp.outstanding)}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        Active
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right sticky right-0 bg-white">
                      <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => onOpenEmployee(emp.employeeId)}
                          className="px-2 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded transition-colors flex items-center gap-1"
                        >
                          <Eye className="w-3 h-3" />
                          <span>View</span>
                        </button>
                        <button
                          onClick={() => onToggleStatus(emp.employeeId)}
                          className="px-2 py-1 text-xs font-medium text-amber-700 bg-amber-50 hover:bg-amber-100 rounded transition-colors flex items-center gap-1"
                          title="Move to Former / Unemployed"
                        >
                          <UserMinus className="w-3 h-3" />
                          <span>Former</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {filtered.length === 0 && (
            <div className="p-12 text-center text-slate-400">
              <p>No active employees found matching your criteria.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
