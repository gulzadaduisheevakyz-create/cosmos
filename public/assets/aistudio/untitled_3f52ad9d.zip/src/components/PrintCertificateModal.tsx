import React from 'react';
import { Printer, X } from 'lucide-react';
import { Certificate, SystemSettings } from '../types';
import { formatCurrency, formatDate } from '../services/db';

interface PrintCertificateModalProps {
  certificate: Certificate | null;
  settings: SystemSettings;
  onClose: () => void;
}

export const PrintCertificateModal: React.FC<PrintCertificateModalProps> = ({
  certificate,
  settings,
  onClose,
}) => {
  if (!certificate) return null;

  const handlePrint = () => {
    window.print();
  };

  const c = certificate;
  const s = c.salaryData;
  const gender = c.employeeName.toUpperCase().includes('MR.') ? 'Mr.' : 'Ms.';
  const displayName = c.employeeName.replace(/^(MR\.|MS\.|MRS\.)\s*/i, '');

  const salaryRows: { label: string; amount: number }[] = [];
  let totalCalc = 0;

  if (c.includeBasic && Number(s.basicSalary) > 0) {
    salaryRows.push({ label: 'Basic Salary', amount: Number(s.basicSalary) });
    totalCalc += Number(s.basicSalary);
  }
  if (c.includeFood && Number(s.foodAllowance) > 0) {
    salaryRows.push({ label: 'Food Allowance', amount: Number(s.foodAllowance) });
    totalCalc += Number(s.foodAllowance);
  }
  if (c.includeTransport && Number(s.transportAllowance) > 0) {
    salaryRows.push({ label: 'Transportation Allowance', amount: Number(s.transportAllowance) });
    totalCalc += Number(s.transportAllowance);
  }
  if (c.includeCar && Number(s.carOperationAllowance) > 0) {
    salaryRows.push({ label: 'Car Operation Allowance', amount: Number(s.carOperationAllowance) });
    totalCalc += Number(s.carOperationAllowance);
  }
  if (c.includeOther && Number(s.otherAllowance) > 0) {
    salaryRows.push({ label: 'Other Allowances', amount: Number(s.otherAllowance) });
    totalCalc += Number(s.otherAllowance);
  }

  return (
    <>
      {/* On-screen Preview Dialog */}
      <div className="fixed inset-0 bg-slate-950/80 z-60 flex items-center justify-center p-4 backdrop-blur-xs no-print">
        <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden flex flex-col max-h-[92vh]">
          {/* Header */}
          <div className="p-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
            <h3 className="text-sm font-bold flex items-center gap-2">
              <Printer className="w-4 h-4 text-emerald-400" />
              <span>Official Print Preview · Ref: {c.reference}</span>
            </h3>
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrint}
                className="px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg flex items-center gap-1.5 shadow-xs transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Official Letter (A4)</span>
              </button>
              <button
                onClick={onClose}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Letter Body Preview */}
          <div className="flex-1 overflow-y-auto p-8 sm:p-12 custom-scrollbar bg-white font-serif text-slate-950 leading-relaxed text-xs">
            {/* Letterhead */}
            <div className="text-center pb-4 border-b-2 border-slate-950 mb-6 font-sans">
              <h1 className="text-xl font-bold uppercase tracking-wider text-slate-950">
                {settings.companyName || 'COSMOS BEAUTY SALON'}
              </h1>
              <p className="text-[11px] text-slate-600 mt-1">
                {settings.companyAddress} · Tel: {settings.companyPhone} · {settings.companyEmail}
              </p>
              <h2 className="text-sm font-bold uppercase tracking-widest text-slate-950 mt-3">
                Human Resources Department
              </h2>
            </div>

            {/* Meta */}
            <div className="flex justify-between items-center text-xs mb-6 font-sans">
              <div>
                <strong>Corresponding to:</strong> {formatDate(c.correspondingDate)}
              </div>
              <div>
                <strong>Reference:</strong> <span className="font-mono">{c.reference}</span>
              </div>
            </div>

            {/* Title */}
            <div className="text-center font-bold text-sm uppercase underline tracking-wider my-6 font-sans">
              {c.certType === 'salary' ? 'SALARY CERTIFICATE' : 'CERTIFICATE OF EMPLOYMENT / WORK'}
            </div>

            {/* Addressed To */}
            <div className="font-bold text-xs mb-4 font-sans text-slate-950">
              To: {c.recipient}
            </div>

            {/* Prose */}
            <div className="text-xs text-justify space-y-3.5 leading-relaxed text-slate-900">
              {c.certType === 'salary' ? (
                <>
                  <p>
                    This is to certify that {gender} <strong>{displayName}</strong>, Nationality:{' '}
                    <strong>{c.employeeNationality || 'N/A'}</strong>, holder of QID No.{' '}
                    <strong>{c.employeeQid || 'N/A'}</strong>, Employee ID:{' '}
                    <strong>{c.employeeId || 'N/A'}</strong>, has been employed with{' '}
                    <strong>{settings.companyName || 'COSMOS BEAUTY SALON'}</strong> since{' '}
                    <strong>{formatDate(c.employeeJoiningDate) || 'N/A'}</strong> in the position of{' '}
                    <strong>{c.employeePosition || 'N/A'}</strong>.
                  </p>
                  <p>
                    We further certify that {gender.toLowerCase()}'s monthly remuneration package is
                    structured as follows:
                  </p>

                  {/* Table */}
                  <table className="w-full text-xs border border-slate-950 border-collapse my-4 font-sans">
                    <thead>
                      <tr className="bg-slate-100 border-b border-slate-950 text-slate-950">
                        <th className="p-2 text-left font-bold border-r border-slate-950">
                          Description
                        </th>
                        <th className="p-2 text-right font-bold w-44">Monthly Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-300">
                      {salaryRows.map((row, idx) => (
                        <tr key={idx}>
                          <td className="p-2 border-r border-slate-950">{row.label}</td>
                          <td className="p-2 text-right font-mono tabular-nums">
                            QAR {formatCurrency(row.amount)}
                          </td>
                        </tr>
                      ))}
                      <tr className="font-bold bg-slate-50 border-t-2 border-slate-950">
                        <td className="p-2 border-r border-slate-950">Total Monthly Salary</td>
                        <td className="p-2 text-right font-mono tabular-nums">
                          QAR {formatCurrency(totalCalc)}
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  <p>
                    This certificate is issued upon {gender.toLowerCase()}'s request for submission to
                    the bank without any financial obligation or commitment on our part.
                  </p>
                </>
              ) : (
                <>
                  <p>
                    This is to certify that {gender} <strong>{displayName}</strong>, holder of QID
                    No. <strong>{c.employeeQid || 'N/A'}</strong>, Nationality:{' '}
                    <strong>{c.employeeNationality || 'N/A'}</strong>, Employee ID:{' '}
                    <strong>{c.employeeId || 'N/A'}</strong>, has been employed with{' '}
                    <strong>{settings.companyName || 'COSMOS BEAUTY SALON'}</strong> since{' '}
                    <strong>{formatDate(c.employeeJoiningDate) || 'N/A'}</strong> and is actively
                    serving in the position of <strong>{c.employeePosition || 'N/A'}</strong>.
                  </p>
                  <p>
                    During {gender.toLowerCase()}'s employment, {gender.toLowerCase()} has conducted
                    her/his duties with integrity and professionalism.
                  </p>
                  <p>
                    This certificate has been issued upon {gender.toLowerCase()}'s request for
                    whatever legal and official purpose it may serve.
                  </p>
                </>
              )}

              <p className="pt-2 text-[11px] text-slate-600 font-sans italic">
                This certificate is valid for {settings.certValidity || 1} month(s) from the date of
                issuance.
              </p>
            </div>

            {/* Stamp & Signatory */}
            <div className="mt-14 pt-6 flex justify-between items-end text-xs font-sans">
              <div className="text-center w-40">
                <div className="w-24 h-24 mx-auto border-2 border-dashed border-slate-300 rounded-lg flex items-center justify-center text-[11px] text-slate-400">
                  Company Stamp
                </div>
                <div className="mt-2 text-[11px] text-slate-500 font-semibold">
                  {settings.companyName || 'COSMOS BEAUTY SALON'}
                </div>
              </div>

              <div className="text-center w-52">
                <div className="border-t border-slate-950 pt-2 font-bold text-slate-950 text-xs">
                  {c.signatoryName}
                </div>
                <div className="text-[11px] text-slate-600 font-medium">{c.signatoryTitle}</div>
                <div className="text-[10px] text-slate-400 mt-1">Authorized HR Signatory</div>
              </div>
            </div>

            {/* Footer Barcode / Ref */}
            <div className="mt-8 pt-3 border-t border-slate-100 text-[10px] text-slate-400 font-mono text-right flex justify-between items-center font-sans">
              <span>Authentic Verification Seal</span>
              <span>Ref: {c.reference} · Issued {new Date(c.createdAt).toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Dedicated Hidden Printable Container for @media print */}
      <div id="printable-certificate" style={{ display: 'none' }}>
        <div style={{ textAlign: 'center', borderBottom: '2px solid #000', paddingBottom: '14px', marginBottom: '22px' }}>
          <div style={{ fontSize: '16pt', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '1px' }}>
            {settings.companyName || 'COSMOS BEAUTY SALON'}
          </div>
          <div style={{ fontSize: '10pt', color: '#333', marginTop: '3px' }}>
            {settings.companyAddress} | Tel: {settings.companyPhone} | {settings.companyEmail}
          </div>
          <div style={{ fontSize: '13pt', fontWeight: 'bold', marginTop: '10px', textTransform: 'uppercase' }}>
            Human Resources (HR)
          </div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px', fontSize: '11pt' }}>
          <div><strong>Corresponding to:</strong> {formatDate(c.correspondingDate)}</div>
          <div><strong>Reference:</strong> {c.reference}</div>
        </div>

        <div style={{ textAlign: 'center', fontWeight: 'bold', fontSize: '13pt', textDecoration: 'underline', margin: '22px 0', textTransform: 'uppercase' }}>
          {c.certType === 'salary' ? 'SALARY CERTIFICATE' : 'CERTIFICATE OF EMPLOYMENT / WORK'}
        </div>

        <div style={{ fontWeight: 'bold', marginBottom: '16px', fontSize: '12pt' }}>
          To: {c.recipient}
        </div>

        <div style={{ textAlign: 'justify', lineHeight: '1.7', fontSize: '11.5pt' }}>
          {c.certType === 'salary' ? (
            <>
              <p style={{ marginBottom: '12px' }}>
                This is to certify that {gender} <strong>{displayName}</strong>, Nationality: <strong>{c.employeeNationality || 'N/A'}</strong>, holder of QID No. <strong>{c.employeeQid || 'N/A'}</strong>, Employee ID: <strong>{c.employeeId || 'N/A'}</strong>, has been employed with {settings.companyName || 'COSMOS BEAUTY SALON'} since <strong>{formatDate(c.employeeJoiningDate) || 'N/A'}</strong> in the position of <strong>{c.employeePosition || 'N/A'}</strong>.
              </p>
              <p style={{ marginBottom: '12px' }}>
                We further certify that {gender.toLowerCase()}'s current monthly salary package is structured as follows:
              </p>

              <table style={{ width: '100%', borderCollapse: 'collapse', margin: '18px 0', fontSize: '11pt' }}>
                <thead>
                  <tr style={{ background: '#f3f4f6' }}>
                    <th style={{ border: '1px solid #000', padding: '8px 12px', textAlign: 'left' }}>Description</th>
                    <th style={{ border: '1px solid #000', padding: '8px 12px', textAlign: 'right' }}>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {salaryRows.map((r, idx) => (
                    <tr key={idx}>
                      <td style={{ border: '1px solid #000', padding: '8px 12px' }}>{r.label}</td>
                      <td style={{ border: '1px solid #000', padding: '8px 12px', textAlign: 'right', fontFamily: 'monospace' }}>
                        QAR {formatCurrency(r.amount)}
                      </td>
                    </tr>
                  ))}
                  <tr style={{ fontWeight: 'bold', background: '#f9fafb' }}>
                    <td style={{ border: '1px solid #000', padding: '8px 12px' }}>Total Monthly Salary</td>
                    <td style={{ border: '1px solid #000', padding: '8px 12px', textAlign: 'right', fontFamily: 'monospace' }}>
                      QAR {formatCurrency(totalCalc)}
                    </td>
                  </tr>
                </tbody>
              </table>

              <p style={{ marginBottom: '12px' }}>
                This certificate has been issued upon {gender.toLowerCase()}'s request for submission to the bank and for whatever legal purpose it may serve.
              </p>
            </>
          ) : (
            <>
              <p style={{ marginBottom: '12px' }}>
                This is to certify that {gender} <strong>{displayName}</strong>, holder of QID No. <strong>{c.employeeQid || 'N/A'}</strong>, Nationality: <strong>{c.employeeNationality || 'N/A'}</strong>, Employee ID: <strong>{c.employeeId || 'N/A'}</strong>, has been employed with {settings.companyName || 'COSMOS BEAUTY SALON'} since <strong>{formatDate(c.employeeJoiningDate) || 'N/A'}</strong> and is currently working with us in the position of <strong>{c.employeePosition || 'N/A'}</strong>.
              </p>
              <p style={{ marginBottom: '12px' }}>
                During {gender.toLowerCase()}'s employment, {gender.toLowerCase()} has performed her/his duties professionally and remains in good standing with the company.
              </p>
              <p style={{ marginBottom: '12px' }}>
                This certificate has been issued upon {gender.toLowerCase()}'s request for whatever legal purpose it may serve.
              </p>
            </>
          )}

          <p style={{ marginTop: '16px', fontSize: '10.5pt', color: '#444' }}>
            This certificate shall be valid for {settings.certValidity || 1} month(s) from the date of issuance.
          </p>
          <p style={{ marginTop: '8px' }}>Accept our sincere regards.</p>
        </div>

        <div style={{ marginTop: '60px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div style={{ textAlign: 'center', width: '200px' }}>
            <div style={{ width: '110px', height: '110px', border: '2px dashed #888', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto', fontSize: '10pt', color: '#777' }}>
              Company Stamp
            </div>
            <div style={{ fontSize: '10pt', marginTop: '6px', fontWeight: 'bold' }}>
              {settings.companyName || 'COSMOS BEAUTY SALON'}
            </div>
          </div>

          <div style={{ textAlign: 'center', width: '220px' }}>
            <div style={{ borderTop: '1px solid #000', paddingTop: '6px', fontWeight: 'bold', fontSize: '11pt' }}>
              {c.signatoryName}
            </div>
            <div style={{ fontSize: '10pt', color: '#333' }}>{c.signatoryTitle}</div>
            <div style={{ fontSize: '9pt', color: '#666', marginTop: '2px' }}>Authorized Signatory</div>
          </div>
        </div>

        <div style={{ fontFamily: 'monospace', fontSize: '9pt', color: '#666', textAlign: 'right', marginTop: '40px' }}>
          Ref: {c.reference} | Generated: {new Date(c.createdAt).toLocaleString()}
        </div>
      </div>
    </>
  );
};
