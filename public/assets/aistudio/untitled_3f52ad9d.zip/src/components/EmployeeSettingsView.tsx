import React, { useState, useMemo } from 'react';
import {
  Users,
  Settings,
  ShieldCheck,
  Scissors,
  Sparkles,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  Briefcase,
  X,
  Edit2,
  Eye,
  Check,
  Building,
  UserCheck,
  UserX,
  Plus,
} from 'lucide-react';
import {
  Employee,
  ServiceCatalogueItem,
  SalonServiceCategory,
  NonServiceRole,
  ServiceCategory,
} from '../types';
import { db, formatCurrency } from '../services/db';

interface EmployeeSettingsViewProps {
  employees: Employee[];
  catalogue: ServiceCatalogueItem[];
  onRefresh: () => void;
  onOpenEmployee?: (id: string) => void;
  onNavigateAddEmployee?: () => void;
}

export const SALON_CATEGORIES: { id: SalonServiceCategory; label: string; icon: string; color: string; bg: string }[] = [
  { id: 'Hairdresser', label: 'Hairdresser', icon: '💇‍♀️', color: 'text-amber-400', bg: 'bg-amber-500/10 border-amber-500/30' },
  { id: 'Eyelash Art', label: 'Eyelash Art', icon: '👁️', color: 'text-purple-400', bg: 'bg-purple-500/10 border-purple-500/30' },
  { id: 'Eyebrows Art', label: 'Eyebrows Art', icon: '🖋️', color: 'text-cyan-400', bg: 'bg-cyan-500/10 border-cyan-500/30' },
  { id: 'Nail Art', label: 'Nail Art', icon: '💅', color: 'text-pink-400', bg: 'bg-pink-500/10 border-pink-500/30' },
  { id: 'Spa', label: 'Spa & Hammam', icon: '🧖‍♀️', color: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/30' },
  { id: 'Spray Tan', label: 'Spray Tan', icon: '☀️', color: 'text-orange-400', bg: 'bg-orange-500/10 border-orange-500/30' },
];

export const NON_SERVICE_ROLES: { id: NonServiceRole; label: string; icon: string; description: string }[] = [
  { id: 'Manager', label: 'Manager', icon: '👑', description: 'Salon operations, approvals, managerial signatory & supervision' },
  { id: 'HR', label: 'HR', icon: '📋', description: 'Personnel records, visa compliance, contracts & leave tracking' },
  { id: 'Receptionist', label: 'Receptionist', icon: '📞', description: 'Customer check-in, appointments scheduling & POS checkout desk' },
  { id: 'Accountant', label: 'Accountant', icon: '🧮', description: 'Bookkeeping, monthly payroll, bank WPS transfers & daily audits' },
  { id: 'Cleaner', label: 'Cleaner', icon: '🧹', description: 'Salon sanitation, sterilization, towel care & facility maintenance' },
];

export const EmployeeSettingsView: React.FC<EmployeeSettingsViewProps> = ({
  employees,
  catalogue,
  onRefresh,
  onOpenEmployee,
  onNavigateAddEmployee,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<'ALL' | SalonServiceCategory | 'NON_SERVICE'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);

  // Edit Modal Form State
  const [editRoleType, setEditRoleType] = useState<'service' | 'non_service'>('service');
  const [editCategory, setEditCategory] = useState<SalonServiceCategory>('Hairdresser');
  const [editNonServiceRole, setEditNonServiceRole] = useState<NonServiceRole>('Manager');
  const [editCommissionRate, setEditCommissionRate] = useState<number>(10);
  const [editProdCommissionRate, setEditProdCommissionRate] = useState<number>(5);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Filter Active Employees
  const activeEmployees = useMemo(() => {
    return employees.filter((e) => e.status !== 'Unemployed');
  }, [employees]);

  // Count employees per category and non-service
  const roleMetrics = useMemo(() => {
    const serviceStaff = activeEmployees.filter((e) => e.canProvideServices !== false && !['HR', 'Accountant', 'Cleaner Staff', 'Cleaner', 'Manager', 'Receptionist'].includes(e.employeeRole || e.position));
    const nonServiceStaff = activeEmployees.filter((e) => e.canProvideServices === false || ['HR', 'Accountant', 'Cleaner Staff', 'Cleaner', 'Manager', 'Receptionist'].includes(e.employeeRole || e.position));

    const categoryCounts: Record<SalonServiceCategory, number> = {
      'Hairdresser': 0,
      'Eyelash Art': 0,
      'Eyebrows Art': 0,
      'Nail Art': 0,
      'Spa': 0,
      'Spray Tan': 0,
    };

    serviceStaff.forEach((emp) => {
      const cat = (emp.assignedCategory || (emp.serviceCategories && emp.serviceCategories[0]) || emp.employeeRole) as SalonServiceCategory;
      if (categoryCounts[cat] !== undefined) {
        categoryCounts[cat]++;
      }
    });

    return {
      total: activeEmployees.length,
      serviceCount: serviceStaff.length,
      nonServiceCount: nonServiceStaff.length,
      categoryCounts,
    };
  }, [activeEmployees]);

  // Filtered employees according to active filter and search query
  const filteredEmployees = useMemo(() => {
    return activeEmployees.filter((emp) => {
      const isNonService =
        emp.canProvideServices === false ||
        ['HR', 'Accountant', 'Cleaner Staff', 'Cleaner', 'Manager', 'Receptionist'].includes(
          emp.employeeRole || emp.position
        );

      if (selectedFilter === 'NON_SERVICE') {
        if (!isNonService) return false;
      } else if (selectedFilter !== 'ALL') {
        if (isNonService) return false;
        const assigned =
          emp.assignedCategory ||
          (emp.serviceCategories && emp.serviceCategories[0]) ||
          emp.employeeRole;
        if (assigned !== selectedFilter) return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = emp.employeeName.toLowerCase().includes(q);
        const matchId = emp.employeeId.toLowerCase().includes(q);
        const matchRole = (emp.employeeRole || emp.position).toLowerCase().includes(q);
        if (!matchName && !matchId && !matchRole) return false;
      }

      return true;
    });
  }, [activeEmployees, selectedFilter, searchQuery]);

  // Open Edit Modal for an Employee
  const handleOpenEdit = (emp: Employee) => {
    setEditingEmployee(emp);
    const isNonService =
      emp.canProvideServices === false ||
      ['HR', 'Accountant', 'Cleaner Staff', 'Cleaner', 'Manager', 'Receptionist'].includes(
        emp.employeeRole || emp.position
      );

    if (isNonService) {
      setEditRoleType('non_service');
      const roleName = (emp.employeeRole || emp.position) as NonServiceRole;
      setEditNonServiceRole(
        ['Manager', 'HR', 'Receptionist', 'Accountant', 'Cleaner'].includes(roleName)
          ? roleName
          : 'Manager'
      );
      setEditCommissionRate(0);
      setEditProdCommissionRate(0);
    } else {
      setEditRoleType('service');
      const cat = (emp.assignedCategory ||
        (emp.serviceCategories && emp.serviceCategories[0]) ||
        emp.employeeRole) as SalonServiceCategory;
      setEditCategory(
        ['Hairdresser', 'Eyelash Art', 'Eyebrows Art', 'Nail Art', 'Spa', 'Spray Tan'].includes(cat)
          ? cat
          : 'Hairdresser'
      );
      setEditCommissionRate(emp.saleCommissionRate || 10);
      setEditProdCommissionRate(emp.prodSaleCommission || 5);
    }
  };

  // Save Role / Category Assignment
  const handleSaveRole = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEmployee) return;

    setIsSubmitting(true);
    try {
      let updatedEmp: Employee;

      if (editRoleType === 'service') {
        // STRICT RULE: 1 Employee = Exactly 1 Service Category!
        updatedEmp = {
          ...editingEmployee,
          canProvideServices: true,
          availableForBooking: true,
          employeeRole: editCategory,
          assignedCategory: editCategory,
          serviceCategories: [editCategory], // Single category array
          saleCommissionRate: editCommissionRate,
          prodSaleCommission: editProdCommissionRate,
        };
      } else {
        // Non-service role: does NOT perform any salon categories/services
        updatedEmp = {
          ...editingEmployee,
          canProvideServices: false,
          availableForBooking: false,
          employeeRole: editNonServiceRole,
          assignedCategory: undefined,
          serviceCategories: [], // Empty: does not perform any services
          saleCommissionRate: 0,
          prodSaleCommission: 0,
        };
      }

      await db.saveEmployee(updatedEmp);
      await db.logAudit(
        'EMPLOYEE_ROLE_UPDATED',
        `Configured role for ${updatedEmp.employeeName}: ${editRoleType === 'service' ? `Salon Service (${editCategory})` : `Non-Service (${editNonServiceRole})`}`
      );

      setSuccessToast(`Successfully updated category settings for ${updatedEmp.employeeName}`);
      setTimeout(() => setSuccessToast(null), 3500);

      setEditingEmployee(null);
      onRefresh();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* ----------------- TOP BANNER & ENFORCEMENT NOTICE ----------------- */}
      <div className="bg-[#121216] border border-[#2b2b34] rounded-2xl p-5 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                <span>Cosmos Role Policy</span>
              </span>
              <span className="text-xs text-slate-400 font-medium">
                1 Employee &bull; 1 Designated Service Category
              </span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
              <Settings className="w-5 h-5 text-purple-400" />
              <span>Employee Category &amp; Role Settings</span>
            </h2>
            <p className="text-xs text-slate-400 max-w-2xl mt-1 leading-relaxed">
              In Cosmos Beauty Salon, each service specialist is dedicated to <span className="text-purple-300 font-semibold">one exclusive category</span> (Hairdresser, Eyelash Art, Eyebrows Art, Nail Art, Spa, or Spray Tan) and cannot perform services outside their assigned specialty. Administrative &amp; support staff (Manager, HR, Receptionist, Accountant, Cleaner) do not perform salon service bookings.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {onNavigateAddEmployee && (
              <button
                type="button"
                onClick={onNavigateAddEmployee}
                className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-950 bg-white hover:bg-slate-100 flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Add Employee</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Success Notification */}
      {successToast && (
        <div className="p-3 bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs rounded-xl flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
          <span>{successToast}</span>
        </div>
      )}

      {/* ----------------- CATEGORY METRICS CARDS ----------------- */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2.5">
        <div
          onClick={() => setSelectedFilter('ALL')}
          className={`p-3 rounded-xl border transition-all cursor-pointer ${
            selectedFilter === 'ALL'
              ? 'bg-purple-950/40 border-purple-500 text-white shadow-md'
              : 'bg-[#141419] border-[#25252e] text-slate-300 hover:bg-[#1b1b22]'
          }`}
        >
          <div className="text-[10px] uppercase font-bold text-slate-400">Total Staff</div>
          <div className="text-lg font-bold text-white mt-0.5">{roleMetrics.total}</div>
          <div className="text-[10px] text-purple-400 font-medium">All active</div>
        </div>

        {SALON_CATEGORIES.map((cat) => {
          const count = roleMetrics.categoryCounts[cat.id];
          const isSelected = selectedFilter === cat.id;

          return (
            <div
              key={cat.id}
              onClick={() => setSelectedFilter(cat.id)}
              className={`p-3 rounded-xl border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-purple-950/40 border-purple-500 text-white shadow-md'
                  : 'bg-[#141419] border-[#25252e] text-slate-300 hover:bg-[#1b1b22]'
              }`}
            >
              <div className="flex items-center justify-between text-xs">
                <span>{cat.icon}</span>
                <span className={`text-[10px] font-bold ${count > 0 ? cat.color : 'text-slate-500'}`}>
                  {count}
                </span>
              </div>
              <div className="text-xs font-bold text-white truncate mt-1">{cat.label}</div>
              <div className="text-[9px] text-slate-400 font-mono">1 Category</div>
            </div>
          );
        })}

        <div
          onClick={() => setSelectedFilter('NON_SERVICE')}
          className={`p-3 rounded-xl border transition-all cursor-pointer ${
            selectedFilter === 'NON_SERVICE'
              ? 'bg-purple-950/40 border-purple-500 text-white shadow-md'
              : 'bg-[#141419] border-[#25252e] text-slate-300 hover:bg-[#1b1b22]'
          }`}
        >
          <div className="flex items-center justify-between text-xs">
            <span>🏢</span>
            <span className="text-[10px] font-bold text-blue-400">{roleMetrics.nonServiceCount}</span>
          </div>
          <div className="text-xs font-bold text-white truncate mt-1">Non-Service</div>
          <div className="text-[9px] text-slate-400 font-mono">Admin / Support</div>
        </div>
      </div>

      {/* ----------------- SEARCH & CONTROLS ----------------- */}
      <div className="bg-[#121216] border border-[#272730] p-4 rounded-xl flex flex-wrap items-center justify-between gap-3 text-white">
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search employee by name, ID (e.g. CBSE20243), or position..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full text-xs bg-[#191920] border border-[#2f2f3b] rounded-lg px-3 py-1.5 text-white focus:outline-hidden focus:border-purple-500"
          />
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">Showing:</span>
          <span className="font-bold text-white font-mono">{filteredEmployees.length}</span>
          <span className="text-slate-400">employees</span>
        </div>
      </div>

      {/* ----------------- EMPLOYEES SETTINGS TABLE ----------------- */}
      <div className="bg-[#121216] border border-[#25252e] rounded-2xl overflow-hidden shadow-xl text-white">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#17171e] text-slate-400 uppercase text-[10px] font-bold tracking-wider border-b border-[#25252e]">
              <tr>
                <th className="py-3.5 px-4">Employee</th>
                <th className="py-3.5 px-4">Role Classification</th>
                <th className="py-3.5 px-4">Assigned Category</th>
                <th className="py-3.5 px-4">Allowed Services Scope</th>
                <th className="py-3.5 px-4 text-center">Service Commission</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1f1f28]">
              {filteredEmployees.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500 text-xs">
                    No employees matching the selected category filter or search query.
                  </td>
                </tr>
              ) : (
                filteredEmployees.map((emp) => {
                  const isNonService =
                    emp.canProvideServices === false ||
                    ['HR', 'Accountant', 'Cleaner Staff', 'Cleaner', 'Manager', 'Receptionist'].includes(
                      emp.employeeRole || emp.position
                    );

                  const assignedCat = (emp.assignedCategory ||
                    (emp.serviceCategories && emp.serviceCategories[0]) ||
                    emp.employeeRole) as SalonServiceCategory;

                  // Find services matching employee's designated category
                  const eligibleServices = !isNonService
                    ? catalogue.filter((s) => s.category === assignedCat && s.isActive)
                    : [];

                  const catConfig = SALON_CATEGORIES.find((c) => c.id === assignedCat);

                  return (
                    <tr
                      key={emp.employeeId}
                      className="hover:bg-[#181820] transition-colors group"
                    >
                      {/* Employee Name & ID */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-purple-600/20 border border-purple-500/40 text-purple-300 flex items-center justify-center font-bold text-xs shrink-0">
                            {emp.employeeName.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-bold text-white group-hover:text-purple-300 transition-colors">
                              {emp.employeeName}
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                              {emp.employeeId} &bull; {emp.position}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Role Classification */}
                      <td className="py-3.5 px-4">
                        {isNonService ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-950/50 text-blue-300 border border-blue-800/40">
                            <Building className="w-3 h-3" />
                            <span>Non-Service Staff</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-950/50 text-emerald-300 border border-emerald-800/40">
                            <Scissors className="w-3 h-3" />
                            <span>Salon Service Specialist</span>
                          </span>
                        )}
                      </td>

                      {/* Assigned Category */}
                      <td className="py-3.5 px-4">
                        {isNonService ? (
                          <div className="flex items-center gap-1.5">
                            <span className="text-sm">
                              {emp.employeeRole === 'Manager' ? '👑' : emp.employeeRole === 'HR' ? '📋' : emp.employeeRole === 'Receptionist' ? '📞' : emp.employeeRole === 'Accountant' ? '🧮' : '🧹'}
                            </span>
                            <span className="font-semibold text-slate-300">
                              {emp.employeeRole || emp.position}
                            </span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1.5">
                            <span className="text-sm">{catConfig?.icon || '✨'}</span>
                            <span className={`font-bold ${catConfig?.color || 'text-purple-400'}`}>
                              {assignedCat}
                            </span>
                          </div>
                        )}
                      </td>

                      {/* Services Scope */}
                      <td className="py-3.5 px-4">
                        {isNonService ? (
                          <span className="text-slate-500 italic text-[11px]">
                            No salon services &bull; Administrative scope only
                          </span>
                        ) : (
                          <div className="space-y-1">
                            <div className="flex items-center gap-1.5">
                              <span className="px-1.5 py-0.5 rounded bg-[#1e1e26] text-purple-300 font-mono font-bold text-[10px]">
                                {eligibleServices.length} services in {assignedCat}
                              </span>
                              <span className="text-[10px] text-slate-400">
                                (Restricted to {assignedCat})
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400 truncate max-w-xs">
                              {eligibleServices.slice(0, 3).map((s) => s.name).join(', ')}
                              {eligibleServices.length > 3 && ` +${eligibleServices.length - 3} more`}
                            </div>
                          </div>
                        )}
                      </td>

                      {/* Commission Rates */}
                      <td className="py-3.5 px-4 text-center">
                        {isNonService ? (
                          <span className="text-slate-500 font-mono text-[11px]">-</span>
                        ) : (
                          <div className="font-mono text-xs">
                            <span className="font-bold text-emerald-400">
                              {emp.saleCommissionRate || 10}%
                            </span>
                            <span className="text-slate-500 text-[10px] ml-1">
                              (prod: {emp.prodSaleCommission || 5}%)
                            </span>
                          </div>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            emp.status === 'Active'
                              ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40'
                              : 'bg-amber-950/60 text-amber-300 border border-amber-800/40'
                          }`}
                        >
                          {emp.status}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(emp)}
                            className="px-2.5 py-1 text-xs font-semibold bg-purple-600 hover:bg-purple-700 text-white rounded-lg flex items-center gap-1 cursor-pointer transition-colors shadow-xs"
                            title="Edit Role / Category Setting"
                          >
                            <Edit2 className="w-3 h-3" />
                            <span>Configure</span>
                          </button>

                          {onOpenEmployee && (
                            <button
                              type="button"
                              onClick={() => onOpenEmployee(emp.employeeId)}
                              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-[#202028] transition-colors cursor-pointer"
                              title="View Full Employee Profile"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ----------------- CONFIGURE CATEGORY / ROLE MODAL ----------------- */}
      {editingEmployee && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#141419] border border-[#2b2b36] rounded-2xl w-full max-w-xl text-white shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="px-6 py-4 border-b border-[#252530] flex items-center justify-between bg-[#191922]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/40 text-purple-300 flex items-center justify-center">
                  <Settings className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Configure Employee Category &amp; Role</h3>
                  <p className="text-xs text-slate-400 font-mono">
                    {editingEmployee.employeeName} &bull; {editingEmployee.employeeId}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingEmployee(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSaveRole} className="p-6 space-y-5">
              {/* Step 1: Classification Type (Service Provider vs Non-Service) */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                  1. Staff Classification *
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setEditRoleType('service')}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      editRoleType === 'service'
                        ? 'bg-purple-950/50 border-purple-500 text-white shadow-md'
                        : 'bg-[#181820] border-[#292934] text-slate-300 hover:bg-[#20202a]'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Scissors className="w-4 h-4 text-purple-400" />
                      <span className="font-bold text-xs">Salon Service Provider</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Performs client appointments under 1 designated specialty category.
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setEditRoleType('non_service')}
                    className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      editRoleType === 'non_service'
                        ? 'bg-purple-950/50 border-purple-500 text-white shadow-md'
                        : 'bg-[#181820] border-[#292934] text-slate-300 hover:bg-[#20202a]'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Building className="w-4 h-4 text-blue-400" />
                      <span className="font-bold text-xs">Non-Service / Admin</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Manager, HR, Receptionist, Accountant, Cleaner (no salon services).
                    </p>
                  </button>
                </div>
              </div>

              {/* Step 2A: Service Employee Category Selection */}
              {editRoleType === 'service' ? (
                <div className="space-y-3 p-4 rounded-xl bg-[#181822] border border-purple-500/30">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold uppercase tracking-wider text-purple-300 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>2. Assign Exclusive Service Category (1 Category Only) *</span>
                    </label>
                  </div>

                  <p className="text-[11px] text-slate-400">
                    Cosmos strict rule: This specialist will only be booked or assigned for services in this chosen category.
                  </p>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1">
                    {SALON_CATEGORIES.map((cat) => {
                      const isSelected = editCategory === cat.id;

                      return (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() => setEditCategory(cat.id)}
                          className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-purple-600 border-purple-400 text-white font-bold shadow-md'
                              : 'bg-[#121216] border-[#2b2b36] text-slate-300 hover:bg-[#1e1e28]'
                          }`}
                        >
                          <div className="text-base mb-1">{cat.icon}</div>
                          <div className="text-xs font-bold">{cat.label}</div>
                          <div className="text-[10px] opacity-75 font-mono">Exclusive</div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Preview of allowed services */}
                  <div className="pt-2 border-t border-[#2a2a38]">
                    <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider mb-1.5">
                      Services allowed under {editCategory} ({catalogue.filter((s) => s.category === editCategory && s.isActive).length} services):
                    </div>
                    <div className="flex flex-wrap gap-1 max-h-24 overflow-y-auto">
                      {catalogue
                        .filter((s) => s.category === editCategory && s.isActive)
                        .map((s) => (
                          <span
                            key={s.id}
                            className="px-2 py-0.5 rounded-md bg-[#121216] border border-[#2b2b38] text-[10px] text-slate-300 font-mono"
                          >
                            {s.name} &bull; QAR {formatCurrency(s.price)}
                          </span>
                        ))}
                    </div>
                  </div>
                </div>
              ) : (
                /* Step 2B: Non-Service Role Selection */
                <div className="space-y-3 p-4 rounded-xl bg-[#181822] border border-blue-500/30">
                  <label className="block text-xs font-bold uppercase tracking-wider text-blue-300">
                    2. Select Non-Service Job Role *
                  </label>

                  <div className="space-y-2">
                    {NON_SERVICE_ROLES.map((role) => {
                      const isSelected = editNonServiceRole === role.id;

                      return (
                        <label
                          key={role.id}
                          onClick={() => setEditNonServiceRole(role.id)}
                          className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                            isSelected
                              ? 'bg-blue-950/50 border-blue-500 text-white shadow-md'
                              : 'bg-[#121216] border-[#2b2b36] text-slate-300 hover:bg-[#1c1c24]'
                          }`}
                        >
                          <input
                            type="radio"
                            name="nonServiceRole"
                            checked={isSelected}
                            onChange={() => setEditNonServiceRole(role.id)}
                            className="accent-blue-500 mt-1"
                          />
                          <div>
                            <div className="text-xs font-bold flex items-center gap-1.5">
                              <span>{role.icon}</span>
                              <span>{role.label}</span>
                            </div>
                            <p className="text-[11px] text-slate-400 mt-0.5">
                              {role.description}
                            </p>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Commission Rates (For service providers only) */}
              {editRoleType === 'service' && (
                <div className="grid grid-cols-2 gap-3 bg-[#181820] p-3.5 rounded-xl border border-[#292936]">
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                      Service Commission Rate (%)
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={editCommissionRate}
                      onChange={(e) => setEditCommissionRate(parseFloat(e.target.value) || 0)}
                      className="w-full text-xs p-2 bg-[#121216] border border-[#2e2e38] rounded-lg text-emerald-400 font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">
                      Product Commission Rate (%)
                    </label>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={editProdCommissionRate}
                      onChange={(e) => setEditProdCommissionRate(parseFloat(e.target.value) || 0)}
                      className="w-full text-xs p-2 bg-[#121216] border border-[#2e2e38] rounded-lg text-emerald-400 font-mono font-bold"
                    />
                  </div>
                </div>
              )}

              {/* Footer */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#252530]">
                <button
                  type="button"
                  onClick={() => setEditingEmployee(null)}
                  disabled={isSubmitting}
                  className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-[#22222a] hover:bg-[#2b2b35] rounded-xl cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 text-xs font-bold text-slate-950 bg-white hover:bg-slate-100 rounded-xl transition-all shadow-md cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isSubmitting ? 'Saving...' : 'Apply Role & Category Settings'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
