import React, { useState, useMemo } from 'react';
import { UserCheck, Eye, Search, AlertCircle } from 'lucide-react';
import { Employee } from '../types';
import { formatCurrency } from '../services/db';

interface UnemployedViewProps {
  employees: Employee[];
  onOpenEmployee: (empId: string) => void;
  onReactivate: (empId: string) => void;
}

export const UnemployedView: React.FC<UnemployedViewProps> = ({
  employees,
  onOpenEmployee,
  onReactivate,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const formerEmployees = useMemo(() => {
    return employees.filter((emp) => emp.status === 'Unemployed');
  }, [employees]);

  const filtered = useMemo(() => {
    if (!searchTerm) return formerEmployees;
    const term = searchTerm.toLowerCase();
    return formerEmployees.filter(
      (e) =>
        e.employeeName.toLowerCase().includes(term) ||
        e.employeeId.toLowerCase().includes(term) ||
        e.position.toLowerCase().includes(term) ||
        (e.reasonForLeaving && e.reasonForLeaving.toLowerCase().includes(term))
    );
  }, [formerEmployees, searchTerm]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <span>Unemployed &amp; Former Employees Archive</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Archived records, exit reasons, and outstanding liabilities for former staff members.
          </p>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search former staff..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-xs text-left border-collapse">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Employee ID</th>
                <th className="py-2.5 px-3">Full Name</th>
                <th className="py-2.5 px-3">Company</th>
                <th className="py-2.5 px-3">Position</th>
                <th className="py-2.5 px-3">Last Working Date</th>
                <th className="py-2.5 px-3">Reason for Leaving</th>
                <th className="py-2.5 px-3 text-right">Outstanding Balance</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((emp) => (
                <tr
                  key={emp.employeeId}
                  onClick={() => onOpenEmployee(emp.employeeId)}
                  className="hover:bg-slate-50 cursor-pointer transition-colors"
                >
                  <td className="py-3 px-3 font-bold font-mono text-slate-900">{emp.employeeId}</td>
                  <td className="py-3 px-3 font-semibold text-slate-900">{emp.employeeName}</td>
                  <td className="py-3 px-3 text-slate-600">{emp.company}</td>
                  <td className="py-3 px-3 text-slate-700">{emp.position}</td>
                  <td className="py-3 px-3 font-mono text-slate-600">
                    {emp.lastWorkingDate || 'Not specified'}
                  </td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-amber-50 text-amber-800 border border-amber-200/60">
                      {emp.reasonForLeaving || 'Resigned'}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right font-bold font-mono tabular-nums text-rose-600">
                    QAR {formatCurrency(emp.outstanding)}
                  </td>
                  <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => onOpenEmployee(emp.employeeId)}
                        className="px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors flex items-center gap-1"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View</span>
                      </button>
                      <button
                        onClick={() => onReactivate(emp.employeeId)}
                        className="px-2.5 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded transition-colors flex items-center gap-1"
                        title="Reactivate employee and return to active directory"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Reactivate</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {filtered.length === 0 && (
            <div className="p-12 text-center text-slate-400">
              <AlertCircle className="w-8 h-8 mx-auto text-slate-300 mb-2" />
              <p className="text-sm font-medium">No former / unemployed staff in archive.</p>
              <p className="text-xs text-slate-400 mt-1">
                When employees resign or finish contract, use "Move to Former" from the employee profile.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
