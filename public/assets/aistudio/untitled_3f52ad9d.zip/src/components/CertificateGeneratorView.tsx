import React, { useState, useEffect } from 'react';
import { FileText, Printer, Save, Archive, Eye, CheckSquare, Square, Building2, User } from 'lucide-react';
import { Employee, Certificate, SystemSettings } from '../types';
import { db, formatCurrency, formatDate } from '../services/db';

interface CertificateGeneratorViewProps {
  employees: Employee[];
  settings: SystemSettings;
  onRefresh: () => void;
  onNavigateArchive: () => void;
  onTriggerPrint: (cert: Certificate) => void;
}

export const CertificateGeneratorView: React.FC<CertificateGeneratorViewProps> = ({
  employees,
  settings,
  onRefresh,
  onNavigateArchive,
  onTriggerPrint,
}) => {
  const activeEmployees = employees.filter((e) => e.status !== 'Unemployed');

  const [certType, setCertType] = useState<'salary' | 'employment'>('salary');
  const [selectedEmpId, setSelectedEmpId] = useState(activeEmployees[0]?.employeeId || '');
  const [correspondingDate, setCorrespondingDate] = useState(new Date().toISOString().slice(0, 10));
  const [reference, setReference] = useState('');
  const [recipient, setRecipient] = useState('Qatar Islamic Bank');
  const [customRecipient, setCustomRecipient] = useState('');

  // Salary inclusions
  const [includeBasic, setIncludeBasic] = useState(true);
  const [includeFood, setIncludeFood] = useState(true);
  const [includeTransport, setIncludeTransport] = useState(true);
  const [includeCar, setIncludeCar] = useState(true);
  const [includeOther, setIncludeOther] = useState(true);

  // Signatory
  const [signatoryName, setSignatoryName] = useState(settings.signatoryName || 'ATYRGUL AIAZOVA');
  const [signatoryTitle, setSignatoryTitle] = useState(settings.signatoryTitle || 'Authorized Manager');

  // Generate Reference
  useEffect(() => {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + 1;
    const counter = settings.certCounter || 1;
    setReference(`Certificates/${year}/${month}/${String(counter).padStart(4, '0')}`);
  }, [settings.certCounter]);

  // Selected Employee
  const currentEmp = employees.find((e) => e.employeeId === selectedEmpId) || activeEmployees[0];

  const actualRecipient = recipient === 'custom' ? customRecipient || 'To Whom It May Concern' : recipient;

  // Build Salary Table Items
  const salaryItems: { label: string; amount: number }[] = [];
  let totalCertificateSalary = 0;

  if (currentEmp) {
    if (includeBasic && Number(currentEmp.basicSalary) > 0) {
      salaryItems.push({ label: 'Basic Salary', amount: Number(currentEmp.basicSalary) });
      totalCertificateSalary += Number(currentEmp.basicSalary);
    }
    if (includeFood && Number(currentEmp.foodAllowance) > 0) {
      salaryItems.push({ label: 'Food Allowance', amount: Number(currentEmp.foodAllowance) });
      totalCertificateSalary += Number(currentEmp.foodAllowance);
    }
    if (includeTransport && Number(currentEmp.transportAllowance) > 0) {
      salaryItems.push({ label: 'Transportation Allowance', amount: Number(currentEmp.transportAllowance) });
      totalCertificateSalary += Number(currentEmp.transportAllowance);
    }
    if (includeCar && Number(currentEmp.carOperationAllowance) > 0) {
      salaryItems.push({ label: 'Car Operation Allowance', amount: Number(currentEmp.carOperationAllowance) });
      totalCertificateSalary += Number(currentEmp.carOperationAllowance);
    }
    if (includeOther && Number(currentEmp.otherAllowance) > 0) {
      salaryItems.push({ label: 'Other Allowance', amount: Number(currentEmp.otherAllowance) });
      totalCertificateSalary += Number(currentEmp.otherAllowance);
    }
  }

  const handleSaveAndPrint = async () => {
    if (!currentEmp) {
      alert('Please select an employee.');
      return;
    }

    const cert: Certificate = {
      certId: `CERT-${Date.now()}`,
      certType,
      certTypeName: certType === 'salary' ? 'Salary Certificate' : 'Certificate of Employment',
      employeeId: currentEmp.employeeId,
      employeeName: currentEmp.employeeName,
      employeePosition: currentEmp.position,
      employeeQid: currentEmp.residencyQid,
      employeeNationality: currentEmp.nationality,
      employeeJoiningDate: currentEmp.joiningDate,
      recipient: actualRecipient,
      correspondingDate,
      reference,
      signatoryName,
      signatoryTitle,
      salaryData: {
        basicSalary: currentEmp.basicSalary,
        foodAllowance: currentEmp.foodAllowance,
        transportAllowance: currentEmp.transportAllowance,
        carOperationAllowance: currentEmp.carOperationAllowance,
        otherAllowance: currentEmp.otherAllowance,
        totalSalary: currentEmp.totalSalary,
      },
      includeBasic,
      includeFood,
      includeTransport,
      includeCar,
      includeOther,
      createdAt: new Date().toISOString(),
    };

    await db.saveCertificate(cert);
    onRefresh();
    onTriggerPrint(cert);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <span>Official Certificate Generator</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Create verified Qatar salary certificates and employment confirmation letters with company letterhead, Qatar bank address, and official manager sign-off.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={onNavigateArchive}
            className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
          >
            <Archive className="w-3.5 h-3.5 text-slate-600" />
            <span>View Archive</span>
          </button>
          <button
            onClick={handleSaveAndPrint}
            className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
          >
            <Printer className="w-4 h-4" />
            <span>Save &amp; Print Certificate</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Configuration Controls */}
        <div className="lg:col-span-5 space-y-5">
          {/* Form Panel */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 pb-2 border-b border-slate-100">
              Certificate Configuration
            </h3>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Certificate Type *
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setCertType('salary')}
                  className={`py-2 px-3 text-xs font-semibold rounded-lg border transition-all ${
                    certType === 'salary'
                      ? 'bg-blue-50 border-blue-600 text-blue-700'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Salary Certificate
                </button>
                <button
                  type="button"
                  onClick={() => setCertType('employment')}
                  className={`py-2 px-3 text-xs font-semibold rounded-lg border transition-all ${
                    certType === 'employment'
                      ? 'bg-blue-50 border-blue-600 text-blue-700'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  Certificate of Employment
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Employee *
              </label>
              <select
                value={selectedEmpId}
                onChange={(e) => setSelectedEmpId(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-medium"
              >
                {activeEmployees.map((e) => (
                  <option key={e.employeeId} value={e.employeeId}>
                    {e.employeeName} ({e.employeeId}) - {e.position}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Issue Date *
                </label>
                <input
                  type="date"
                  value={correspondingDate}
                  onChange={(e) => setCorrespondingDate(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Reference No. (Auto)
                </label>
                <input
                  type="text"
                  value={reference}
                  readOnly
                  className="w-full text-xs p-2 bg-slate-100 border border-slate-200 rounded-lg font-mono text-slate-600 font-bold"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Recipient (To:) *
              </label>
              <select
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-medium"
              >
                <option value="Qatar Islamic Bank">Qatar Islamic Bank (QIB)</option>
                <option value="Commercial Bank of Qatar">Commercial Bank of Qatar (CBQ)</option>
                <option value="Qatar National Bank">Qatar National Bank (QNB)</option>
                <option value="Doha Bank">Doha Bank (DB)</option>
                <option value="Masraf Al Rayan">Masraf Al Rayan (MAR)</option>
                <option value="National Bank of Kuwait">National Bank of Kuwait (NBK)</option>
                <option value="To Whom It May Concern">To Whom It May Concern</option>
                <option value="custom">✏️ Other / Custom Recipient...</option>
              </select>

              {recipient === 'custom' && (
                <input
                  type="text"
                  placeholder="Enter custom recipient organization or bank..."
                  value={customRecipient}
                  onChange={(e) => setCustomRecipient(e.target.value)}
                  className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg mt-2"
                />
              )}
            </div>

            {/* Salary components toggles (only if salary cert) */}
            {certType === 'salary' && (
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <label className="block text-xs font-bold text-slate-800">
                  Included Salary Package Allowances
                </label>
                <div className="space-y-1.5 text-xs text-slate-700">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeBasic}
                      onChange={(e) => setIncludeBasic(e.target.checked)}
                      className="rounded text-blue-600 w-4 h-4"
                    />
                    <span>Basic Salary ({formatCurrency(currentEmp?.basicSalary)} QAR)</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeFood}
                      onChange={(e) => setIncludeFood(e.target.checked)}
                      className="rounded text-blue-600 w-4 h-4"
                    />
                    <span>Food Allowance ({formatCurrency(currentEmp?.foodAllowance)} QAR)</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeTransport}
                      onChange={(e) => setIncludeTransport(e.target.checked)}
                      className="rounded text-blue-600 w-4 h-4"
                    />
                    <span>Transportation Allowance ({formatCurrency(currentEmp?.transportAllowance)} QAR)</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeCar}
                      onChange={(e) => setIncludeCar(e.target.checked)}
                      className="rounded text-blue-600 w-4 h-4"
                    />
                    <span>Car Operation Allowance ({formatCurrency(currentEmp?.carOperationAllowance)} QAR)</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={includeOther}
                      onChange={(e) => setIncludeOther(e.target.checked)}
                      className="rounded text-blue-600 w-4 h-4"
                    />
                    <span>Other Allowances ({formatCurrency(currentEmp?.otherAllowance)} QAR)</span>
                  </label>
                </div>
              </div>
            )}

            {/* Authorized Signatory */}
            <div className="pt-2 border-t border-slate-100 grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Signatory Name
                </label>
                <input
                  type="text"
                  value={signatoryName}
                  onChange={(e) => setSignatoryName(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg font-bold"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                  Signatory Title
                </label>
                <input
                  type="text"
                  value={signatoryTitle}
                  onChange={(e) => setSignatoryTitle(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Live Official Letter Preview */}
        <div className="lg:col-span-7 space-y-2">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-slate-400" />
              <span>Official Document Letterhead Preview</span>
            </span>
            <span className="text-[11px] text-slate-400 font-mono">A4 Portrait Format</span>
          </div>

          <div className="bg-white p-8 sm:p-10 rounded-xl border border-slate-200 shadow-md font-serif text-slate-900 leading-relaxed min-h-[640px] relative">
            {/* Salon Official Header */}
            <div className="text-center pb-4 border-b-2 border-slate-900 mb-6">
              <h2 className="text-xl font-bold tracking-wider text-slate-900 uppercase">
                {settings.companyName || 'COSMOS BEAUTY SALON'}
              </h2>
              <p className="text-xs text-slate-600 font-sans mt-0.5">
                {settings.companyAddress} · Tel: {settings.companyPhone} · {settings.companyEmail}
              </p>
              <h1 className="text-sm font-bold tracking-widest text-slate-900 uppercase mt-3 font-sans">
                Human Resources Department
              </h1>
            </div>

            {/* Letter Meta */}
            <div className="flex justify-between items-center text-xs text-slate-800 mb-6 font-sans">
              <div>
                <strong>Corresponding to:</strong> {formatDate(correspondingDate)}
              </div>
              <div>
                <strong>Reference:</strong> <span className="font-mono">{reference}</span>
              </div>
            </div>

            {/* Subject */}
            <div className="text-center font-bold text-base uppercase underline tracking-wide my-6 font-sans">
              {certType === 'salary' ? 'SALARY CERTIFICATE' : 'CERTIFICATE OF EMPLOYMENT / WORK'}
            </div>

            {/* Addressed To */}
            <div className="font-bold text-sm mb-4 font-sans text-slate-900">
              To: {actualRecipient}
            </div>

            {/* Letter Body */}
            <div className="text-xs text-justify space-y-3.5 leading-relaxed text-slate-800">
              {certType === 'salary' ? (
                <>
                  <p>
                    This is to certify that Ms./Mr.{' '}
                    <strong>{currentEmp?.employeeName || 'Staff Member'}</strong>, holder of QID
                    No. <strong>{currentEmp?.residencyQid || 'N/A'}</strong>, Nationality:{' '}
                    <strong>{currentEmp?.nationality || 'N/A'}</strong>, Employee ID:{' '}
                    <strong>{currentEmp?.employeeId || 'N/A'}</strong>, has been employed with{' '}
                    <strong>{settings.companyName || 'COSMOS BEAUTY SALON'}</strong> since{' '}
                    <strong>{formatDate(currentEmp?.joiningDate) || 'N/A'}</strong> in the capacity
                    of <strong>{currentEmp?.position || 'N/A'}</strong>.
                  </p>
                  <p>
                    We further certify that her/his monthly remuneration and breakdown of basic
                    allowances is structured as follows:
                  </p>

                  {/* Salary Table */}
                  <table className="w-full text-xs border border-slate-900 border-collapse my-4 font-sans">
                    <thead>
                      <tr className="bg-slate-100 border-b border-slate-900 text-slate-900">
                        <th className="p-2 text-left font-bold border-r border-slate-900">
                          Remuneration Component
                        </th>
                        <th className="p-2 text-right font-bold w-40">Monthly Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-300">
                      {salaryItems.map((item, idx) => (
                        <tr key={idx}>
                          <td className="p-2 border-r border-slate-900">{item.label}</td>
                          <td className="p-2 text-right font-mono tabular-nums">
                            QAR {formatCurrency(item.amount)}
                          </td>
                        </tr>
                      ))}
                      <tr className="font-bold bg-slate-50 border-t-2 border-slate-900 text-slate-900">
                        <td className="p-2 border-r border-slate-900">Total Monthly Salary</td>
                        <td className="p-2 text-right font-mono tabular-nums text-slate-900">
                          QAR {formatCurrency(totalCertificateSalary)}
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  <p>
                    This certificate is issued upon the request of the employee for submission to
                    the bank without any financial liability or commitment on our part.
                  </p>
                </>
              ) : (
                <>
                  <p>
                    This is to certify that Ms./Mr.{' '}
                    <strong>{currentEmp?.employeeName || 'Staff Member'}</strong>, holder of QID
                    No. <strong>{currentEmp?.residencyQid || 'N/A'}</strong>, Nationality:{' '}
                    <strong>{currentEmp?.nationality || 'N/A'}</strong>, Employee ID:{' '}
                    <strong>{currentEmp?.employeeId || 'N/A'}</strong>, has been working with{' '}
                    <strong>{settings.companyName || 'COSMOS BEAUTY SALON'}</strong> since{' '}
                    <strong>{formatDate(currentEmp?.joiningDate) || 'N/A'}</strong> in the position of{' '}
                    <strong>{currentEmp?.position || 'N/A'}</strong>.
                  </p>
                  <p>
                    During her/his tenure with us, she/he has maintained high professional standards
                    and dedication towards salon operations and client care.
                  </p>
                  <p>
                    This certificate is issued upon her/his request for whatever lawful and official
                    purpose it may serve.
                  </p>
                </>
              )}

              <p className="pt-2 text-[11px] text-slate-600 font-sans italic">
                Valid for {settings.certValidity || 1} month(s) from the date of issuance.
              </p>
            </div>

            {/* Official Stamp & Signatory Block */}
            <div className="mt-14 pt-6 flex justify-between items-end text-xs font-sans">
              <div className="text-center w-40">
                <div className="w-24 h-24 mx-auto border-2 border-dashed border-slate-300 rounded-lg flex items-center justify-center text-[11px] text-slate-400">
                  Official Seal &amp; Stamp
                </div>
                <div className="mt-2 text-[11px] text-slate-500 font-semibold">
                  {settings.companyName || 'COSMOS BEAUTY SALON'}
                </div>
              </div>

              <div className="text-center w-52">
                <div className="border-t border-slate-900 pt-2 font-bold text-slate-900 text-xs">
                  {signatoryName}
                </div>
                <div className="text-[11px] text-slate-600 font-medium">{signatoryTitle}</div>
                <div className="text-[10px] text-slate-400 mt-1">Authorized HR Signatory</div>
              </div>
            </div>

            {/* Footer Barcode / Ref */}
            <div className="mt-8 pt-3 border-t border-slate-100 text-[10px] text-slate-400 font-mono text-right flex justify-between items-center">
              <span>Authentic Document Verification</span>
              <span>Ref: {reference} · System Verified</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
