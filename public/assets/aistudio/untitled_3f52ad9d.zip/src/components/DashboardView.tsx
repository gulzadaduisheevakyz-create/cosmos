import React, { useState, useMemo } from 'react';
import {
  Users,
  AlertTriangle,
  Coins,
  Wallet,
  CheckCircle,
  FileSpreadsheet,
  Search,
  Eye,
  Plus,
  RefreshCw,
  Clock,
  ShieldAlert,
  ReceiptText,
} from 'lucide-react';
import { Employee } from '../types';
import { formatCurrency, maskIBAN, calculateDaysRemaining, calculateEmployeeCommissions } from '../services/db';

interface DashboardViewProps {
  employees: Employee[];
  onOpenEmployee: (empId: string) => void;
  onNavigateAdd: () => void;
  onNavigateDailySales?: () => void;
  onLoadSample: () => void;
  onExportExcel: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  employees,
  onOpenEmployee,
  onNavigateAdd,
  onNavigateDailySales,
  onLoadSample,
  onExportExcel,
}) => {

  const [searchTerm, setSearchTerm] = useState('');

  // Stats calculation
  const stats = useMemo(() => {
    let active = 0;
    let inactive = 0;
    let basic = 0;
    let allowances = 0;
    let net = 0;
    let unpaid = 0;
    let expiringPassports = 0;
    let expiringQids = 0;

    employees.forEach((emp) => {
      const isUnemployed = emp.status === 'Unemployed';
      if (!isUnemployed) {
        active++;
      } else {
        inactive++;
      }

      const basicSal = Number(emp.basicSalary) || 0;
      const allw =
        (Number(emp.foodAllowance) || 0) +
        (Number(emp.transportAllowance) || 0) +
        (Number(emp.carOperationAllowance) || 0) +
        (Number(emp.otherAllowance) || 0) +
        (Number(emp.limitedTransport) || 0);

      const totSal = basicSal + allw;
      basic += basicSal;
      allowances += allw;
      net += totSal;
      unpaid += Number(emp.outstanding) || 0;

      const pDays = calculateDaysRemaining(emp.passportExpiry);
      const qDays = calculateDaysRemaining(emp.residencyExpiry);

      if (pDays < 90) expiringPassports++;
      if (qDays < 90) expiringQids++;
    });

    return {
      active,
      inactive,
      basic,
      allowances,
      net,
      unpaid,
      expiringPassports,
      expiringQids,
    };
  }, [employees]);

  // Filtered employees for table
  const filteredEmployees = useMemo(() => {
    return employees.filter((emp) => {
      if (emp.status === 'Unemployed') return false; // Dashboard focuses on active workforce
      if (!searchTerm) return true;
      const term = searchTerm.toLowerCase();
      return (
        emp.employeeName.toLowerCase().includes(term) ||
        emp.employeeId.toLowerCase().includes(term) ||
        emp.position.toLowerCase().includes(term) ||
        emp.company.toLowerCase().includes(term) ||
        emp.residencyQid.toLowerCase().includes(term) ||
        emp.passportNumber.toLowerCase().includes(term) ||
        emp.nationality.toLowerCase().includes(term) ||
        emp.payerBank.toLowerCase().includes(term)
      );
    });
  }, [employees, searchTerm]);

  return (
    <div className="space-y-6">
      {/* Action Header */}
      <div className="bg-white p-4 sm:p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight">
            Payroll &amp; Human Resources Overview
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time workforce analytics, Qatar compliance tracking, salary packages, and active contracts.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search staff, QID, ID, bank..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
            />
          </div>

          <button
            onClick={onExportExcel}
            className="px-3 py-2 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export Excel</span>
          </button>

          {onNavigateDailySales && (
            <button
              onClick={onNavigateDailySales}
              className="px-3.5 py-2 text-xs font-semibold text-purple-900 bg-purple-50 hover:bg-purple-100 border border-purple-200 rounded-lg transition-colors flex items-center gap-1.5 shadow-2xs shrink-0"
            >
              <ReceiptText className="w-3.5 h-3.5 text-purple-600" />
              <span>Daily Sales Report</span>
            </button>
          )}

          <button
            onClick={onNavigateAdd}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Employee</span>
          </button>
        </div>
      </div>


      {/* 8 Metric KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Active Staff */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Active Staff
            </div>
            <div className="text-xl font-bold text-slate-900 tabular-nums">
              {stats.active}
            </div>
          </div>
        </div>

        {/* Card 2: Former / On Leave */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Former / Inactive
            </div>
            <div className="text-xl font-bold text-slate-900 tabular-nums">
              {stats.inactive}
            </div>
          </div>
        </div>

        {/* Card 3: Basic Salaries */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
            <Coins className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Total Basic Salaries
            </div>
            <div className="text-lg font-bold text-slate-900 tabular-nums">
              QAR {formatCurrency(stats.basic)}
            </div>
          </div>
        </div>

        {/* Card 4: Total Allowances */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-cyan-50 text-cyan-600 flex items-center justify-center shrink-0">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Total Allowances
            </div>
            <div className="text-lg font-bold text-slate-900 tabular-nums">
              QAR {formatCurrency(stats.allowances)}
            </div>
          </div>
        </div>

        {/* Card 5: Net Payroll */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Total Monthly Net
            </div>
            <div className="text-lg font-bold text-emerald-600 tabular-nums">
              QAR {formatCurrency(stats.net)}
            </div>
          </div>
        </div>

        {/* Card 6: Outstanding Balance */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Unpaid / Outstanding
            </div>
            <div className="text-lg font-bold text-rose-600 tabular-nums">
              QAR {formatCurrency(stats.unpaid)}
            </div>
          </div>
        </div>

        {/* Card 7: Expiring Passports */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Passports (&lt;90 Days)
            </div>
            <div className="text-xl font-bold text-amber-600 tabular-nums">
              {stats.expiringPassports}
            </div>
          </div>
        </div>

        {/* Card 8: Expiring QIDs */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              QIDs (&lt;90 Days)
            </div>
            <div className="text-xl font-bold text-rose-600 tabular-nums">
              {stats.expiringQids}
            </div>
          </div>
        </div>
      </div>

      {/* Main Wide Data Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-slate-900">
              Master Payroll &amp; Employment Schedule
            </h3>
            <span className="text-xs text-slate-500 font-mono">
              ({filteredEmployees.length} employees)
            </span>
          </div>
          <div className="text-xs text-slate-400">
            Scroll horizontally to inspect full banking, allowances, and sales targets →
          </div>
        </div>

        <div className="overflow-x-auto max-h-[600px] custom-scrollbar">
          <table className="w-full text-xs text-left border-collapse min-w-[3400px]">
            <thead className="bg-slate-50 text-slate-600 font-semibold sticky top-0 z-10 border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3 whitespace-nowrap bg-slate-50">Actions</th>
                <th className="py-2.5 px-3 whitespace-nowrap">No</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Employee ID</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Employee's Name</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Company</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Duty</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Accommodation</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Position</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Contract No.</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Contract Type</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Joining Date</th>
                <th className="py-2.5 px-3 whitespace-nowrap">End Contract</th>
                <th className="py-2.5 px-3 whitespace-nowrap">MPH</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Expire MPH</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Nationality</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Mobile</th>
                <th className="py-2.5 px-3 whitespace-nowrap">WhatsApp</th>
                <th className="py-2.5 px-3 whitespace-nowrap">E-mail</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Passport Number</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Passport Expiry</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Passport Days</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Residency QID</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Residency Expiry</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Residency Days</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Payer Bank</th>
                <th className="py-2.5 px-3 whitespace-nowrap font-mono">Payee IBAN</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Basic Salary</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Food Allowance</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Transport Allow.</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Car Operation</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Other Allowance</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Limited Transport</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right font-bold text-slate-900 bg-slate-100/60">
                  Total Salaries
                </th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right text-rose-600">
                  Deduction Current
                </th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Deduction Future</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Tips</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right text-rose-600">
                  Outstanding
                </th>
                <th className="py-2.5 px-3 whitespace-nowrap">Annual Leave Paid</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Salaries &amp; Wages</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Sale Comm %</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Sale Target</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Actual Sales</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Target Sales</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Prod Comm %</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Prod Target</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Prod Total</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Business Rate %</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Business Gross</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right">Business Bonus</th>
                <th className="py-2.5 px-3 whitespace-nowrap text-right font-bold text-amber-800 bg-amber-50/50">Total Commission</th>
                <th className="py-2.5 px-3 whitespace-nowrap">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredEmployees.map((emp, index) => {
                const pDays = calculateDaysRemaining(emp.passportExpiry);
                const qDays = calculateDaysRemaining(emp.residencyExpiry);
                const comms = calculateEmployeeCommissions(emp);

                return (
                  <tr
                    key={emp.employeeId}
                    onClick={() => onOpenEmployee(emp.employeeId)}
                    className="hover:bg-blue-50/40 cursor-pointer transition-colors"
                  >
                    <td className="py-2 px-3 whitespace-nowrap sticky left-0 bg-white z-0 group-hover:bg-blue-50/40">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenEmployee(emp.employeeId);
                        }}
                        className="px-2.5 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors flex items-center gap-1"
                      >
                        <Eye className="w-3 h-3" />
                        <span>View</span>
                      </button>
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-slate-500 font-mono">
                      {emp.no || index + 1}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-bold text-slate-900 font-mono">
                      {emp.employeeId}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-semibold text-slate-900">
                      {emp.employeeName}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-slate-700">
                      {emp.company}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700">
                        {emp.duty}
                      </span>
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-slate-600">
                      {emp.accommodation}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-slate-800">
                      {emp.position}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-mono text-slate-500">
                      {emp.contractNo}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-slate-600">
                      {emp.contractType}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-mono text-slate-600">
                      {emp.joiningDate}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-mono text-slate-600">
                      {emp.endContract}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap">
                      <span
                        className={`px-1.5 py-0.5 text-[10px] font-semibold rounded ${
                          emp.mph === 'YES'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {emp.mph}
                      </span>
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-mono text-slate-500">
                      {emp.expireMph || '-'}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-slate-700">
                      {emp.nationality}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-mono text-slate-600">
                      {emp.mobile}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-mono text-slate-600">
                      {emp.whatsapp}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-slate-600">
                      {emp.email}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-mono text-slate-800">
                      {emp.passportNumber}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-mono text-slate-600">
                      {emp.passportExpiry}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                          pDays < 90
                            ? 'bg-rose-100 text-rose-800'
                            : pDays < 180
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        Day {pDays}
                      </span>
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-mono text-slate-800">
                      {emp.residencyQid}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-mono text-slate-600">
                      {emp.residencyExpiry}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                          qDays < 90
                            ? 'bg-rose-100 text-rose-800'
                            : qDays < 180
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        Day {qDays}
                      </span>
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-slate-800 font-medium">
                      {emp.payerBank}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap font-mono text-slate-600 tracking-wider">
                      {maskIBAN(emp.iban)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.basicSalary)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.foodAllowance)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.transportAllowance)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.carOperationAllowance)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.otherAllowance)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.limitedTransport)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums font-bold text-slate-900 bg-slate-100/60">
                      {formatCurrency(emp.totalSalary)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums text-rose-600 font-medium">
                      {formatCurrency(emp.deductionCurrent)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums text-slate-500">
                      {formatCurrency(emp.deductionFuture)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums text-emerald-600">
                      {formatCurrency(emp.tips)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums font-bold text-rose-600">
                      {formatCurrency(emp.outstanding)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-slate-600">
                      {emp.annualLeavePaid || '-'}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums font-semibold">
                      {formatCurrency(emp.salariesWages)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {emp.saleCommissionRate}%
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.saleTargetRate)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.totalSalesRate)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.targetSales)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {emp.prodSaleCommission}%
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.prodSaleTarget)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.prodTotalSales)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {emp.businessTargetRate}%
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.businessGross)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums">
                      {formatCurrency(emp.businessBonus)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap text-right tabular-nums font-bold text-amber-700 bg-amber-50/40">
                      QAR {formatCurrency(comms.total)}
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        {emp.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {filteredEmployees.length === 0 && (
            <div className="text-center py-12 text-slate-400">
              <p className="text-sm font-medium">No active employees found matching your search.</p>
              <button
                onClick={onLoadSample}
                className="mt-3 px-3 py-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors"
              >
                Reload Sample Salon Staff
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
