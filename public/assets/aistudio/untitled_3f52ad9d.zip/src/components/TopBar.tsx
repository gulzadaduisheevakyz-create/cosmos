import React from 'react';
import { Menu, Plus, RefreshCw, CheckCircle2 } from 'lucide-react';
import { ViewType } from './Sidebar';

interface TopBarProps {
  activeView: ViewType;
  onOpenMobile: () => void;
  onNavigate: (view: ViewType) => void;
  onLoadSample: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeView,
  onOpenMobile,
  onNavigate,
  onLoadSample,
}) => {
  const getBreadcrumbTitle = (view: ViewType): string => {
    switch (view) {
      case 'dashboard':
        return 'Main Payroll & Staff Dashboard';
      case 'add-employee':
        return 'Add New Salon Employee';
      case 'active-employees':
        return 'Active Employees Directory';
      case 'unemployed':
        return 'Unemployed & Former Staff Archive';
      case 'monthly-payroll':
        return 'Monthly Payroll Processing & Batch Approval';
      case 'attendance':
        return 'Attendance & Extra-Time Schedule';
      case 'leave-management':
        return 'Annual Leave & Flight Ticket Management';
      case 'certificate-generator':
        return 'Official Salary & Employment Certificate Generator';
      case 'certificate-archive':
        return 'Certificate Archive & Print Records';
      case 'import-export':
        return 'Excel Import & Export Center';
      case 'backup-restore':
        return 'Database Backup & JSON Restore';
      case 'audit-log':
        return 'System Security & Audit Activity Log';
      case 'settings':
        return 'Company & System Settings';
      default:
        return 'Cosmos HR & Payroll';
    }
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-4 sticky top-0 z-30 shadow-xs">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobile}
          className="lg:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <span>{getBreadcrumbTitle(activeView)}</span>
          </h1>
          <p className="text-[11px] text-slate-400 hidden sm:block">
            COSMOS BEAUTY SALON · Doha, Qatar
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        {/* System ready status */}
        <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 text-emerald-700 text-xs font-medium rounded-full border border-emerald-200/60">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          <span>Database Ready</span>
        </div>

        {/* Load Sample Data Button */}
        <button
          onClick={onLoadSample}
          className="px-2.5 sm:px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
          title="Reload initial salon employee records"
        >
          <RefreshCw className="w-3.5 h-3.5 text-slate-600" />
          <span className="hidden sm:inline">Load Sample Data</span>
        </button>

        {/* Add Employee CTA */}
        {activeView !== 'add-employee' && (
          <button
            onClick={() => onNavigate('add-employee')}
            className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Employee</span>
          </button>
        )}
      </div>
    </header>
  );
};
