import React, { useState } from 'react';
import {
  X,
  User,
  Calendar,
  CreditCard,
  Phone,
  Mail,
  Wallet,
  Star,
  Award,
  AlertCircle,
  FileText,
  Package,
  Plus,
  Clock,
  RotateCcw,
  CheckCircle2,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { Customer, CustomerBooking, DailySaleRecord } from '../types';
import { formatCurrency, formatDate } from '../services/db';

interface ClientDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  client: Customer | null;
  bookings: CustomerBooking[];
  sales: DailySaleRecord[];
  onRebookAppointment?: (client: Customer) => void;
  onRefresh: () => void;
}

type TabType =
  | 'overview'
  | 'appointments'
  | 'sales'
  | 'details'
  | 'items'
  | 'records'
  | 'wallet'
  | 'loyalty'
  | 'reviews';

export const ClientDetailModal: React.FC<ClientDetailModalProps> = ({
  isOpen,
  onClose,
  client,
  bookings,
  sales,
  onRebookAppointment,
  onRefresh,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('overview');

  if (!isOpen || !client) return null;

  // Filter client's bookings and sales
  const clientBookings = bookings.filter(
    (b) =>
      b.customerId === client.id ||
      (b.customerMobile && b.customerMobile.replace(/[^0-9]/g, '').slice(-8) === client.mobile.replace(/[^0-9]/g, '').slice(-8))
  );

  const clientSales = sales.filter(
    (s) =>
      s.customerId === client.id ||
      (s.mobileNumber && s.mobileNumber.replace(/[^0-9]/g, '').slice(-8) === client.mobile.replace(/[^0-9]/g, '').slice(-8))
  );

  const canceledCount = client.canceledCount ?? clientBookings.filter((b) => b.status === 'Cancelled').length;
  const noShowCount = client.noShowCount ?? clientBookings.filter((b) => b.status === 'No-Show').length;
  const completedCount = clientBookings.filter((b) => b.status === 'Completed').length;
  const totalSalesAmount = client.totalSpent || clientSales.reduce((sum, s) => sum + (Number(s.netSales) || 0), 0);

  // Latest / upcoming appointment
  const latestAppointment = clientBookings[0] || null;

  return (
    <div className="fixed inset-0 bg-black/80 z-60 flex items-center justify-center p-2 sm:p-4 backdrop-blur-xs overflow-y-auto font-sans">
      <div className="bg-[#121214] text-slate-100 rounded-2xl shadow-2xl border border-white/10 w-full max-w-4xl my-auto max-h-[92vh] flex flex-col md:flex-row overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Left Sidebar Navigation (Dark Aesthetics matching screenshot 2) */}
        <div className="w-full md:w-56 bg-[#18181c] border-b md:border-b-0 md:border-r border-white/10 p-3 flex flex-col shrink-0">
          <div className="flex items-center justify-between p-2 mb-2 md:mb-4">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-full bg-indigo-600/30 text-indigo-300 font-bold flex items-center justify-center text-sm border border-indigo-500/30">
                {client.name.slice(0, 1).toUpperCase()}
              </div>
              <div className="truncate">
                <div className="text-xs font-bold text-white truncate">{client.name}</div>
                <div className="text-[10px] text-slate-400 font-mono">{client.mobile}</div>
              </div>
            </div>
            <button
              onClick={onClose}
              className="md:hidden p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Items */}
          <nav className="flex md:flex-col gap-1 overflow-x-auto md:overflow-visible custom-scrollbar text-xs">
            <button
              onClick={() => setActiveTab('overview')}
              className={`w-full px-3 py-2 rounded-xl text-left font-medium transition-all flex items-center justify-between ${
                activeTab === 'overview'
                  ? 'bg-[#272730] text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Overview</span>
            </button>

            <button
              onClick={() => setActiveTab('appointments')}
              className={`w-full px-3 py-2 rounded-xl text-left font-medium transition-all flex items-center justify-between ${
                activeTab === 'appointments'
                  ? 'bg-[#272730] text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Appointments</span>
              <span className="w-5 h-5 rounded-full bg-white/10 text-[10px] flex items-center justify-center font-bold">
                {clientBookings.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('sales')}
              className={`w-full px-3 py-2 rounded-xl text-left font-medium transition-all flex items-center justify-between ${
                activeTab === 'sales'
                  ? 'bg-[#272730] text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Sales</span>
              {clientSales.length > 0 && (
                <span className="text-[10px] text-emerald-400 font-mono">
                  {clientSales.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('details')}
              className={`w-full px-3 py-2 rounded-xl text-left font-medium transition-all flex items-center justify-between ${
                activeTab === 'details'
                  ? 'bg-[#272730] text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Client details</span>
            </button>

            <button
              onClick={() => setActiveTab('items')}
              className={`w-full px-3 py-2 rounded-xl text-left font-medium transition-all flex items-center justify-between ${
                activeTab === 'items'
                  ? 'bg-[#272730] text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Items</span>
            </button>

            <button
              onClick={() => setActiveTab('records')}
              className={`w-full px-3 py-2 rounded-xl text-left font-medium transition-all flex items-center justify-between ${
                activeTab === 'records'
                  ? 'bg-[#272730] text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Records</span>
            </button>

            <button
              onClick={() => setActiveTab('wallet')}
              className={`w-full px-3 py-2 rounded-xl text-left font-medium transition-all flex items-center justify-between ${
                activeTab === 'wallet'
                  ? 'bg-[#272730] text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Wallet</span>
            </button>

            <button
              onClick={() => setActiveTab('loyalty')}
              className={`w-full px-3 py-2 rounded-xl text-left font-medium transition-all flex items-center justify-between ${
                activeTab === 'loyalty'
                  ? 'bg-[#272730] text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Loyalty</span>
            </button>

            <button
              onClick={() => setActiveTab('reviews')}
              className={`w-full px-3 py-2 rounded-xl text-left font-medium transition-all flex items-center justify-between ${
                activeTab === 'reviews'
                  ? 'bg-[#272730] text-white font-semibold'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span>Reviews</span>
            </button>
          </nav>
        </div>

        {/* Right Main Content Pane */}
        <div className="flex-1 flex flex-col min-w-0 bg-[#0f0f12]">
          {/* Top Bar inside Modal */}
          <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between shrink-0">
            <div>
              <h2 className="text-xl font-bold tracking-tight text-white capitalize">
                {activeTab === 'overview' ? 'Overview' : activeTab.replace('-', ' ')}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tab Body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 custom-scrollbar">
            {activeTab === 'overview' && (
              <>
                {/* 1. Wallet Card (Matches Screenshot 2) */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                    <span>Wallet</span>
                    <button
                      type="button"
                      onClick={() => setActiveTab('wallet')}
                      className="text-indigo-400 hover:text-indigo-300 font-medium"
                    >
                      View wallet
                    </button>
                  </div>

                  <div className="p-5 rounded-2xl bg-[#18181c] border border-white/5 space-y-2">
                    <div className="flex items-center gap-1.5 text-xs text-slate-400">
                      <span>Balance</span>
                      <div className="w-3.5 h-3.5 rounded-full border border-slate-600 text-[10px] flex items-center justify-center text-slate-400">
                        i
                      </div>
                    </div>
                    <div className="text-2xl font-bold font-mono text-white tracking-tight">
                      QAR {formatCurrency(client.walletBalance || 0)}
                    </div>
                  </div>
                </div>

                {/* 2. Summary Grid (Matches Screenshot 2) */}
                <div className="space-y-3">
                  <div className="text-xs font-semibold text-slate-300">Summary</div>

                  {/* Top full-width card: Total Sales */}
                  <div className="p-5 rounded-2xl bg-[#18181c] border border-white/5 space-y-2">
                    <div className="flex items-center gap-1.5 text-xs text-slate-400">
                      <span>Total sales</span>
                      <div className="w-3.5 h-3.5 rounded-full border border-slate-600 text-[10px] flex items-center justify-center text-slate-400">
                        i
                      </div>
                    </div>
                    <div className="text-2xl font-bold font-mono text-white tracking-tight">
                      QAR {formatCurrency(totalSalesAmount)}
                    </div>
                  </div>

                  {/* 2x2 Grid: Appointments, Rating, Canceled, No show */}
                  <div className="grid grid-cols-2 gap-3">
                    {/* Appointments */}
                    <div className="p-4 rounded-2xl bg-[#18181c] border border-white/5 space-y-1">
                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        <span>Appointments</span>
                        <div className="w-3 h-3 rounded-full border border-slate-600 text-[9px] flex items-center justify-center text-slate-400">
                          i
                        </div>
                      </div>
                      <div className="text-2xl font-bold font-mono text-white">
                        {clientBookings.length || client.totalVisits || 1}
                      </div>
                    </div>

                    {/* Rating */}
                    <div className="p-4 rounded-2xl bg-[#18181c] border border-white/5 space-y-1">
                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        <span>Rating</span>
                        <div className="w-3 h-3 rounded-full border border-slate-600 text-[9px] flex items-center justify-center text-slate-400">
                          i
                        </div>
                      </div>
                      <div className="text-2xl font-bold font-mono text-white">
                        {client.rating ? `★ ${client.rating}` : '—'}
                      </div>
                    </div>

                    {/* Canceled */}
                    <div className="p-4 rounded-2xl bg-[#18181c] border border-white/5 space-y-1">
                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        <span>Canceled</span>
                        <div className="w-3 h-3 rounded-full border border-slate-600 text-[9px] flex items-center justify-center text-slate-400">
                          i
                        </div>
                      </div>
                      <div className="text-2xl font-bold font-mono text-white">
                        {canceledCount}
                      </div>
                    </div>

                    {/* No show */}
                    <div className="p-4 rounded-2xl bg-[#18181c] border border-white/5 space-y-1">
                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        <span>No show</span>
                        <div className="w-3 h-3 rounded-full border border-slate-600 text-[9px] flex items-center justify-center text-slate-400">
                          i
                        </div>
                      </div>
                      <div className="text-2xl font-bold font-mono text-white">
                        {noShowCount}
                      </div>
                    </div>
                  </div>
                </div>

                {/* 3. Upcoming appointment card (Matches Screenshot 2) */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-300">
                    <span>Upcoming appointment</span>
                    <button
                      type="button"
                      onClick={() => setActiveTab('appointments')}
                      className="text-indigo-400 hover:text-indigo-300 font-medium"
                    >
                      View all
                    </button>
                  </div>

                  {latestAppointment ? (
                    <div className="p-5 rounded-2xl bg-[#18181c] border border-white/5 space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-sm font-bold text-white">Appointment</div>
                          <div className="text-xs text-slate-400 mt-0.5">
                            Thu, {formatDate(latestAppointment.date)}, {latestAppointment.startTime} · Cosmos Beauty Salon
                          </div>
                        </div>

                        <span
                          className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                            latestAppointment.status === 'Cancelled'
                              ? 'bg-rose-950/80 text-rose-300 border border-rose-800/40'
                              : latestAppointment.status === 'Completed'
                              ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/40'
                              : 'bg-indigo-950/80 text-indigo-300 border border-indigo-800/40'
                          }`}
                        >
                          {latestAppointment.status === 'Cancelled' ? 'Canceled' : latestAppointment.status}
                        </span>
                      </div>

                      <div className="pt-2 border-t border-white/5 flex items-center justify-between">
                        <div>
                          <div className="text-sm font-bold text-white">
                            {latestAppointment.serviceName}
                          </div>
                          <div className="text-xs text-slate-400 mt-0.5">
                            {latestAppointment.startTime} · {latestAppointment.durationMinutes} min ·{' '}
                            <span className="font-semibold text-slate-300">
                              {latestAppointment.employeeName}
                            </span>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-sm font-mono font-bold text-white">
                            QAR {formatCurrency(latestAppointment.servicePrice)}
                          </span>
                        </div>
                      </div>

                      <div className="pt-2">
                        <button
                          type="button"
                          onClick={() => {
                            if (onRebookAppointment) {
                              onRebookAppointment(client);
                            }
                            onClose();
                          }}
                          className="px-4 py-2 rounded-xl text-xs font-bold bg-[#272730] hover:bg-[#32323e] text-white transition-colors"
                        >
                          Rebook
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-6 text-center text-xs text-slate-500 bg-[#18181c] rounded-2xl border border-white/5">
                      No upcoming appointments. Click Rebook below to schedule.
                      <div className="mt-3">
                        <button
                          type="button"
                          onClick={() => {
                            if (onRebookAppointment) onRebookAppointment(client);
                            onClose();
                          }}
                          className="px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white transition-colors"
                        >
                          Book Service
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}

            {/* TAB 2: APPOINTMENTS */}
            {activeTab === 'appointments' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white">Client Appointments ({clientBookings.length})</h3>
                  <button
                    type="button"
                    onClick={() => {
                      if (onRebookAppointment) onRebookAppointment(client);
                      onClose();
                    }}
                    className="px-3 py-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>New Booking</span>
                  </button>
                </div>

                {clientBookings.length === 0 ? (
                  <div className="p-8 text-center text-slate-500 bg-[#18181c] rounded-xl border border-white/5">
                    No appointments on file for this client.
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {clientBookings.map((b) => (
                      <div
                        key={b.id}
                        className="p-4 bg-[#18181c] border border-white/5 rounded-xl flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-white">{b.serviceName}</span>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                b.status === 'Cancelled'
                                  ? 'bg-rose-950 text-rose-300'
                                  : b.status === 'Completed'
                                  ? 'bg-emerald-950 text-emerald-300'
                                  : 'bg-indigo-950 text-indigo-300'
                              }`}
                            >
                              {b.status}
                            </span>
                          </div>
                          <div className="text-xs text-slate-400 mt-1">
                            {formatDate(b.date)} · {b.startTime} - {b.endTime} · Stylist: <strong>{b.employeeName}</strong>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-mono font-bold text-white">
                            QAR {formatCurrency(b.servicePrice)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: SALES HISTORY */}
            {activeTab === 'sales' && (
              <div className="space-y-4">
                <h3 className="text-sm font-bold text-white">Sales &amp; Invoices ({clientSales.length})</h3>
                {clientSales.length === 0 ? (
                  <div className="p-8 text-center text-slate-500 bg-[#18181c] rounded-xl border border-white/5">
                    No daily sales records registered yet for this client.
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {clientSales.map((s) => (
                      <div
                        key={s.saleId}
                        className="p-4 bg-[#18181c] border border-white/5 rounded-xl flex items-center justify-between"
                      >
                        <div>
                          <div className="font-mono font-bold text-white text-xs">{s.srCode}</div>
                          <div className="text-xs text-slate-400 mt-0.5">
                            {formatDate(s.date)} · Services: {s.services.length} · Products: {s.products.length}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-mono font-bold text-emerald-400 text-sm">
                            QAR {formatCurrency(s.netSales)}
                          </div>
                          <div className="text-[10px] text-slate-400">{s.paymentStatus}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: CLIENT DETAILS */}
            {activeTab === 'details' && (
              <div className="space-y-4 bg-[#18181c] p-5 rounded-2xl border border-white/5">
                <h3 className="text-sm font-bold text-white border-b border-white/10 pb-2">Client Profile Details</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="text-slate-400 block mb-1">Full Name</label>
                    <div className="p-2.5 bg-[#272730] rounded-xl text-white font-semibold">{client.name}</div>
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Mobile Number</label>
                    <div className="p-2.5 bg-[#272730] rounded-xl text-white font-mono">{client.mobile}</div>
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Email</label>
                    <div className="p-2.5 bg-[#272730] rounded-xl text-white">{client.email || '—'}</div>
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Client Segment</label>
                    <div className="p-2.5 bg-[#272730] rounded-xl text-indigo-300 font-bold">{client.segment || 'Regular'}</div>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="text-slate-400 block mb-1">Internal Notes</label>
                    <div className="p-2.5 bg-[#272730] rounded-xl text-slate-300">{client.notes || 'No notes on file.'}</div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 5-9: Placeholders for Wallet, Loyalty, Items, Records, Reviews */}
            {['items', 'records', 'wallet', 'loyalty', 'reviews'].includes(activeTab) && (
              <div className="p-8 text-center text-slate-400 bg-[#18181c] rounded-2xl border border-white/5 space-y-2">
                <div className="text-base font-bold text-white capitalize">{activeTab} Section</div>
                <p className="text-xs text-slate-500">
                  {activeTab === 'wallet' && `Current Store Balance: QAR ${formatCurrency(client.walletBalance || 0)}. No pending credit.`}
                  {activeTab === 'loyalty' && `Cosmos Loyalty Tier: Bronze · Accumulated points: ${client.loyaltyPoints || 120} pts`}
                  {activeTab === 'records' && 'All consultation forms and patch test records are verified for Qatar salon guidelines.'}
                  {activeTab === 'items' && 'All retail products purchased during visits are synchronized with inventory.'}
                  {activeTab === 'reviews' && 'Client satisfaction rating recorded from post-treatment surveys.'}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
