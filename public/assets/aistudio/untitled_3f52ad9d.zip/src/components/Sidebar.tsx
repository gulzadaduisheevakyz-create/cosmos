import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  ReceiptText,
  UserPlus,
  Users,
  UserX,
  CreditCard,
  Clock,
  CalendarDays,
  FileText,
  Archive,
  FileSpreadsheet,
  Database,
  History,
  Settings,
  Sparkles,
  ChevronDown,
  ChevronRight,
  UserCog,
  SlidersHorizontal,
} from 'lucide-react';

export type ViewType =
  | 'dashboard'
  | 'clients-list'
  | 'daily-sales'
  | 'active-employees'
  | 'add-employee'
  | 'employee-settings'
  | 'unemployed'
  | 'monthly-payroll'
  | 'attendance'
  | 'leave-management'
  | 'certificate-generator'
  | 'certificate-archive'
  | 'import-export'
  | 'backup-restore'
  | 'audit-log'
  | 'settings';

interface SidebarProps {
  activeView: ViewType;
  onSelectView: (view: ViewType) => void;
  activeCount: number;
  unemployedCount: number;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onSelectView,
  activeCount,
  unemployedCount,
  isOpenMobile,
  onCloseMobile,
}) => {
  const isEmployeeSectionActive =
    activeView === 'active-employees' ||
    activeView === 'add-employee' ||
    activeView === 'employee-settings' ||
    activeView === 'unemployed';

  const [isEmployeesOpen, setIsEmployeesOpen] = useState(true);

  // Keep open whenever an employee view is active
  useEffect(() => {
    if (isEmployeeSectionActive) {
      setIsEmployeesOpen(true);
    }
  }, [isEmployeeSectionActive]);

  const employeeSubItems: {
    id: ViewType;
    label: string;
    icon: React.ReactNode;
    badge?: number | string;
    badgeColor?: string;
  }[] = [
    {
      id: 'active-employees',
      label: 'Active Employees',
      icon: <Users className="w-3.5 h-3.5" />,
      badge: activeCount,
    },
    {
      id: 'add-employee',
      label: 'Add Employee',
      icon: <UserPlus className="w-3.5 h-3.5" />,
    },
    {
      id: 'employee-settings',
      label: 'Employee Settings',
      icon: <UserCog className="w-3.5 h-3.5" />,
      badge: '1-Cat Rule',
      badgeColor: 'bg-purple-900/40 text-purple-300 border border-purple-700/40',
    },
    {
      id: 'unemployed',
      label: 'Unemployed / Former',
      icon: <UserX className="w-3.5 h-3.5" />,
      badge: unemployedCount > 0 ? unemployedCount : undefined,
      badgeColor: 'bg-amber-900/40 text-amber-300 border border-amber-700/40',
    },
  ];

  const mainNavItemsTop: { id: ViewType; label: string; icon: React.ReactNode; badge?: number | string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'clients-list', label: 'Clients List', icon: <Users className="w-4 h-4" />, badge: '2,450' },
    { id: 'daily-sales', label: 'Daily Sales Report', icon: <ReceiptText className="w-4 h-4" /> },
  ];

  const mainNavItemsBottom: { id: ViewType; label: string; icon: React.ReactNode; badge?: number | string }[] = [
    { id: 'monthly-payroll', label: 'Monthly Payroll', icon: <CreditCard className="w-4 h-4" /> },
    { id: 'attendance', label: 'Attendance Schedule', icon: <Clock className="w-4 h-4" /> },
    { id: 'leave-management', label: 'Leave & Tickets', icon: <CalendarDays className="w-4 h-4" /> },
    { id: 'certificate-generator', label: 'Certificate Generator', icon: <FileText className="w-4 h-4" /> },
    { id: 'certificate-archive', label: 'Certificate Archive', icon: <Archive className="w-4 h-4" /> },
    { id: 'import-export', label: 'Excel Import / Export', icon: <FileSpreadsheet className="w-4 h-4" /> },
    { id: 'backup-restore', label: 'Backup & Restore', icon: <Database className="w-4 h-4" /> },
    { id: 'audit-log', label: 'Audit Log', icon: <History className="w-4 h-4" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 bg-slate-950/60 z-40 lg:hidden backdrop-blur-xs"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-slate-900 border-r border-slate-800 text-slate-300 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand header */}
        <div className="p-5 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-linear-to-br from-amber-400 via-rose-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-rose-950/30">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="text-sm font-bold tracking-tight text-white flex items-center gap-1.5">
                COSMOS HR
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Salon Payroll & Staff Pro</p>
            </div>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-1 custom-scrollbar">
          {/* Top section links */}
          {mainNavItemsTop.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectView(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
                }`}
              >
                <div className="flex items-center gap-3 truncate">
                  <span className={`${isActive ? 'text-white' : 'text-slate-400'}`}>
                    {item.icon}
                  </span>
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-medium ${
                      isActive ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}

          {/* Single Parent Link: "Employees" */}
          <div className="pt-1.5 pb-1">
            <div
              className={`rounded-xl border transition-all ${
                isEmployeeSectionActive
                  ? 'bg-slate-800/60 border-slate-700/80 shadow-xs'
                  : 'border-transparent hover:bg-slate-800/30'
              }`}
            >
              <div className="flex items-center justify-between px-3 py-2.5">
                <button
                  type="button"
                  onClick={() => {
                    if (!isEmployeesOpen) {
                      setIsEmployeesOpen(true);
                    }
                    if (!isEmployeeSectionActive) {
                      onSelectView('active-employees');
                      onCloseMobile();
                    }
                  }}
                  className="flex items-center gap-3 truncate flex-1 text-left"
                >
                  <span
                    className={`p-1 rounded-md ${
                      isEmployeeSectionActive
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Users className="w-4 h-4" />
                  </span>
                  <div className="truncate">
                    <span
                      className={`text-xs font-bold block ${
                        isEmployeeSectionActive ? 'text-white' : 'text-slate-200'
                      }`}
                    >
                      Employees
                    </span>
                    <span className="text-[10px] text-slate-400 block -mt-0.5 font-normal">
                      Directory, Roles &amp; Rules
                    </span>
                  </div>
                </button>

                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full font-mono font-semibold bg-slate-800 text-slate-300 border border-slate-700/50">
                    {activeCount}
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsEmployeesOpen((prev) => !prev);
                    }}
                    className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-700/60 transition-colors"
                    title={isEmployeesOpen ? 'Collapse Employees' : 'Expand Employees'}
                  >
                    {isEmployeesOpen ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              {/* Collapsible Sub-menu */}
              {isEmployeesOpen && (
                <div className="px-2 pb-2 pt-0.5 space-y-0.5 border-t border-slate-700/40 mt-1">
                  {employeeSubItems.map((sub) => {
                    const isSubActive = activeView === sub.id;
                    return (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => {
                          onSelectView(sub.id);
                          onCloseMobile();
                        }}
                        className={`w-full flex items-center justify-between pl-3 pr-2 py-2 rounded-lg text-xs font-medium transition-all ${
                          isSubActive
                            ? 'bg-blue-600 text-white font-semibold shadow-xs'
                            : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 truncate">
                          <span
                            className={
                              isSubActive
                                ? 'text-white'
                                : sub.id === 'employee-settings'
                                ? 'text-purple-400'
                                : 'text-slate-400'
                            }
                          >
                            {sub.icon}
                          </span>
                          <span className="truncate text-[11px]">{sub.label}</span>
                        </div>
                        {sub.badge !== undefined && (
                          <span
                            className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-medium ${
                              isSubActive
                                ? 'bg-white/20 text-white'
                                : sub.badgeColor || 'bg-slate-800 text-slate-300'
                            }`}
                          >
                            {sub.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Bottom section links */}
          {mainNavItemsBottom.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectView(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
                }`}
              >
                <div className="flex items-center gap-3 truncate">
                  <span className={`${isActive ? 'text-white' : 'text-slate-400'}`}>
                    {item.icon}
                  </span>
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-medium ${
                      isActive ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer info */}
        <div className="p-3 border-t border-slate-800 text-[11px] text-slate-400 bg-slate-950/40">
          <div className="flex items-center justify-between">
            <span>Doha, Qatar</span>
            <span className="font-mono text-[10px] text-emerald-400">QAR (ريال)</span>
          </div>
        </div>
      </aside>
    </>
  );
};

