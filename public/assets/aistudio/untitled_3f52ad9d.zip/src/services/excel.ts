import * as XLSX from 'xlsx';
import { Employee, AttendanceRecord, Certificate, LeaveRecord, FlightTicketRecord, DailySaleRecord } from '../types';
import { calculateDaysRemaining, formatDate, getDayOfWeek, formatTime12, minutesToTimeStr, formatCurrency } from './db';


export function exportEmployeesToExcel(employees: Employee[], filename?: string) {
  if (!employees || employees.length === 0) {
    throw new Error('No employee records to export');
  }

  const exportData = employees.map((emp, idx) => ({
    'No': emp.no || idx + 1,
    'EMPLOYER ID': emp.employerId || '',
    'COMPANY': emp.company || '',
    'Duty': emp.duty || '',
    'Accommodation': emp.accommodation || '',
    'CONTRACT No': emp.contractNo || '',
    'EMPLOYEE ID': emp.employeeId || '',
    'CONTRACT Type': emp.contractType || '',
    'JOINING DATE': emp.joiningDate || '',
    'END CONTRACT': emp.endContract || '',
    'MPH CERTIFICATE': emp.mph || '',
    'EXPIRE MPH': emp.expireMph || '',
    'POSITION': emp.position || '',
    "EMPLOYEE'S NAME": emp.employeeName || '',
    'NATIONALITY': emp.nationality || '',
    'MOBILE': emp.mobile || '',
    'WHATSAPP': emp.whatsapp || '',
    'E-MAIL': emp.email || '',
    'PASSPORT NUMBER': emp.passportNumber || '',
    'PASSPORT EXPIRY': emp.passportExpiry || '',
    'PASSPORT DAYS': emp.passportDays || '',
    'RESIDENCY QID': emp.residencyQid || '',
    'RESIDENCY EXPIRY': emp.residencyExpiry || '',
    'RESIDENCY DAYS': emp.residencyDays || '',
    'PAYER BANK': emp.payerBank || '',
    'PAYER BANK SHORT': emp.payerBankShort || '',
    'PAYE BANK IBAN': emp.iban || '',
    'BASIC SALARY': Number(emp.basicSalary) || 0,
    'FOOD ALLOWANCE': Number(emp.foodAllowance) || 0,
    'TRANSPORTATION ALLOWANCE': Number(emp.transportAllowance) || 0,
    'CAR OPERATION ALLOWANCE': Number(emp.carOperationAllowance) || 0,
    'OTHER ALLOWANCE': Number(emp.otherAllowance) || 0,
    'LIMITED TRANSPORTATION': Number(emp.limitedTransport) || 0,
    'TOTAL SALARIES': Number(emp.totalSalary) || 0,
    'SALE COMMISSION RATE (%)': Number(emp.saleCommissionRate) || 10,
    'SALE TARGET RATE': Number(emp.saleTargetRate) || 0,
    'TOTAL SALES RATE': Number(emp.totalSalesRate) || 0,
    'TARGET SALES': Number(emp.targetSales) || 0,
    'PRODUCTS SALE COMMISSION (%)': Number(emp.prodSaleCommission) || 5,
    "PRODUCTS SALE'S TARGET": Number(emp.prodSaleTarget) || 0,
    "PRODUCTS TOTAL SALE'S": Number(emp.prodTotalSales) || 0,
    'BUSINESS TARGET 200,000 RATE (%)': Number(emp.businessTargetRate) || 5,
    'BUSINESS TARGET AMOUNT': Number(emp.businessTargetAmount) || 200000,
    'BUSINESS GROSS': Number(emp.businessGross) || 0,
    'BUSINESS COMMISSION BASE': emp.businessCommBase || 'all_gross',
    'BUSINESS BONUS': Number(emp.businessBonus) || 0,
    'DEDUCTION IN THE CURRENT MONTH': Number(emp.deductionCurrent) || 0,
    'DEDUCTION SCHEDULED FOR A FUTURE': Number(emp.deductionFuture) || 0,
    "TIP'S": Number(emp.tips) || 0,
    'OUTSTANDING': Number(emp.outstanding) || 0,
    'LEAVE ENTITLEMENT': Number(emp.leaveEntitlement) || 21,
    'Annual Leave Paid': emp.annualLeavePaid || '',
    'SALARIES & WAGES': Number(emp.salariesWages) || 0,
    'Total Credit Leave Days': Number(emp.totalCreditLeave) || 21,
    'LAST ANNUAL LEAVES DATE': emp.lastLeaveDate || '',
    'ANNUAL LEAVE DAYS': Number(emp.annualLeaveDays) || 0,
    'Annual Leave (Paid/Unpaid)': emp.annualLeaveStatus || 'Paid',
    'Annual Leave Paid Amount': Number(emp.annualLeavePaidAmt) || 0,
    'Annual Leave Remaining': Number(emp.annualLeaveRemaining) || 21,
    'Annual Leave Fees': Number(emp.annualLeaveFees) || 0,
    'TICKET CYCLE (YEARS)': Number(emp.ticketCycle) || 2,
    'NEXT TICKET DATE': emp.nextTicketDate || '',
    'TICKET STATUS': emp.ticketStatus || '',
    'TICKET DESTINATION': emp.ticketDestination || '',
    'I confirm': emp.confirm || '',
    'signature': emp.signature || '',
    'Date': emp.date || '',
    'STATUS': emp.status || 'Active',
  }));

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Employees');
  const outName = filename || `Cosmos_Beauty_Salon_Employees_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(workbook, outName);
}

export async function parseEmployeesFromExcel(file: File): Promise<{
  importedCount: number;
  updatedCount: number;
  employees: Employee[];
}> {
  const data = await file.arrayBuffer();
  const workbook = XLSX.read(data, { type: 'array' });
  const sheetName = workbook.SheetNames[0];
  const jsonData = XLSX.utils.sheet_to_json<Record<string, unknown>>(workbook.Sheets[sheetName], { defval: '' });

  const parsedEmployees: Employee[] = [];
  let index = 1;

  for (const row of jsonData) {
    const empId = String(row['EMPLOYEE ID'] || row['Employee ID'] || `CBSE${20240 + index}`).trim();

    // Auto-calculate end contract (+2 years) if not provided
    let joiningDate = String(row['JOINING DATE'] || row['Joining Date'] || '').trim();
    let endContract = String(row['END CONTRACT'] || row['End Contract'] || '').trim();
    if (!endContract && joiningDate) {
      const join = new Date(joiningDate);
      if (!isNaN(join.getTime())) {
        join.setFullYear(join.getFullYear() + 2);
        endContract = join.toISOString().split('T')[0];
      }
    }

    // Auto-calculate passport & residency days
    const passportExpiry = String(row['PASSPORT EXPIRY'] || row['Passport Expiry'] || '').trim();
    let passportDays = String(row['PASSPORT DAYS'] || row['Passport Days'] || '').trim();
    if (passportExpiry && !passportDays) {
      const pDays = calculateDaysRemaining(passportExpiry);
      passportDays = `Day ${pDays}`;
    }

    const residencyExpiry = String(row['RESIDENCY EXPIRY'] || row['Residency Expiry'] || '').trim();
    let residencyDays = String(row['RESIDENCY DAYS'] || row['Residency Days'] || '').trim();
    if (residencyExpiry && !residencyDays) {
      const rDays = calculateDaysRemaining(residencyExpiry);
      residencyDays = `Day ${rDays}`;
    }

    const basicSalary = parseFloat(String(row['BASIC SALARY'] || row['Basic Salary'] || 0)) || 0;
    const foodAllowance = parseFloat(String(row['FOOD ALLOWANCE'] || row['Food Allowance'] || 0)) || 0;
    const transportAllowance = parseFloat(String(row['TRANSPORTATION ALLOWANCE'] || row['Transportation Allowance'] || 0)) || 0;
    const carOperationAllowance = parseFloat(String(row['CAR OPERATION ALLOWANCE'] || row['Car Operation Allowance'] || 0)) || 0;
    const otherAllowance = parseFloat(String(row['OTHER ALLOWANCE'] || row['Other Allowance'] || 0)) || 0;
    const limitedTransport = parseFloat(String(row['LIMITED TRANSPORTATION'] || row['Limited Transportation'] || 0)) || 0;
    const totalSalary = basicSalary + foodAllowance + transportAllowance + carOperationAllowance + otherAllowance + limitedTransport;

    const emp: Employee = {
      no: row['No'] ? String(row['No']) : index,
      employerId: String(row['EMPLOYER ID'] || row['Employer ID'] || '17-2681-92'),
      company: String(row['COMPANY'] || row['Company'] || 'COSMOS'),
      duty: String(row['Duty'] || 'Duty'),
      accommodation: String(row['Accommodation'] || 'Live In'),
      contractNo: String(row['CONTRACT No'] || row['Contract No'] || `CBS-${Date.now().toString().slice(-8)}`),
      employeeId: empId,
      contractType: String(row['CONTRACT Type'] || row['Contract Type'] || 'Contract'),
      joiningDate,
      endContract,
      mph: String(row['MPH CERTIFICATE'] || row['MPH'] || 'NO'),
      expireMph: String(row['EXPIRE MPH'] || row['Expire MPH'] || ''),
      position: String(row['POSITION'] || row['Position'] || 'Staff'),
      employeeName: String(row["EMPLOYEE'S NAME"] || row['Employee Name'] || row['Name'] || 'Employee ' + index),
      nationality: String(row['NATIONALITY'] || row['Nationality'] || 'KYRGYZSTAN'),
      mobile: String(row['MOBILE'] || row['Mobile'] || ''),
      whatsapp: String(row['WHATSAPP'] || row['WhatsApp'] || ''),
      email: String(row['E-MAIL'] || row['Email'] || ''),
      passportNumber: String(row['PASSPORT NUMBER'] || row['Passport Number'] || ''),
      passportExpiry,
      passportDays,
      residencyQid: String(row['RESIDENCY QID'] || row['QID'] || ''),
      residencyExpiry,
      residencyDays,
      payerBank: String(row['PAYER BANK'] || row['Payer Bank'] || 'Doha Bank'),
      payerBankShort: String(row['PAYER BANK SHORT'] || row['Bank Short'] || 'DB'),
      iban: String(row['PAYE BANK IBAN'] || row['IBAN'] || ''),
      basicSalary,
      foodAllowance,
      transportAllowance,
      carOperationAllowance,
      otherAllowance,
      limitedTransport,
      totalSalary,
      saleCommissionRate: parseFloat(String(row['SALE COMMISSION RATE (%)'] || 10)) || 10,
      saleTargetRate: parseFloat(String(row['SALE TARGET RATE'] || 0)) || 0,
      totalSalesRate: parseFloat(String(row['TOTAL SALES RATE'] || 0)) || 0,
      targetSales: parseFloat(String(row['TARGET SALES'] || 0)) || 0,
      prodSaleCommission: parseFloat(String(row['PRODUCTS SALE COMMISSION (%)'] || 5)) || 5,
      prodSaleTarget: parseFloat(String(row["PRODUCTS SALE'S TARGET"] || 0)) || 0,
      prodTotalSales: parseFloat(String(row["PRODUCTS TOTAL SALE'S"] || 0)) || 0,
      businessTargetRate: parseFloat(String(row['BUSINESS TARGET 200,000 RATE (%)'] || row['Business Target Rate'] || 5)) || 5,
      businessTargetAmount: parseFloat(String(row['BUSINESS TARGET AMOUNT'] || row['Business Target'] || 200000)) || 200000,
      businessGross: parseFloat(String(row['BUSINESS GROSS'] || row['Business Gross'] || 0)) || 0,
      businessCommBase: String(row['BUSINESS COMMISSION BASE'] || row['Business Comm Base'] || '').toLowerCase().includes('above') ? 'above_target' : 'all_gross',
      businessBonus: parseFloat(String(row['BUSINESS BONUS'] || 0)) || 0,
      deductionCurrent: parseFloat(String(row['DEDUCTION IN THE CURRENT MONTH'] || 0)) || 0,
      deductionFuture: parseFloat(String(row['DEDUCTION SCHEDULED FOR A FUTURE'] || 0)) || 0,
      futureDeductions: [],
      tips: parseFloat(String(row["TIP'S"] || row['Tips'] || 0)) || 0,
      outstanding: parseFloat(String(row['OUTSTANDING'] || row['Outstanding'] || 0)) || 0,
      leaveEntitlement: parseFloat(String(row['LEAVE ENTITLEMENT'] || 21)) || 21,
      annualLeavePaid: String(row['Annual Leave Paid'] || ''),
      salariesWages: parseFloat(String(row['SALARIES & WAGES'] || 0)) || totalSalary,
      totalCreditLeave: parseFloat(String(row['Total Credit Leave Days'] || 21)) || 21,
      lastLeaveDate: String(row['LAST ANNUAL LEAVES DATE'] || ''),
      annualLeaveDays: parseFloat(String(row['ANNUAL LEAVE DAYS'] || 0)) || 0,
      annualLeaveStatus: String(row['Annual Leave (Paid/Unpaid)'] || 'Paid'),
      annualLeavePaidAmt: parseFloat(String(row['Annual Leave Paid Amount'] || 0)) || 0,
      annualLeaveRemaining: parseFloat(String(row['Annual Leave Remaining'] || 21)) || 21,
      annualLeaveFees: parseFloat(String(row['Annual Leave Fees'] || 0)) || 0,
      ticketCycle: parseInt(String(row['TICKET CYCLE (YEARS)'] || 2)) || 2,
      nextTicketDate: String(row['NEXT TICKET DATE'] || ''),
      ticketStatus: String(row['TICKET STATUS'] || 'Not Eligible'),
      ticketDestination: String(row['TICKET DESTINATION'] || ''),
      confirm: String(row['I confirm'] || 'I further acknowledge and confirm that I have received Salary'),
      signature: String(row['signature'] || ''),
      date: String(row['Date'] || new Date().toISOString().slice(0, 10)),
      status: String(row['STATUS'] || row['Status'] || 'Active') === 'Unemployed' ? 'Unemployed' : 'Active',
    };

    parsedEmployees.push(emp);
    index++;
  }

  return {
    importedCount: parsedEmployees.length,
    updatedCount: 0,
    employees: parsedEmployees,
  };
}

export function exportAttendanceToExcel(records: AttendanceRecord[], monthTitle?: string) {
  const exportData = records.map((r) => {
    const extraMinutes = r.extraMinutes || 0;
    const shortMinutes = r.shortMinutes !== undefined ? r.shortMinutes : (r.totalWorkMinutes < r.scheduledWorkMinutes ? r.scheduledWorkMinutes - r.totalWorkMinutes : 0);

    return {
      'Employee ID': r.employeeId,
      'Employee Name': r.employeeName,
      'Date': r.date,
      'Day': getDayOfWeek(r.date),
      'Shift': 'Morning to Night (Single Shift)',
      'Scheduled Start': r.scheduledStart || '09:00',
      'Time In (Morning)': r.timeIn ? formatTime12(r.timeIn) : '-',
      'Time Out (Night)': r.timeOut ? formatTime12(r.timeOut) : '-',
      'Scheduled End': r.scheduledEnd || '21:00',
      'Total Work Hours': minutesToTimeStr(r.totalWorkMinutes),
      'Scheduled Hours': minutesToTimeStr(r.scheduledWorkMinutes),
      'Extra Hours': extraMinutes > 0 ? `+${minutesToTimeStr(extraMinutes)}` : '0h 0m',
      'Short Hours': shortMinutes > 0 ? `-${minutesToTimeStr(shortMinutes)}` : '0h 0m',
      'Status': r.status,
      'Remarks': r.remarks || '',
    };
  });

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Attendance Records');
  const filename = monthTitle ? `Cosmos_Attendance_${monthTitle}.xlsx` : `Cosmos_Attendance_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(workbook, filename);
}

export function exportCertificatesToExcel(certificates: Certificate[]) {
  const exportData = certificates.map((c) => ({
    'Reference': c.reference,
    'Type': c.certTypeName,
    'Employee ID': c.employeeId,
    'Employee Name': c.employeeName,
    'Position': c.employeePosition,
    'QID': c.employeeQid,
    'Nationality': c.employeeNationality,
    'Joining Date': formatDate(c.employeeJoiningDate),
    'Recipient': c.recipient,
    'Corresponding Date': formatDate(c.correspondingDate),
    'Signatory Name': c.signatoryName,
    'Signatory Title': c.signatoryTitle,
    'Basic Salary': c.salaryData.basicSalary,
    'Food Allowance': c.salaryData.foodAllowance,
    'Transport Allowance': c.salaryData.transportAllowance,
    'Car Operation Allowance': c.salaryData.carOperationAllowance,
    'Other Allowance': c.salaryData.otherAllowance,
    'Total Salary': c.salaryData.totalSalary,
    'Created At': new Date(c.createdAt).toLocaleString(),
  }));

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Certificates');
  XLSX.writeFile(workbook, `Cosmos_Certificates_Archive_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

export function exportLeaveAndTicketsToExcel(employees: Employee[], leaves: LeaveRecord[], tickets: FlightTicketRecord[]) {
  const exportData = employees.filter((e) => e.status !== 'Unemployed').map((emp) => {
    const empLeaves = leaves.filter((l) => l.employeeId === emp.employeeId);
    const entitlement = Number(emp.leaveEntitlement) || 21;
    const taken = empLeaves.filter((l) => l.status === 'Approved').reduce((sum, l) => sum + (Number(l.days) || 0), 0);
    const pending = empLeaves.filter((l) => l.status === 'Pending').reduce((sum, l) => sum + (Number(l.days) || 0), 0);
    const remaining = entitlement - taken - pending;
    const basic = Number(emp.basicSalary) || 0;
    const dailyRate = basic / 30;

    return {
      'Employee ID': emp.employeeId,
      'Name': emp.employeeName,
      'Position': emp.position,
      'Joining Date': formatDate(emp.joiningDate),
      'Leave Entitlement': entitlement,
      'Leave Days Taken': taken,
      'Leave Days Pending': pending,
      'Remaining Balance': remaining,
      'Daily Basic Rate (÷30)': dailyRate,
      'Leave Payment Value': remaining * dailyRate,
      'Flight Ticket Cycle (Years)': emp.ticketCycle || 2,
      'Next Eligible Ticket Date': emp.nextTicketDate ? formatDate(emp.nextTicketDate) : '-',
      'Ticket Status': emp.ticketStatus || 'Not Eligible',
      'Destination': emp.ticketDestination || '-',
    };
  });

  const worksheet = XLSX.utils.json_to_sheet(exportData);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Leave & Flight Tickets');
  XLSX.writeFile(workbook, `Cosmos_Leave_Flight_Tickets_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

export function exportDailySalesToExcel(sales: DailySaleRecord[], employees: Employee[]) {
  if (!sales || sales.length === 0) {
    throw new Error('No sales records to export');
  }

  // 1. Transaction level sheet
  const salesData = sales.map((s) => ({
    'Sr#': s.srCode,
    'Date': s.date,
    'Customer Name': s.customerName,
    'Mobile Number': s.mobileNumber,
    'Services Rendered': s.services.map((sv) => `${sv.serviceName} (${sv.employeeName} - QAR ${sv.lineTotal})`).join('; '),
    'Service Revenue (QAR)': s.totalServiceAmount,
    'Product Sales': s.products.map((p) => `${p.productName} (x${p.quantity} - QAR ${p.lineTotal})`).join('; '),
    'Product Revenue (QAR)': s.totalProductAmount,
    'Uber for Home Service (QAR)': s.uberCharge,
    'Gross Business Sales (QAR)': s.grossSales,
    'Total Revenue (QAR)': s.totalRevenue,
    'POS Card (QAR)': s.posCard,
    'Cash (QAR)': s.cash,
    'Fawran (QAR)': s.fawran,
    'Fawran Recipient': s.fawranRecipientName || '-',
    'Tips (QAR)': s.tips,
    'Un-Paid (QAR)': s.unpaid,
    'Refunds (QAR)': s.refunds,
    'Net Sales (QAR)': s.netSales,
    'Total Paid (QAR)': s.totalPaid,
    'Payment Status': s.paymentStatus,
    'Notes': s.notes || '-',
  }));

  // 2. Employee breakdown sheet
  const empMap: Record<string, { name: string; serviceSales: number; productSales: number }> = {};
  employees.forEach((e) => {
    empMap[e.employeeId] = { name: e.employeeName, serviceSales: 0, productSales: 0 };
  });

  sales.forEach((s) => {
    s.services.forEach((srv) => {
      if (empMap[srv.employeeId]) {
        empMap[srv.employeeId].serviceSales += Number(srv.lineTotal) || 0;
      }
    });
    s.products.forEach((prd) => {
      if (empMap[prd.employeeId]) {
        empMap[prd.employeeId].productSales += Number(prd.lineTotal) || 0;
      }
    });
  });

  const empSummaryData = Object.keys(empMap).map((empId) => {
    const item = empMap[empId];
    return {
      'Employee ID': empId,
      'Employee Name': item.name,
      'Eligible Service Sales (QAR)': item.serviceSales,
      'Eligible Product Sales (QAR)': item.productSales,
      'Total Sales Generated (QAR)': item.serviceSales + item.productSales,
    };
  });

  // 3. Payment Mode Summary
  let totalPOS = 0, totalCash = 0, totalFawran = 0, totalTips = 0, totalUnpaid = 0, totalRefunds = 0, totalNet = 0;
  sales.forEach((s) => {
    totalPOS += Number(s.posCard) || 0;
    totalCash += Number(s.cash) || 0;
    totalFawran += Number(s.fawran) || 0;
    totalTips += Number(s.tips) || 0;
    totalUnpaid += Number(s.unpaid) || 0;
    totalRefunds += Number(s.refunds) || 0;
    totalNet += Number(s.netSales) || 0;
  });

  const paymentSummaryData = [
    { 'Payment Mode': 'POS Card', 'Total Collected (QAR)': totalPOS },
    { 'Payment Mode': 'Cash', 'Total Collected (QAR)': totalCash },
    { 'Payment Mode': 'Fawran (Instant)', 'Total Collected (QAR)': totalFawran },
    { 'Payment Mode': 'Tips (Gratuity)', 'Total Collected (QAR)': totalTips },
    { 'Payment Mode': 'Un-Paid (Outstanding)', 'Total Collected (QAR)': totalUnpaid },
    { 'Payment Mode': 'Refunds (Deducted)', 'Total Collected (QAR)': totalRefunds },
    { 'Payment Mode': 'Net Sales', 'Total Collected (QAR)': totalNet },
  ];

  const workbook = XLSX.utils.book_new();
  const ws1 = XLSX.utils.json_to_sheet(salesData);
  const ws2 = XLSX.utils.json_to_sheet(empSummaryData);
  const ws3 = XLSX.utils.json_to_sheet(paymentSummaryData);

  XLSX.utils.book_append_sheet(workbook, ws1, 'Daily Sales Transactions');
  XLSX.utils.book_append_sheet(workbook, ws2, 'Employee Sales Summary');
  XLSX.utils.book_append_sheet(workbook, ws3, 'Payment Reconciliation');

  XLSX.writeFile(workbook, `Cosmos_Daily_Sales_Report_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

