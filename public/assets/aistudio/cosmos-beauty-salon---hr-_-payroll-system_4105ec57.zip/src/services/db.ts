import {
  Employee,
  PayrollRecord,
  AttendanceRecord,
  ExtraTimeTransaction,
  LeaveRecord,
  FlightTicketRecord,
  Certificate,
  BankInfo,
  SystemSettings,
  AuditLogItem,
} from '../types';

export const DEFAULT_QATAR_BANKS: BankInfo[] = [
  { name: 'Qatar Islamic Bank', short: 'QIB' },
  { name: 'Commercial Bank of Qatar', short: 'CBQ' },
  { name: 'Qatar National Bank', short: 'QNB' },
  { name: 'Doha Bank', short: 'DB' },
  { name: 'Masraf Al Rayan', short: 'MAR' },
  { name: 'Bank of Bahrain and Kuwait (Qatar)', short: 'BBK' },
  { name: 'Ahli Bank', short: 'ABQ' },
  { name: 'International Bank of Qatar', short: 'IBQ' },
  { name: 'Qatar Development Bank', short: 'QDB' },
  { name: 'HSBC Qatar', short: 'HSBC' },
  { name: 'Standard Chartered Qatar', short: 'SCB' },
  { name: 'Citibank Qatar', short: 'CITI' },
  { name: 'Barwa Bank', short: 'BARWA' },
  { name: 'Qatar First Bank', short: 'QFB' },
  { name: 'Other', short: 'OTHER' },
];

export const DEFAULT_SETTINGS: SystemSettings = {
  companyName: 'COSMOS BEAUTY SALON',
  companyAddress: 'Doha, Qatar',
  companyPhone: '+974 4455 6677',
  companyEmail: 'hr@cosmosbeautysalon.qa',
  signatoryName: 'ATYRGUL AIAZOVA',
  signatoryTitle: 'Authorized Manager',
  certValidity: 1,
  certCounter: 1,
  salesCommRate: 10,
  productCommRate: 5,
  businessTarget: 200000,
  businessCommRate: 5,
  leaveEntitlement: 21,
  leaveDivisor: 30,
  ticketCycle: 2,
  attOpening: '09:00',
  attClosing: '21:00',
  attBreakStart: '13:00',
  attBreakEnd: '14:00',
  attLateThreshold: 15,
  attMorningStart: '09:00',
  attMorningEnd: '13:00',
  attNightStart: '16:00',
  attNightEnd: '21:00',
};

export const SAMPLE_EMPLOYEES: Employee[] = [
  {
    no: 1,
    employerId: '17-2681-92',
    company: 'COSMOS',
    duty: 'Vacation',
    accommodation: 'Live Out',
    contractNo: 'CBS-22062026',
    employeeId: 'CBSE20243',
    contractType: 'Contract',
    joiningDate: '2026-02-15',
    endContract: '2028-02-15',
    mph: 'YES',
    expireMph: '2027-08-04',
    position: 'Eyelash Technician',
    employeeName: 'ATYRGUL AIAZOVA',
    nationality: 'KYRGYZSTAN',
    mobile: '+974 3388 8687',
    whatsapp: '+974 3388 8687',
    email: 'Atyrgula50@gmail.com',
    passportNumber: 'AC3002861',
    passportExpiry: '2027-06-09',
    passportDays: 'Day 598',
    residencyQid: '29741700048',
    residencyExpiry: '2027-06-26',
    residencyDays: 'Day 615',
    payerBank: 'Doha Bank',
    payerBankShort: 'DB',
    iban: 'QA60BRWA00000000020000129',
    basicSalary: 4000,
    foodAllowance: 1500,
    transportAllowance: 2000,
    carOperationAllowance: 0,
    otherAllowance: 2500,
    limitedTransport: 200,
    totalSalary: 10200,
    saleCommissionRate: 10,
    saleTargetRate: 35000,
    totalSalesRate: 38500,
    targetSales: 35000,
    prodSaleCommission: 5,
    prodSaleTarget: 5000,
    prodTotalSales: 6200,
    businessTargetRate: 5,
    businessGross: 215000,
    businessBonus: 0,
    deductionCurrent: 3060,
    deductionFuture: 0,
    futureDeductions: [],
    tips: 450,
    outstanding: 0,
    leaveEntitlement: 21,
    annualLeavePaid: 'QAR 1,333',
    salariesWages: 8473,
    totalCreditLeave: 30,
    lastLeaveDate: '2026-09-20',
    annualLeaveDays: 25,
    annualLeaveStatus: 'Paid',
    annualLeavePaidAmt: 3333,
    annualLeaveRemaining: 5,
    annualLeaveFees: 667,
    ticketCycle: 2,
    nextTicketDate: '2028-02-15',
    ticketStatus: 'Not Eligible',
    ticketDestination: 'Bishkek, Kyrgyzstan',
    confirm: 'I further acknowledge and confirm that I have received Salary',
    signature: 'A. Aiazova',
    date: '2026-10-21',
    status: 'Active',
    weeklyOffDay: 'Monday',
  },
  {
    no: 2,
    employerId: '17-2681-92',
    company: 'COSMOS',
    duty: 'Duty',
    accommodation: 'Live In',
    contractNo: 'CBS-22062027',
    employeeId: 'CBSE20244',
    contractType: 'Contract',
    joiningDate: '2026-06-20',
    endContract: '2028-06-20',
    mph: 'NO',
    expireMph: '',
    position: 'Manager',
    employeeName: 'KUMUSHAI DUISHOGULOVA',
    nationality: 'KYRGYZSTAN',
    mobile: '+974 70637559',
    whatsapp: '+974 5053 3889',
    email: 'kumushaiduishogulova@gmail.com',
    passportNumber: 'AC3117123',
    passportExpiry: '2027-12-19',
    passportDays: 'Day 791',
    residencyQid: '30141700003',
    residencyExpiry: '2027-06-19',
    residencyDays: 'Day 608',
    payerBank: 'Qatar Islamic Bank',
    payerBankShort: 'QIB',
    iban: 'QA56QISB000000000156307030017',
    basicSalary: 2500,
    foodAllowance: 1000,
    transportAllowance: 1000,
    carOperationAllowance: 500,
    otherAllowance: 3791,
    limitedTransport: 200,
    totalSalary: 8991,
    saleCommissionRate: 10,
    saleTargetRate: 20000,
    totalSalesRate: 24000,
    targetSales: 20000,
    prodSaleCommission: 5,
    prodSaleTarget: 3000,
    prodTotalSales: 3500,
    businessTargetRate: 5,
    businessGross: 215000,
    businessBonus: 500,
    deductionCurrent: 0,
    deductionFuture: 0,
    futureDeductions: [],
    tips: 600,
    outstanding: 0,
    leaveEntitlement: 21,
    annualLeavePaid: 'QAR 0',
    salariesWages: 8991,
    totalCreditLeave: 30,
    lastLeaveDate: '',
    annualLeaveDays: 0,
    annualLeaveStatus: 'Paid',
    annualLeavePaidAmt: 0,
    annualLeaveRemaining: 30,
    annualLeaveFees: 2500,
    ticketCycle: 2,
    nextTicketDate: '2028-06-20',
    ticketStatus: 'Eligible',
    ticketDestination: 'Bishkek, Kyrgyzstan',
    confirm: 'I further acknowledge and confirm that I have received Salary',
    signature: 'K. Duishogulova',
    date: '2026-10-21',
    status: 'Active',
    weeklyOffDay: 'Tuesday',
  },
];

// Helper calculations
export function calculateDaysRemaining(dateStr: string): number {
  if (!dateStr) return 9999;
  const target = new Date(dateStr);
  if (isNaN(target.getTime())) return 9999;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const diffTime = target.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

export function formatCurrency(num: number | string | undefined | null): string {
  if (num === null || num === undefined || num === '') return '0';
  const val = typeof num === 'string' ? parseFloat(num) : num;
  if (isNaN(val)) return '0';
  return val.toLocaleString('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
}

export function maskIBAN(iban: string | undefined | null): string {
  if (!iban || iban.length < 8) return iban || 'N/A';
  return iban.substring(0, 4) + '****' + iban.substring(iban.length - 4);
}

export function formatDate(dateStr: string | undefined | null): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

export function timeToMinutes(timeStr: string | undefined | null): number {
  if (!timeStr) return 0;
  const [h, m] = timeStr.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function minutesToTimeStr(minutes: number): string {
  const isNeg = minutes < 0;
  const absMin = Math.abs(minutes);
  const h = Math.floor(absMin / 60);
  const m = absMin % 60;
  return `${isNeg ? '-' : ''}${h}h ${m}m`;
}

export function formatTime12(timeStr: string | undefined | null): string {
  if (!timeStr) return '';
  const [h, m] = timeStr.split(':').map(Number);
  const ampm = (h || 0) >= 12 ? 'PM' : 'AM';
  const h12 = (h || 0) % 12 || 12;
  return `${h12}:${(m || 0).toString().padStart(2, '0')} ${ampm}`;
}

export function getDayOfWeek(dateStr: string): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleDateString('en-US', { weekday: 'long' });
}

// Commission calculation logic
export function calculateEmployeeCommissions(emp: Employee, settings: SystemSettings) {
  const salesTarget = Number(emp.saleTargetRate) || 0;
  const actualSales = Number(emp.totalSalesRate) || 0;
  const salesRate = Number(emp.saleCommissionRate) || settings.salesCommRate;

  let serviceCommission = 0;
  let serviceEligible = false;
  if (salesTarget > 0 && actualSales >= salesTarget) {
    serviceCommission = actualSales * (salesRate / 100);
    serviceEligible = true;
  } else if (salesTarget === 0 && actualSales > 0) {
    serviceCommission = actualSales * (salesRate / 100);
    serviceEligible = true;
  }

  const productSales = Number(emp.prodTotalSales) || 0;
  const productRate = Number(emp.prodSaleCommission) || settings.productCommRate;
  let productCommission = 0;
  let productEligible = false;
  if (productSales > 0) {
    productCommission = productSales * (productRate / 100);
    productEligible = true;
  }

  const businessGross = Number(emp.businessGross) || 0;
  const businessTarget = settings.businessTarget || 200000;
  const businessRate = Number(emp.businessTargetRate) || settings.businessCommRate;
  let businessCommission = 0;
  let businessEligible = false;
  if (businessGross >= businessTarget) {
    businessCommission = businessGross * (businessRate / 100);
    businessEligible = true;
  }

  return {
    service: serviceCommission,
    serviceEligible,
    serviceTarget: salesTarget,
    serviceActual: actualSales,
    serviceRate: salesRate,
    serviceAchievement: salesTarget > 0 ? (actualSales / salesTarget) * 100 : 0,

    product: productCommission,
    productEligible,
    productSales,
    productRate,

    business: businessCommission,
    businessEligible,
    businessTarget,
    businessGross,
    businessRate,
    businessAchievement: businessTarget > 0 ? (businessGross / businessTarget) * 100 : 0,

    total: serviceCommission + productCommission + businessCommission,
  };
}

// Local Storage & IndexedDB Unified Storage Engine
const STORAGE_PREFIX = 'cosmos_hr_';

class CosmosDatabase {
  private inMemoryCache: {
    employees: Employee[];
    payroll: PayrollRecord[];
    attendance: AttendanceRecord[];
    leaves: LeaveRecord[];
    tickets: FlightTicketRecord[];
    extraTime: ExtraTimeTransaction[];
    certificates: Certificate[];
    settings: SystemSettings;
    banks: BankInfo[];
    audit: AuditLogItem[];
  } = {
    employees: [],
    payroll: [],
    attendance: [],
    leaves: [],
    tickets: [],
    extraTime: [],
    certificates: [],
    settings: DEFAULT_SETTINGS,
    banks: DEFAULT_QATAR_BANKS,
    audit: [],
  };

  private initialized = false;

  public async init(): Promise<void> {
    if (this.initialized) return;

    try {
      const storedEmployees = localStorage.getItem(STORAGE_PREFIX + 'employees');
      if (storedEmployees) {
        this.inMemoryCache.employees = JSON.parse(storedEmployees);
      } else {
        this.inMemoryCache.employees = [...SAMPLE_EMPLOYEES];
        this.saveEmployees();
      }

      const storedPayroll = localStorage.getItem(STORAGE_PREFIX + 'payroll');
      if (storedPayroll) {
        this.inMemoryCache.payroll = JSON.parse(storedPayroll);
      } else {
        // Seed default sample payroll records for current and past month
        this.inMemoryCache.payroll = [
          {
            id: 'PAY-CBSE20243-2026-October',
            employeeId: 'CBSE20243',
            month: 'October',
            year: '2026',
            basicSalary: 4000,
            allowances: 6200,
            commissions: 4160,
            deductions: 3060,
            netSalary: 11300,
            paidAmount: 11300,
            status: 'Paid',
            paymentDate: '2026-10-20',
            notes: 'October payroll paid via Doha Bank',
            commissionBreakdown: { service: 3850, product: 310, business: 0 },
          },
          {
            id: 'PAY-CBSE20244-2026-October',
            employeeId: 'CBSE20244',
            month: 'October',
            year: '2026',
            basicSalary: 2500,
            allowances: 6491,
            commissions: 2575,
            deductions: 0,
            netSalary: 11566,
            paidAmount: 0,
            status: 'Approved',
            paymentDate: '',
            notes: 'Manager October payroll verified',
            commissionBreakdown: { service: 2400, product: 175, business: 0 },
          },
        ];
        this.savePayroll();
      }

      const storedAttendance = localStorage.getItem(STORAGE_PREFIX + 'attendance');
      if (storedAttendance) {
        this.inMemoryCache.attendance = JSON.parse(storedAttendance);
      } else {
        // Seed full month single-shift attendance (Morning to Night: 09:00 - 21:00)
        const seedRecords: AttendanceRecord[] = [];
        const staffList = [
          { id: 'CBSE20244', name: 'KUMUSHAI DUISHOGULOVA', offDayIndex: 2, offDayName: 'Tuesday' },
          { id: 'CBSE20243', name: 'ATYRGUL AIAZOVA', offDayIndex: 1, offDayName: 'Monday' },
        ];

        for (let day = 1; day <= 21; day++) {
          const dayStr = day.toString().padStart(2, '0');
          const dateStr = `2026-10-${dayStr}`;
          const dateObj = new Date(dateStr);
          const dayOfWeek = dateObj.getDay();

          staffList.forEach((st, sIdx) => {
            if (dayOfWeek === st.offDayIndex) {
              seedRecords.push({
                attId: `ATT-${st.id}-${dateStr}`,
                employeeId: st.id,
                employeeName: st.name,
                date: dateStr,
                shiftType: 'Single Shift',
                scheduledStart: '09:00',
                scheduledEnd: '21:00',
                timeIn: '',
                timeOut: '',
                breakStart: '',
                breakEnd: '',
                totalWorkMinutes: 0,
                scheduledWorkMinutes: 0,
                extraMinutes: 0,
                shortMinutes: 0,
                status: 'Day Off',
                remarks: `Assigned Weekly Day Off (${st.offDayName})`,
                createdAt: new Date().toISOString(),
                createdBy: 'System',
              });
              return;
            }

            let inH = 8;
            let inM = 50 + ((day + sIdx) % 3) * 5; // 08:50, 08:55, 09:00
            let outH = 21;
            let outM = ((day * 7 + sIdx * 5) % 4) * 10; // 21:00, 21:10, 21:20, 21:30
            let isLate = false;

            if (day === 8 && sIdx === 1) {
              inH = 9;
              inM = 25;
              isLate = true;
            }

            const timeIn = `${inH.toString().padStart(2, '0')}:${inM.toString().padStart(2, '0')}`;
            const timeOut = `${outH.toString().padStart(2, '0')}:${outM.toString().padStart(2, '0')}`;
            const totalWorkMinutes = (outH * 60 + outM) - (inH * 60 + inM);
            const scheduledWorkMinutes = 720; // 12 hours (09:00 - 21:00)
            const extraMinutes = totalWorkMinutes > scheduledWorkMinutes ? totalWorkMinutes - scheduledWorkMinutes : 0;
            const shortMinutes = totalWorkMinutes < scheduledWorkMinutes ? scheduledWorkMinutes - totalWorkMinutes : 0;

            seedRecords.push({
              attId: `ATT-${st.id}-${dateStr}`,
              employeeId: st.id,
              employeeName: st.name,
              date: dateStr,
              shiftType: 'Single Shift',
              scheduledStart: '09:00',
              scheduledEnd: '21:00',
              timeIn,
              timeOut,
              breakStart: '13:00',
              breakEnd: '14:00',
              totalWorkMinutes,
              scheduledWorkMinutes,
              extraMinutes,
              shortMinutes,
              status: isLate ? 'Late' : 'Present',
              remarks: extraMinutes > 0 ? `+${minutesToTimeStr(extraMinutes)} extra-time worked` : isLate ? 'Late arrival (-25m short)' : 'Morning to night salon shift completed',
              createdAt: new Date().toISOString(),
              createdBy: 'Admin',
            });
          });
        }

        this.inMemoryCache.attendance = seedRecords;
        this.saveAttendance();
      }

      const storedLeaves = localStorage.getItem(STORAGE_PREFIX + 'leaves');
      if (storedLeaves) this.inMemoryCache.leaves = JSON.parse(storedLeaves);

      const storedTickets = localStorage.getItem(STORAGE_PREFIX + 'tickets');
      if (storedTickets) this.inMemoryCache.tickets = JSON.parse(storedTickets);

      const storedExtraTime = localStorage.getItem(STORAGE_PREFIX + 'extraTime');
      if (storedExtraTime) this.inMemoryCache.extraTime = JSON.parse(storedExtraTime);

      const storedCertificates = localStorage.getItem(STORAGE_PREFIX + 'certificates');
      if (storedCertificates) this.inMemoryCache.certificates = JSON.parse(storedCertificates);

      const storedSettings = localStorage.getItem(STORAGE_PREFIX + 'settings');
      if (storedSettings) this.inMemoryCache.settings = { ...DEFAULT_SETTINGS, ...JSON.parse(storedSettings) };

      const storedBanks = localStorage.getItem(STORAGE_PREFIX + 'banks');
      if (storedBanks) this.inMemoryCache.banks = JSON.parse(storedBanks);

      const storedAudit = localStorage.getItem(STORAGE_PREFIX + 'audit');
      if (storedAudit) {
        this.inMemoryCache.audit = JSON.parse(storedAudit);
      } else {
        this.logAudit('SYSTEM_INITIALIZED', 'Cosmos HR & Payroll system loaded with initial Qatar configuration.');
      }

      this.initialized = true;
    } catch (e) {
      console.error('Storage initialization failed, using in-memory state', e);
      this.initialized = true;
    }
  }

  // Audits
  public async logAudit(action: string, details: string): Promise<void> {
    const item: AuditLogItem = {
      id: Date.now() + Math.floor(Math.random() * 1000),
      timestamp: new Date().toISOString(),
      action,
      details,
    };
    this.inMemoryCache.audit.unshift(item);
    if (this.inMemoryCache.audit.length > 500) {
      this.inMemoryCache.audit = this.inMemoryCache.audit.slice(0, 500);
    }
    try {
      localStorage.setItem(STORAGE_PREFIX + 'audit', JSON.stringify(this.inMemoryCache.audit));
    } catch {}
  }

  public getAuditLogs(): AuditLogItem[] {
    return this.inMemoryCache.audit;
  }

  // Employees
  public getEmployees(): Employee[] {
    return [...this.inMemoryCache.employees];
  }

  public getEmployee(id: string): Employee | undefined {
    return this.inMemoryCache.employees.find((e) => e.employeeId === id);
  }

  public async saveEmployee(emp: Employee): Promise<void> {
    const idx = this.inMemoryCache.employees.findIndex((e) => e.employeeId === emp.employeeId);
    if (idx >= 0) {
      this.inMemoryCache.employees[idx] = { ...emp };
      await this.logAudit('EMPLOYEE_UPDATED', `Updated record for ${emp.employeeName} (${emp.employeeId})`);
    } else {
      this.inMemoryCache.employees.push({ ...emp });
      await this.logAudit('EMPLOYEE_ADDED', `Registered new employee ${emp.employeeName} (${emp.employeeId})`);
    }
    this.saveEmployees();
  }

  public async updateEmployeeOffDay(employeeId: string, offDay: string): Promise<void> {
    const emp = this.getEmployee(employeeId);
    if (!emp) return;
    emp.weeklyOffDay = offDay;
    await this.saveEmployee(emp);
    await this.logAudit('OFF_DAY_UPDATED', `Set weekly day off for ${emp.employeeName} to ${offDay}`);
  }

  public async deleteEmployee(empId: string): Promise<void> {
    const emp = this.getEmployee(empId);
    this.inMemoryCache.employees = this.inMemoryCache.employees.filter((e) => e.employeeId !== empId);
    this.inMemoryCache.payroll = this.inMemoryCache.payroll.filter((p) => p.employeeId !== empId);
    this.inMemoryCache.attendance = this.inMemoryCache.attendance.filter((a) => a.employeeId !== empId);
    this.inMemoryCache.leaves = this.inMemoryCache.leaves.filter((l) => l.employeeId !== empId);
    this.inMemoryCache.tickets = this.inMemoryCache.tickets.filter((t) => t.employeeId !== empId);
    this.inMemoryCache.extraTime = this.inMemoryCache.extraTime.filter((et) => et.employeeId !== empId);
    this.saveEmployees();
    this.savePayroll();
    this.saveAttendance();
    this.saveLeaves();
    this.saveTickets();
    this.saveExtraTime();
    await this.logAudit('EMPLOYEE_DELETED', `Deleted employee record and associated history for ${emp?.employeeName || empId}`);
  }

  public getNextNo(): number {
    if (this.inMemoryCache.employees.length === 0) return 1;
    const nos = this.inMemoryCache.employees.map((e) => parseInt(String(e.no)) || 0);
    return Math.max(...nos, 0) + 1;
  }

  private saveEmployees() {
    try {
      localStorage.setItem(STORAGE_PREFIX + 'employees', JSON.stringify(this.inMemoryCache.employees));
    } catch (e) {
      console.warn('LocalStorage save failed', e);
    }
  }

  // Payroll
  public getPayrolls(): PayrollRecord[] {
    return [...this.inMemoryCache.payroll];
  }

  public async savePayrollRecord(record: PayrollRecord): Promise<void> {
    const idx = this.inMemoryCache.payroll.findIndex((p) => p.id === record.id);
    if (idx >= 0) {
      this.inMemoryCache.payroll[idx] = { ...record };
    } else {
      this.inMemoryCache.payroll.unshift({ ...record });
    }
    this.savePayroll();
  }

  public async deletePayrollRecord(id: string): Promise<void> {
    this.inMemoryCache.payroll = this.inMemoryCache.payroll.filter((p) => p.id !== id);
    this.savePayroll();
    await this.logAudit('PAYROLL_DELETED', `Deleted payroll record ${id}`);
  }

  private savePayroll() {
    try {
      localStorage.setItem(STORAGE_PREFIX + 'payroll', JSON.stringify(this.inMemoryCache.payroll));
    } catch {}
  }

  // Attendance
  public getAttendance(): AttendanceRecord[] {
    return [...this.inMemoryCache.attendance];
  }

  public async saveAttendanceRecord(record: AttendanceRecord): Promise<void> {
    const idx = this.inMemoryCache.attendance.findIndex((a) => a.attId === record.attId);
    if (idx >= 0) {
      this.inMemoryCache.attendance[idx] = { ...record };
    } else {
      this.inMemoryCache.attendance.unshift({ ...record });
    }
    this.saveAttendance();

    // Log extra time transaction
    if (record.extraMinutes !== 0) {
      await this.recordExtraTimeTransaction({
        extraId: `ET-${record.employeeId}-${Date.now()}`,
        employeeId: record.employeeId,
        date: record.date,
        type: record.extraMinutes > 0 ? 'Earned' : 'Used',
        minutes: Math.abs(record.extraMinutes),
        reason: `Attendance on ${record.date} (${record.status})`,
        balanceAfter: this.getEmployeeExtraTimeBalance(record.employeeId) + record.extraMinutes,
        approvedBy: 'Admin',
        createdAt: new Date().toISOString(),
      });
    }

    await this.logAudit('ATTENDANCE_RECORDED', `Logged attendance for ${record.employeeName} on ${record.date} (${record.status})`);
  }

  public async deleteAttendanceRecord(id: string): Promise<void> {
    this.inMemoryCache.attendance = this.inMemoryCache.attendance.filter((a) => a.attId !== id);
    this.saveAttendance();
    await this.logAudit('ATTENDANCE_DELETED', `Deleted attendance record ${id}`);
  }

  private saveAttendance() {
    try {
      localStorage.setItem(STORAGE_PREFIX + 'attendance', JSON.stringify(this.inMemoryCache.attendance));
    } catch {}
  }

  // Extra Time Transactions
  public getExtraTimeTransactions(): ExtraTimeTransaction[] {
    return [...this.inMemoryCache.extraTime];
  }

  public async recordExtraTimeTransaction(tx: ExtraTimeTransaction): Promise<void> {
    this.inMemoryCache.extraTime.unshift(tx);
    this.saveExtraTime();
  }

  public getEmployeeExtraTimeBalance(employeeId: string): number {
    const records = this.inMemoryCache.extraTime.filter((e) => e.employeeId === employeeId);
    let balance = 0;
    records.forEach((r) => {
      if (r.type === 'Earned') balance += r.minutes;
      if (r.type === 'Used') balance -= r.minutes;
    });
    return balance;
  }

  private saveExtraTime() {
    try {
      localStorage.setItem(STORAGE_PREFIX + 'extraTime', JSON.stringify(this.inMemoryCache.extraTime));
    } catch {}
  }

  // Leaves
  public getLeaves(): LeaveRecord[] {
    return [...this.inMemoryCache.leaves];
  }

  public async saveLeaveRecord(record: LeaveRecord): Promise<void> {
    const idx = this.inMemoryCache.leaves.findIndex((l) => l.leaveId === record.leaveId);
    if (idx >= 0) {
      this.inMemoryCache.leaves[idx] = { ...record };
    } else {
      this.inMemoryCache.leaves.unshift({ ...record });
    }
    this.saveLeaves();
    await this.logAudit('LEAVE_REQUESTED', `${record.employeeName} requested ${record.days} days of ${record.leaveType}`);
  }

  public async deleteLeaveRecord(id: string): Promise<void> {
    this.inMemoryCache.leaves = this.inMemoryCache.leaves.filter((l) => l.leaveId !== id);
    this.saveLeaves();
    await this.logAudit('LEAVE_DELETED', `Deleted leave record ${id}`);
  }

  private saveLeaves() {
    try {
      localStorage.setItem(STORAGE_PREFIX + 'leaves', JSON.stringify(this.inMemoryCache.leaves));
    } catch {}
  }

  // Flight Tickets
  public getTickets(): FlightTicketRecord[] {
    return [...this.inMemoryCache.tickets];
  }

  public async saveTicketRecord(record: FlightTicketRecord): Promise<void> {
    const idx = this.inMemoryCache.tickets.findIndex((t) => t.ticketId === record.ticketId);
    if (idx >= 0) {
      this.inMemoryCache.tickets[idx] = { ...record };
    } else {
      this.inMemoryCache.tickets.unshift({ ...record });
    }
    this.saveTickets();

    // Update employee ticket fields
    const emp = this.getEmployee(record.employeeId);
    if (emp) {
      emp.nextTicketDate = record.eligibleDate;
      emp.ticketStatus = record.status;
      emp.ticketDestination = record.destination;
      this.saveEmployees();
    }

    await this.logAudit('TICKET_RECORDED', `Flight ticket for ${record.employeeName}: ${record.destination} (${record.status})`);
  }

  public async deleteTicketRecord(id: string): Promise<void> {
    this.inMemoryCache.tickets = this.inMemoryCache.tickets.filter((t) => t.ticketId !== id);
    this.saveTickets();
    await this.logAudit('TICKET_DELETED', `Deleted ticket record ${id}`);
  }

  private saveTickets() {
    try {
      localStorage.setItem(STORAGE_PREFIX + 'tickets', JSON.stringify(this.inMemoryCache.tickets));
    } catch {}
  }

  // Certificates
  public getCertificates(): Certificate[] {
    return [...this.inMemoryCache.certificates];
  }

  public async saveCertificate(cert: Certificate): Promise<void> {
    const idx = this.inMemoryCache.certificates.findIndex((c) => c.certId === cert.certId);
    if (idx >= 0) {
      this.inMemoryCache.certificates[idx] = { ...cert };
    } else {
      this.inMemoryCache.certificates.unshift({ ...cert });
    }
    this.saveCertificates();

    // Increment cert counter
    this.inMemoryCache.settings.certCounter = (this.inMemoryCache.settings.certCounter || 1) + 1;
    this.saveSettings();

    await this.logAudit('CERTIFICATE_SAVED', `Generated ${cert.certTypeName} for ${cert.employeeName}, Ref: ${cert.reference}`);
  }

  public async deleteCertificate(id: string): Promise<void> {
    this.inMemoryCache.certificates = this.inMemoryCache.certificates.filter((c) => c.certId !== id);
    this.saveCertificates();
    await this.logAudit('CERTIFICATE_DELETED', `Deleted certificate record ${id}`);
  }

  private saveCertificates() {
    try {
      localStorage.setItem(STORAGE_PREFIX + 'certificates', JSON.stringify(this.inMemoryCache.certificates));
    } catch {}
  }

  // Settings & Banks
  public getSettings(): SystemSettings {
    return { ...this.inMemoryCache.settings };
  }

  public async saveSettings(newSettings?: Partial<SystemSettings>): Promise<void> {
    if (newSettings) {
      this.inMemoryCache.settings = { ...this.inMemoryCache.settings, ...newSettings };
    }
    try {
      localStorage.setItem(STORAGE_PREFIX + 'settings', JSON.stringify(this.inMemoryCache.settings));
      await this.logAudit('SETTINGS_UPDATED', 'System settings saved successfully');
    } catch {}
  }

  public getBanks(): BankInfo[] {
    return [...this.inMemoryCache.banks];
  }

  public async addBank(bank: BankInfo): Promise<void> {
    if (!this.inMemoryCache.banks.find((b) => b.short === bank.short)) {
      this.inMemoryCache.banks.push(bank);
      localStorage.setItem(STORAGE_PREFIX + 'banks', JSON.stringify(this.inMemoryCache.banks));
      await this.logAudit('BANK_ADDED', `Added custom bank ${bank.name} (${bank.short})`);
    }
  }

  public async removeBank(shortName: string): Promise<void> {
    this.inMemoryCache.banks = this.inMemoryCache.banks.filter((b) => b.short !== shortName);
    localStorage.setItem(STORAGE_PREFIX + 'banks', JSON.stringify(this.inMemoryCache.banks));
    await this.logAudit('BANK_REMOVED', `Removed bank ${shortName}`);
  }

  // Full Backup / Restore
  public getFullBackupJSON(): string {
    const data = {
      employees: this.inMemoryCache.employees,
      payroll: this.inMemoryCache.payroll,
      attendance: this.inMemoryCache.attendance,
      leaves: this.inMemoryCache.leaves,
      tickets: this.inMemoryCache.tickets,
      extraTime: this.inMemoryCache.extraTime,
      certificates: this.inMemoryCache.certificates,
      settings: this.inMemoryCache.settings,
      banks: this.inMemoryCache.banks,
      audit: this.inMemoryCache.audit,
      exportedAt: new Date().toISOString(),
    };
    return JSON.stringify(data, null, 2);
  }

  public async restoreFromJSON(jsonString: string): Promise<boolean> {
    try {
      const data = JSON.parse(jsonString);
      if (data.employees) this.inMemoryCache.employees = data.employees;
      if (data.payroll) this.inMemoryCache.payroll = data.payroll;
      if (data.attendance) this.inMemoryCache.attendance = data.attendance;
      if (data.leaves) this.inMemoryCache.leaves = data.leaves;
      if (data.tickets) this.inMemoryCache.tickets = data.tickets;
      if (data.extraTime) this.inMemoryCache.extraTime = data.extraTime;
      if (data.certificates) this.inMemoryCache.certificates = data.certificates;
      if (data.settings) this.inMemoryCache.settings = data.settings;
      if (data.banks) this.inMemoryCache.banks = data.banks;
      if (data.audit) this.inMemoryCache.audit = data.audit;

      this.saveEmployees();
      this.savePayroll();
      this.saveAttendance();
      this.saveLeaves();
      this.saveTickets();
      this.saveExtraTime();
      this.saveCertificates();
      this.saveSettings();
      localStorage.setItem(STORAGE_PREFIX + 'banks', JSON.stringify(this.inMemoryCache.banks));

      await this.logAudit('DATABASE_RESTORED', 'Entire database restored from JSON backup file');
      return true;
    } catch (err) {
      console.error('Failed to restore backup', err);
      return false;
    }
  }

  // Reset to sample data
  public async loadSampleData(): Promise<void> {
    this.inMemoryCache.employees = [...SAMPLE_EMPLOYEES];
    this.saveEmployees();
    await this.logAudit('SAMPLE_DATA_LOADED', 'Reset/Loaded official sample salon employees');
  }
}

export const db = new CosmosDatabase();
