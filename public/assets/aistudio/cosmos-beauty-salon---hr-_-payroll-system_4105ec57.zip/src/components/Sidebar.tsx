import React from 'react';
import {
  LayoutDashboard,
  UserPlus,
  Users,
  UserX,
  CreditCard,
  Clock,
  CalendarDays,
  FileText,
  Archive,
  FileSpreadsheet,
  Database,
  History,
  Settings,
  Sparkles,
} from 'lucide-react';

export type ViewType =
  | 'dashboard'
  | 'add-employee'
  | 'active-employees'
  | 'unemployed'
  | 'monthly-payroll'
  | 'attendance'
  | 'leave-management'
  | 'certificate-generator'
  | 'certificate-archive'
  | 'import-export'
  | 'backup-restore'
  | 'audit-log'
  | 'settings';

interface SidebarProps {
  activeView: ViewType;
  onSelectView: (view: ViewType) => void;
  activeCount: number;
  unemployedCount: number;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeView,
  onSelectView,
  activeCount,
  unemployedCount,
  isOpenMobile,
  onCloseMobile,
}) => {
  const navItems: { id: ViewType; label: string; icon: React.ReactNode; badge?: number | string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'add-employee', label: 'Add Employee', icon: <UserPlus className="w-4 h-4" /> },
    {
      id: 'active-employees',
      label: 'Active Employees',
      icon: <Users className="w-4 h-4" />,
      badge: activeCount,
    },
    {
      id: 'unemployed',
      label: 'Unemployed / Former',
      icon: <UserX className="w-4 h-4" />,
      badge: unemployedCount > 0 ? unemployedCount : undefined,
    },
    { id: 'monthly-payroll', label: 'Monthly Payroll', icon: <CreditCard className="w-4 h-4" /> },
    { id: 'attendance', label: 'Attendance Schedule', icon: <Clock className="w-4 h-4" /> },
    { id: 'leave-management', label: 'Leave & Tickets', icon: <CalendarDays className="w-4 h-4" /> },
    { id: 'certificate-generator', label: 'Certificate Generator', icon: <FileText className="w-4 h-4" /> },
    { id: 'certificate-archive', label: 'Certificate Archive', icon: <Archive className="w-4 h-4" /> },
    { id: 'import-export', label: 'Excel Import / Export', icon: <FileSpreadsheet className="w-4 h-4" /> },
    { id: 'backup-restore', label: 'Backup & Restore', icon: <Database className="w-4 h-4" /> },
    { id: 'audit-log', label: 'Audit Log', icon: <History className="w-4 h-4" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 bg-slate-950/60 z-40 lg:hidden backdrop-blur-xs"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed top-0 bottom-0 left-0 z-50 w-64 bg-slate-900 border-r border-slate-800 text-slate-300 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand header */}
        <div className="p-5 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-linear-to-br from-amber-400 via-rose-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-rose-950/30">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="text-sm font-bold tracking-tight text-white flex items-center gap-1.5">
                COSMOS HR
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Salon Payroll & Staff Pro</p>
            </div>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5 custom-scrollbar">
          {navItems.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectView(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
                }`}
              >
                <div className="flex items-center gap-3 truncate">
                  <span className={`${isActive ? 'text-white' : 'text-slate-400'}`}>
                    {item.icon}
                  </span>
                  <span className="truncate">{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-medium ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : item.id === 'unemployed'
                        ? 'bg-amber-900/40 text-amber-300 border border-amber-700/40'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer info */}
        <div className="p-3 border-t border-slate-800 text-[11px] text-slate-400 bg-slate-950/40">
          <div className="flex items-center justify-between">
            <span>Doha, Qatar</span>
            <span className="font-mono text-[10px] text-emerald-400">QAR (ريال)</span>
          </div>
        </div>
      </aside>
    </>
  );
};
