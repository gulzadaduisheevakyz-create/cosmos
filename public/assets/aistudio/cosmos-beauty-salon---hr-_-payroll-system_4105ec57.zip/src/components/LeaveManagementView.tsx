import React, { useState } from 'react';
import { Plane, Calendar, FileSpreadsheet, Plus, CheckCircle, Clock } from 'lucide-react';
import { Employee, LeaveRecord, FlightTicketRecord } from '../types';
import { db, formatDate, formatCurrency } from '../services/db';
import { exportLeaveAndTicketsToExcel } from '../services/excel';

interface LeaveManagementViewProps {
  employees: Employee[];
  leaves: LeaveRecord[];
  tickets: FlightTicketRecord[];
  onRefresh: () => void;
  onOpenEmployee: (empId: string) => void;
}

export const LeaveManagementView: React.FC<LeaveManagementViewProps> = ({
  employees,
  leaves,
  tickets,
  onRefresh,
  onOpenEmployee,
}) => {
  const [selectedEmpFilter, setSelectedEmpFilter] = useState('');

  // Modals
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [showTicketModal, setShowTicketModal] = useState(false);

  // Leave Form
  const [leaveEmpId, setLeaveEmpId] = useState('');
  const [leaveType, setLeaveType] = useState('Annual Leave');
  const [startDate, setStartDate] = useState(new Date().toISOString().slice(0, 10));
  const [endDate, setEndDate] = useState(new Date().toISOString().slice(0, 10));
  const [paidStatus, setPaidStatus] = useState<'Paid' | 'Unpaid'>('Paid');
  const [leaveRemarks, setLeaveRemarks] = useState('');

  // Ticket Form
  const [ticketEmpId, setTicketEmpId] = useState('');
  const [ticketPeriod, setTicketPeriod] = useState('2024-2026');
  const [eligibleDate, setEligibleDate] = useState(new Date().toISOString().slice(0, 10));
  const [bookedDate, setBookedDate] = useState('');
  const [destination, setDestination] = useState('');
  const [cost, setCost] = useState<number>(0);
  const [ticketStatus, setTicketStatus] = useState<FlightTicketRecord['status']>('Eligible');

  const activeEmployees = employees.filter((e) => e.status !== 'Unemployed');
  const displayedEmployees = selectedEmpFilter
    ? activeEmployees.filter((e) => e.employeeId === selectedEmpFilter)
    : activeEmployees;

  // Handle open leave request modal
  const handleOpenLeaveModal = (empId?: string) => {
    setLeaveEmpId(empId || activeEmployees[0]?.employeeId || '');
    setLeaveType('Annual Leave');
    setStartDate(new Date().toISOString().slice(0, 10));
    setEndDate(new Date().toISOString().slice(0, 10));
    setPaidStatus('Paid');
    setLeaveRemarks('');
    setShowLeaveModal(true);
  };

  // Submit Leave Request
  const handleSaveLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leaveEmpId) return;

    const emp = employees.find((item) => item.employeeId === leaveEmpId);
    if (!emp) return;

    const start = new Date(startDate);
    const end = new Date(endDate);
    const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;

    if (days <= 0) {
      alert('End date must be on or after start date.');
      return;
    }

    const newRecord: LeaveRecord = {
      leaveId: `LEAVE-${emp.employeeId}-${Date.now()}`,
      employeeId: emp.employeeId,
      employeeName: emp.employeeName,
      startDate,
      endDate,
      days,
      leaveType,
      paidStatus,
      status: 'Pending',
      period: `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, '0')}`,
      remarks: leaveRemarks,
      requestedDate: new Date().toISOString(),
    };

    await db.saveLeaveRecord(newRecord);
    setShowLeaveModal(false);
    onRefresh();
    alert(`✅ Leave request for ${days} days submitted for ${emp.employeeName}!`);
  };

  // Handle open ticket modal
  const handleOpenTicketModal = (empId?: string) => {
    const emp = employees.find((e) => e.employeeId === empId) || activeEmployees[0];
    setTicketEmpId(emp?.employeeId || '');
    setTicketPeriod('2024-2026');
    setEligibleDate(emp?.nextTicketDate || new Date().toISOString().slice(0, 10));
    setBookedDate('');
    setDestination(emp?.ticketDestination || '');
    setCost(0);
    setTicketStatus('Eligible');
    setShowTicketModal(true);
  };

  // Submit Flight Ticket
  const handleSaveTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketEmpId) return;

    const emp = employees.find((item) => item.employeeId === ticketEmpId);
    if (!emp) return;

    const record: FlightTicketRecord = {
      ticketId: `TICKET-${emp.employeeId}-${Date.now()}`,
      employeeId: emp.employeeId,
      employeeName: emp.employeeName,
      period: ticketPeriod,
      eligibleDate,
      bookedDate,
      destination,
      cost,
      status: ticketStatus,
      createdAt: new Date().toISOString(),
    };

    await db.saveTicketRecord(record);
    setShowTicketModal(false);
    onRefresh();
    alert(`✅ Flight ticket recorded for ${emp.employeeName}!`);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Plane className="w-5 h-5 text-blue-600" />
            <span>Annual Leave &amp; Flight Ticket Management</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Annual leave balance (Qatar Labor Law 30-day divisor), daily wage encashment, and biennial home flight allowances.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <select
            value={selectedEmpFilter}
            onChange={(e) => setSelectedEmpFilter(e.target.value)}
            className="text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg max-w-[200px]"
          >
            <option value="">All Employees</option>
            {activeEmployees.map((e) => (
              <option key={e.employeeId} value={e.employeeId}>
                {e.employeeName}
              </option>
            ))}
          </select>

          <button
            onClick={() => exportLeaveAndTicketsToExcel(employees, leaves, tickets)}
            className="px-3 py-2 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Export Excel</span>
          </button>

          <button
            onClick={() => handleOpenLeaveModal()}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Request Leave</span>
          </button>

          <button
            onClick={() => handleOpenTicketModal()}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
          >
            <Plane className="w-3.5 h-3.5" />
            <span>Record Flight Ticket</span>
          </button>
        </div>
      </div>

      {/* Summary Table by Employee */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            Employee Leave Balance &amp; Flight Ticket Accrual
          </h3>
          <span className="text-xs text-slate-400">
            Daily Encashment Rate = Basic Salary ÷ 30 Days
          </span>
        </div>

        <div className="overflow-x-auto max-h-[600px] custom-scrollbar">
          <table className="w-full text-xs text-left border-collapse min-w-[1250px]">
            <thead className="bg-slate-50 text-slate-600 font-semibold sticky top-0 z-10 border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Employee ID</th>
                <th className="py-2.5 px-3">Name</th>
                <th className="py-2.5 px-3">Joining Date</th>
                <th className="py-2.5 px-3 text-right">Entitlement</th>
                <th className="py-2.5 px-3 text-right">Taken</th>
                <th className="py-2.5 px-3 text-right">Pending</th>
                <th className="py-2.5 px-3 text-right font-bold text-slate-900 bg-slate-100/60">
                  Remaining
                </th>
                <th className="py-2.5 px-3 text-right">Daily Rate</th>
                <th className="py-2.5 px-3 text-right text-emerald-600">Leave Value</th>
                <th className="py-2.5 px-3">Next Ticket Date</th>
                <th className="py-2.5 px-3">Ticket Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {displayedEmployees.map((emp) => {
                const empLeaves = leaves.filter((l) => l.employeeId === emp.employeeId);
                const entitlement = Number(emp.leaveEntitlement) || 21;
                const taken = empLeaves
                  .filter((l) => l.status === 'Approved')
                  .reduce((sum, l) => sum + (Number(l.days) || 0), 0);
                const pending = empLeaves
                  .filter((l) => l.status === 'Pending')
                  .reduce((sum, l) => sum + (Number(l.days) || 0), 0);
                const remaining = entitlement - taken - pending;

                const basic = Number(emp.basicSalary) || 0;
                const dailyRate = basic / 30;
                const leavePaymentValue = remaining * dailyRate;

                return (
                  <tr
                    key={emp.employeeId}
                    onClick={() => onOpenEmployee(emp.employeeId)}
                    className="hover:bg-blue-50/40 cursor-pointer transition-colors"
                  >
                    <td className="py-2.5 px-3 font-bold font-mono text-slate-900">
                      {emp.employeeId}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">{emp.employeeName}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-600">{formatDate(emp.joiningDate)}</td>
                    <td className="py-2.5 px-3 text-right tabular-nums">{entitlement} d</td>
                    <td className="py-2.5 px-3 text-right tabular-nums text-rose-600 font-medium">
                      {taken} d
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums text-amber-600 font-medium">
                      {pending} d
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-bold text-slate-900 bg-slate-100/60">
                      {remaining} d
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums text-slate-700">
                      QAR {formatCurrency(dailyRate)}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-bold text-emerald-600">
                      QAR {formatCurrency(leavePaymentValue)}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-700">
                      {emp.nextTicketDate ? formatDate(emp.nextTicketDate) : '-'}
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          emp.ticketStatus === 'Eligible'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : emp.ticketStatus === 'Booked'
                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                            : emp.ticketStatus === 'Used'
                            ? 'bg-slate-100 text-slate-600'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {emp.ticketStatus || 'Not Eligible'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenLeaveModal(emp.employeeId)}
                          className="px-2 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded transition-colors"
                        >
                          + Leave
                        </button>
                        <button
                          onClick={() => handleOpenTicketModal(emp.employeeId)}
                          className="px-2 py-1 text-xs font-medium text-cyan-700 bg-cyan-50 hover:bg-cyan-100 rounded transition-colors"
                        >
                          + Ticket
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Request Leave */}
      {showLeaveModal && (
        <div className="fixed inset-0 bg-slate-950/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <Calendar className="w-4 h-4 text-blue-400" />
                <span>Submit Annual / Sick Leave Request</span>
              </h3>
              <button
                onClick={() => setShowLeaveModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveLeave} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Employee *
                </label>
                <select
                  value={leaveEmpId}
                  onChange={(e) => setLeaveEmpId(e.target.value)}
                  required
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                >
                  {activeEmployees.map((e) => (
                    <option key={e.employeeId} value={e.employeeId}>
                      {e.employeeName} ({e.employeeId})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Leave Type *
                </label>
                <select
                  value={leaveType}
                  onChange={(e) => setLeaveType(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-medium"
                >
                  <option value="Annual Leave">Annual Leave (Official)</option>
                  <option value="Sick Leave">Sick Leave (Medical Certificate)</option>
                  <option value="Emergency Leave">Emergency / Compassionate Leave</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Start Date *
                  </label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    required
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    End Date *
                  </label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    required
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Remuneration Status *
                </label>
                <select
                  value={paidStatus}
                  onChange={(e) => setPaidStatus(e.target.value as 'Paid' | 'Unpaid')}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-medium"
                >
                  <option value="Paid">Paid Leave (Encashable)</option>
                  <option value="Unpaid">Unpaid Leave</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Remarks</label>
                <textarea
                  rows={2}
                  placeholder="e.g. Travel home to Kyrgyzstan for family visit"
                  value={leaveRemarks}
                  onChange={(e) => setLeaveRemarks(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowLeaveModal(false)}
                  className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
                >
                  Submit Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Record Ticket */}
      {showTicketModal && (
        <div className="fixed inset-0 bg-slate-950/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-bold flex items-center gap-2">
                <Plane className="w-4 h-4 text-cyan-400" />
                <span>Record Home Flight Ticket Entitlement</span>
              </h3>
              <button
                onClick={() => setShowTicketModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveTicket} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Employee *
                </label>
                <select
                  value={ticketEmpId}
                  onChange={(e) => setTicketEmpId(e.target.value)}
                  required
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                >
                  {activeEmployees.map((e) => (
                    <option key={e.employeeId} value={e.employeeId}>
                      {e.employeeName} ({e.employeeId})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Cycle Period
                  </label>
                  <input
                    type="text"
                    placeholder="2024-2026"
                    value={ticketPeriod}
                    onChange={(e) => setTicketPeriod(e.target.value)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Eligible Date *
                  </label>
                  <input
                    type="date"
                    value={eligibleDate}
                    onChange={(e) => setEligibleDate(e.target.value)}
                    required
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Booked Date
                  </label>
                  <input
                    type="date"
                    value={bookedDate}
                    onChange={(e) => setBookedDate(e.target.value)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Ticket Cost (QAR)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    value={cost}
                    onChange={(e) => setCost(parseFloat(e.target.value) || 0)}
                    className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono tabular-nums"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Destination Airport / City *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Bishkek (FRU), Kyrgyzstan"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  required
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Current Status
                </label>
                <select
                  value={ticketStatus}
                  onChange={(e) =>
                    setTicketStatus(e.target.value as FlightTicketRecord['status'])
                  }
                  className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-medium"
                >
                  <option value="Eligible">Eligible (Ready for Booking)</option>
                  <option value="Pending">Pending Approval</option>
                  <option value="Approved">Approved by Management</option>
                  <option value="Booked">Ticket Issued &amp; Booked</option>
                  <option value="Used">Flight Taken / Completed</option>
                  <option value="Not Eligible">Not Yet Eligible</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowTicketModal(false)}
                  className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-700 rounded-lg transition-colors"
                >
                  Save Ticket Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
