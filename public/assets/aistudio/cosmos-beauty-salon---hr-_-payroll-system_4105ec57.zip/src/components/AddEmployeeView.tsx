import React, { useState, useEffect } from 'react';
import { Save, ArrowLeft, Plus, Trash2, Calendar, DollarSign, Building2, User, Plane, ShieldCheck } from 'lucide-react';
import { Employee, FutureDeduction, BankInfo } from '../types';
import { db, calculateDaysRemaining } from '../services/db';

interface AddEmployeeViewProps {
  banks: BankInfo[];
  onBack: () => void;
  onSaved: () => void;
}

export const AddEmployeeView: React.FC<AddEmployeeViewProps> = ({ banks, onBack, onSaved }) => {
  const [nextNo, setNextNo] = useState<number>(1);
  const [employeeId, setEmployeeId] = useState<string>('');
  const [contractNo, setContractNo] = useState<string>('');

  // Employment
  const [employerId, setEmployerId] = useState('17-2681-92');
  const [company, setCompany] = useState('COSMOS');
  const [duty, setDuty] = useState('Duty');
  const [accommodation, setAccommodation] = useState('Live In');
  const [contractType, setContractType] = useState('Contract');
  const [joiningDate, setJoiningDate] = useState(new Date().toISOString().slice(0, 10));
  const [endContract, setEndContract] = useState('');
  const [mph, setMph] = useState('NO');
  const [expireMph, setExpireMph] = useState('');
  const [position, setPosition] = useState('');
  const [weeklyOffDay, setWeeklyOffDay] = useState('Monday');

  // Personal
  const [employeeName, setEmployeeName] = useState('');
  const [nationality, setNationality] = useState('KYRGYZSTAN');
  const [mobile, setMobile] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [email, setEmail] = useState('');
  const [passportNumber, setPassportNumber] = useState('');
  const [passportExpiry, setPassportExpiry] = useState('');
  const [passportDays, setPassportDays] = useState('');
  const [residencyQid, setResidencyQid] = useState('');
  const [residencyExpiry, setResidencyExpiry] = useState('');
  const [residencyDays, setResidencyDays] = useState('');

  // Banking
  const [payerBank, setPayerBank] = useState('Doha Bank');
  const [payerBankShort, setPayerBankShort] = useState('DB');
  const [customBankName, setCustomBankName] = useState('');
  const [iban, setIban] = useState('');

  // Salary
  const [basicSalary, setBasicSalary] = useState<number>(3000);
  const [foodAllowance, setFoodAllowance] = useState<number>(1000);
  const [transportAllowance, setTransportAllowance] = useState<number>(1000);
  const [carOperationAllowance, setCarOperationAllowance] = useState<number>(0);
  const [otherAllowance, setOtherAllowance] = useState<number>(0);
  const [limitedTransport, setLimitedTransport] = useState<number>(200);

  // Sales
  const [saleCommissionRate, setSaleCommissionRate] = useState<number>(10);
  const [saleTargetRate, setSaleTargetRate] = useState<number>(0);
  const [totalSalesRate, setTotalSalesRate] = useState<number>(0);
  const [targetSales, setTargetSales] = useState<number>(0);
  const [prodSaleCommission, setProdSaleCommission] = useState<number>(5);
  const [prodSaleTarget, setProdSaleTarget] = useState<number>(0);
  const [prodTotalSales, setProdTotalSales] = useState<number>(0);
  const [businessTargetRate, setBusinessTargetRate] = useState<number>(5);
  const [businessGross, setBusinessGross] = useState<number>(0);
  const [businessBonus, setBusinessBonus] = useState<number>(0);

  // Deductions
  const [deductionCurrent, setDeductionCurrent] = useState<number>(0);
  const [tips, setTips] = useState<number>(0);
  const [outstanding, setOutstanding] = useState<number>(0);
  const [futureDeductions, setFutureDeductions] = useState<FutureDeduction[]>([]);

  // Leave & Tickets
  const [leaveEntitlement, setLeaveEntitlement] = useState<number>(21);
  const [totalCreditLeave, setTotalCreditLeave] = useState<number>(21);
  const [lastLeaveDate, setLastLeaveDate] = useState('');
  const [annualLeaveDays, setAnnualLeaveDays] = useState<number>(0);
  const [annualLeaveStatus, setAnnualLeaveStatus] = useState('Paid');
  const [annualLeavePaidAmt, setAnnualLeavePaidAmt] = useState<number>(0);
  const [annualLeaveRemaining, setAnnualLeaveRemaining] = useState<number>(21);
  const [annualLeaveFees, setAnnualLeaveFees] = useState<number>(0);

  const [ticketCycle, setTicketCycle] = useState<number>(2);
  const [nextTicketDate, setNextTicketDate] = useState('');
  const [ticketStatus, setTicketStatus] = useState('Not Eligible');
  const [ticketDestination, setTicketDestination] = useState('');

  // Confirmation
  const [confirmText, setConfirmText] = useState('I further acknowledge and confirm that I have received Salary');
  const [signature, setSignature] = useState('');
  const [formDate, setFormDate] = useState(new Date().toISOString().slice(0, 10));

  // Initialize auto IDs
  useEffect(() => {
    const num = db.getNextNo();
    setNextNo(num);
    setEmployeeId(`CBSE${20244 + num}`);
    setContractNo(`CBS-${Date.now().toString().slice(-8)}`);

    // Auto set end contract 2 years from today
    const join = new Date();
    join.setFullYear(join.getFullYear() + 2);
    setEndContract(join.toISOString().slice(0, 10));
    setNextTicketDate(join.toISOString().slice(0, 10));
  }, []);

  // Update End Contract & Next Ticket on Joining Date Change
  const handleJoiningDateChange = (date: string) => {
    setJoiningDate(date);
    if (date) {
      const d = new Date(date);
      if (!isNaN(d.getTime())) {
        d.setFullYear(d.getFullYear() + 2);
        const twoYears = d.toISOString().slice(0, 10);
        setEndContract(twoYears);
        setNextTicketDate(twoYears);
      }
    }
  };

  // Passport Expiry Countdown
  const handlePassportExpiryChange = (date: string) => {
    setPassportExpiry(date);
    if (date) {
      const days = calculateDaysRemaining(date);
      setPassportDays(`Day ${days}`);
    } else {
      setPassportDays('');
    }
  };

  // Residency Expiry Countdown
  const handleResidencyExpiryChange = (date: string) => {
    setResidencyExpiry(date);
    if (date) {
      const days = calculateDaysRemaining(date);
      setResidencyDays(`Day ${days}`);
    } else {
      setResidencyDays('');
    }
  };

  // Bank Selection
  const handleBankChange = (shortName: string) => {
    setPayerBankShort(shortName);
    if (shortName === 'OTHER') {
      setPayerBank(customBankName || 'Other');
    } else {
      const b = banks.find((item) => item.short === shortName);
      if (b) {
        setPayerBank(b.name);
      }
    }
  };

  // Total Salary
  const totalSalary =
    basicSalary +
    foodAllowance +
    transportAllowance +
    carOperationAllowance +
    otherAllowance +
    limitedTransport;

  // Add Future Deduction
  const handleAddFutureDeduction = () => {
    setFutureDeductions((prev) => [
      ...prev,
      {
        id: `fd-${Date.now()}`,
        date: new Date().toISOString().slice(0, 10),
        amount: 0,
        reason: '',
        status: 'Scheduled',
      },
    ]);
  };

  const handleRemoveFutureDeduction = (id: string) => {
    setFutureDeductions((prev) => prev.filter((d) => d.id !== id));
  };

  const handleUpdateFutureDeduction = (id: string, field: keyof FutureDeduction, value: string | number) => {
    setFutureDeductions((prev) =>
      prev.map((d) => (d.id === id ? { ...d, [field]: value } : d))
    );
  };

  // Form Submit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!employeeName.trim()) {
      alert('Please enter employee name.');
      return;
    }

    const bankName = payerBankShort === 'OTHER' ? customBankName || 'Other' : payerBank;
    const futureDeductionSum = futureDeductions.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);

    const newEmp: Employee = {
      no: nextNo,
      employerId,
      company,
      duty,
      accommodation,
      contractNo,
      employeeId,
      contractType,
      joiningDate,
      endContract,
      mph,
      expireMph,
      position,
      employeeName: employeeName.trim().toUpperCase(),
      nationality,
      mobile,
      whatsapp,
      email,
      passportNumber,
      passportExpiry,
      passportDays,
      residencyQid,
      residencyExpiry,
      residencyDays,
      payerBank: bankName,
      payerBankShort,
      iban,
      basicSalary,
      foodAllowance,
      transportAllowance,
      carOperationAllowance,
      otherAllowance,
      limitedTransport,
      totalSalary,
      saleCommissionRate,
      saleTargetRate,
      totalSalesRate,
      targetSales,
      prodSaleCommission,
      prodSaleTarget,
      prodTotalSales,
      businessTargetRate,
      businessGross,
      businessBonus,
      deductionCurrent,
      deductionFuture: futureDeductionSum,
      futureDeductions,
      tips,
      outstanding,
      leaveEntitlement,
      annualLeavePaid: 'QAR 0',
      salariesWages: totalSalary,
      totalCreditLeave,
      lastLeaveDate,
      annualLeaveDays,
      annualLeaveStatus,
      annualLeavePaidAmt,
      annualLeaveRemaining,
      annualLeaveFees,
      ticketCycle,
      nextTicketDate,
      ticketStatus,
      ticketDestination,
      confirm: confirmText,
      signature,
      date: formDate,
      status: 'Active',
      weeklyOffDay,
    };

    await db.saveEmployee(newEmp);
    alert(`✅ Employee "${newEmp.employeeName}" (${newEmp.employeeId}) registered successfully!`);
    onSaved();
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center justify-between">
        <div>
          <button
            onClick={onBack}
            className="text-xs font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1.5 transition-colors mb-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Dashboard</span>
          </button>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight">
            Register New Salon Staff Member
          </h2>
          <p className="text-xs text-slate-500">
            Fill in official Qatar employment contract details, bank information, allowances, and documents.
          </p>
        </div>

        <button
          onClick={handleSubmit}
          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
        >
          <Save className="w-4 h-4" />
          <span>Save Employee</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Section 1: Employment Details */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Building2 className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">1. Employment &amp; Contract Information</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Record No (Auto)
              </label>
              <input
                type="text"
                value={nextNo}
                readOnly
                className="w-full text-xs p-2.5 bg-slate-100 border border-slate-200 rounded-lg text-slate-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Employee ID (Auto)
              </label>
              <input
                type="text"
                value={employeeId}
                readOnly
                className="w-full text-xs p-2.5 bg-blue-50 border border-blue-200 text-blue-800 font-bold font-mono rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Employer ID *
              </label>
              <input
                type="text"
                value={employerId}
                onChange={(e) => setEmployerId(e.target.value)}
                required
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Contract No. (Auto)
              </label>
              <input
                type="text"
                value={contractNo}
                readOnly
                className="w-full text-xs p-2.5 bg-slate-100 border border-slate-200 rounded-lg text-slate-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Company *</label>
              <select
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              >
                <option value="COSMOS">COSMOS</option>
                <option value="F&G">F&amp;G</option>
                <option value="Ali Bin Ali">Ali Bin Ali</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Duty *</label>
              <select
                value={duty}
                onChange={(e) => setDuty(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              >
                <option value="Duty">Duty</option>
                <option value="Vacation">Vacation</option>
                <option value="Sick Leave">Sick Leave</option>
                <option value="Day Off">Day Off</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-purple-900 mb-1">
                Assigned Weekly Day Off *
              </label>
              <select
                value={weeklyOffDay}
                onChange={(e) => setWeeklyOffDay(e.target.value)}
                className="w-full text-xs p-2.5 bg-purple-50 border border-purple-200 text-purple-900 font-bold rounded-lg focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500"
              >
                <option value="Monday">Monday</option>
                <option value="Tuesday">Tuesday</option>
                <option value="Wednesday">Wednesday</option>
                <option value="Thursday">Thursday</option>
                <option value="Friday">Friday</option>
                <option value="Saturday">Saturday</option>
                <option value="Sunday">Sunday</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Accommodation *
              </label>
              <select
                value={accommodation}
                onChange={(e) => setAccommodation(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              >
                <option value="Live In">Live In (Provided)</option>
                <option value="Live Out">Live Out</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Contract Type *
              </label>
              <select
                value={contractType}
                onChange={(e) => setContractType(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              >
                <option value="Contract">Contract</option>
                <option value="Permit">Permit</option>
                <option value="Nll">Nll</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Joining Date *
              </label>
              <input
                type="date"
                value={joiningDate}
                onChange={(e) => handleJoiningDateChange(e.target.value)}
                required
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                End Contract (Auto +2 Years)
              </label>
              <input
                type="date"
                value={endContract}
                onChange={(e) => setEndContract(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-50 border border-slate-200 rounded-lg font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                MPH Certificate *
              </label>
              <select
                value={mph}
                onChange={(e) => setMph(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              >
                <option value="YES">YES</option>
                <option value="APPLY">APPLY</option>
                <option value="NO">NO</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Expire MPH</label>
              <input
                type="date"
                value={expireMph}
                onChange={(e) => setExpireMph(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Salon Position / Job Title *
              </label>
              <input
                type="text"
                placeholder="e.g. Eyelash Technician, Hair Stylist, Salon Manager"
                value={position}
                onChange={(e) => setPosition(e.target.value)}
                required
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Personal Information */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <User className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-900">2. Personal &amp; Identity Documentation</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Employee's Full Name (as per Passport) *
              </label>
              <input
                type="text"
                placeholder="e.g. ATYRGUL AIAZOVA"
                value={employeeName}
                onChange={(e) => setEmployeeName(e.target.value)}
                required
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 uppercase font-semibold text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Nationality *</label>
              <input
                type="text"
                placeholder="e.g. KYRGYZSTAN, PHILIPPINES, TUNISIA"
                value={nationality}
                onChange={(e) => setNationality(e.target.value)}
                required
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 uppercase"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Mobile Phone</label>
              <input
                type="text"
                placeholder="+974 XXXX XXXX"
                value={mobile}
                onChange={(e) => setMobile(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">WhatsApp</label>
              <input
                type="text"
                placeholder="+974 XXXX XXXX"
                value={whatsapp}
                onChange={(e) => setWhatsapp(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">E-mail Address</label>
              <input
                type="email"
                placeholder="employee@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Passport Number</label>
              <input
                type="text"
                placeholder="e.g. AC3002861"
                value={passportNumber}
                onChange={(e) => setPassportNumber(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 uppercase font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Passport Expiry Date</label>
              <input
                type="date"
                value={passportExpiry}
                onChange={(e) => handlePassportExpiryChange(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Passport Days Remaining
              </label>
              <input
                type="text"
                value={passportDays}
                readOnly
                placeholder="Calculated automatically"
                className="w-full text-xs p-2.5 bg-slate-100 border border-slate-200 text-slate-700 font-mono font-semibold rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Residency QID (11 Digits)
              </label>
              <input
                type="text"
                placeholder="e.g. 29741700048"
                value={residencyQid}
                onChange={(e) => setResidencyQid(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono tracking-wider font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Residency QID Expiry</label>
              <input
                type="date"
                value={residencyExpiry}
                onChange={(e) => handleResidencyExpiryChange(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Residency Days Remaining
              </label>
              <input
                type="text"
                value={residencyDays}
                readOnly
                placeholder="Calculated automatically"
                className="w-full text-xs p-2.5 bg-slate-100 border border-slate-200 text-slate-700 font-mono font-semibold rounded-lg"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Banking Information */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Building2 className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900">3. Qatar Banking &amp; IBAN Details</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Payer Bank *</label>
              <select
                value={payerBankShort}
                onChange={(e) => handleBankChange(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              >
                {banks.map((b) => (
                  <option key={b.short} value={b.short}>
                    {b.name} ({b.short})
                  </option>
                ))}
              </select>
            </div>

            {payerBankShort === 'OTHER' && (
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Custom Bank Name
                </label>
                <input
                  type="text"
                  placeholder="Enter full bank name"
                  value={customBankName}
                  onChange={(e) => setCustomBankName(e.target.value)}
                  className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
                />
              </div>
            )}

            <div className={payerBankShort === 'OTHER' ? 'sm:col-span-1' : 'sm:col-span-2'}>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Payee Bank IBAN (QA...)
              </label>
              <input
                type="text"
                placeholder="QA60BRWA00000000020000129"
                value={iban}
                onChange={(e) => setIban(e.target.value.toUpperCase())}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-mono tracking-wider font-semibold"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Salary & Allowances */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-bold text-slate-900">4. Monthly Salary &amp; Allowances (QAR)</h3>
            </div>
            <div className="text-xs font-semibold text-slate-500">
              Total Package: <span className="text-emerald-600 font-bold font-mono">QAR {totalSalary.toLocaleString()}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Basic Salary</label>
              <input
                type="number"
                step="0.01"
                value={basicSalary}
                onChange={(e) => setBasicSalary(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums font-semibold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Food Allowance</label>
              <input
                type="number"
                step="0.01"
                value={foodAllowance}
                onChange={(e) => setFoodAllowance(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Transportation Allowance
              </label>
              <input
                type="number"
                step="0.01"
                value={transportAllowance}
                onChange={(e) => setTransportAllowance(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Car Operation Allowance
              </label>
              <input
                type="number"
                step="0.01"
                value={carOperationAllowance}
                onChange={(e) => setCarOperationAllowance(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Other Allowance</label>
              <input
                type="number"
                step="0.01"
                value={otherAllowance}
                onChange={(e) => setOtherAllowance(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Limited Transportation
              </label>
              <input
                type="number"
                step="0.01"
                value={limitedTransport}
                onChange={(e) => setLimitedTransport(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Total Monthly Package (Auto Calculated)
              </label>
              <input
                type="text"
                value={`QAR ${totalSalary.toLocaleString()}`}
                readOnly
                className="w-full text-xs p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 font-bold font-mono rounded-lg tabular-nums"
              />
            </div>
          </div>
        </div>

        {/* Section 5: Sales Commission & Targets */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <DollarSign className="w-4 h-4 text-amber-600" />
            <h3 className="text-sm font-bold text-slate-900">
              5. Salon Service, Retail &amp; Business Target Commissions
            </h3>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Service Comm. Rate (%)
              </label>
              <input
                type="number"
                step="0.1"
                value={saleCommissionRate}
                onChange={(e) => setSaleCommissionRate(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Service Sales Target (QAR)
              </label>
              <input
                type="number"
                step="0.01"
                value={saleTargetRate}
                onChange={(e) => setSaleTargetRate(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Products Comm. Rate (%)
              </label>
              <input
                type="number"
                step="0.1"
                value={prodSaleCommission}
                onChange={(e) => setProdSaleCommission(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Products Target (QAR)
              </label>
              <input
                type="number"
                step="0.01"
                value={prodSaleTarget}
                onChange={(e) => setProdSaleTarget(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Business Target Rate (%)
              </label>
              <input
                type="number"
                step="0.1"
                value={businessTargetRate}
                onChange={(e) => setBusinessTargetRate(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Business Gross Target
              </label>
              <input
                type="number"
                step="0.01"
                value={businessGross}
                onChange={(e) => setBusinessGross(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Business Bonus</label>
              <input
                type="number"
                step="0.01"
                value={businessBonus}
                onChange={(e) => setBusinessBonus(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>
          </div>
        </div>

        {/* Section 6: Deductions & Scheduled Payments */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <DollarSign className="w-4 h-4 text-rose-600" />
            <h3 className="text-sm font-bold text-slate-900">6. Deductions, Tips &amp; Scheduled Debt</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Current Month Deduction (QAR)
              </label>
              <input
                type="number"
                step="0.01"
                value={deductionCurrent}
                onChange={(e) => setDeductionCurrent(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums text-rose-600 font-semibold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Staff Tips (QAR)</label>
              <input
                type="number"
                step="0.01"
                value={tips}
                onChange={(e) => setTips(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums text-emerald-600 font-semibold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Outstanding Balance (QAR)
              </label>
              <input
                type="number"
                step="0.01"
                value={outstanding}
                onChange={(e) => setOutstanding(parseFloat(e.target.value) || 0)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums text-rose-600 font-semibold"
              />
            </div>
          </div>

          {/* Future deductions list */}
          <div className="pt-2">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-700">
                Scheduled Future Month Deductions
              </label>
              <button
                type="button"
                onClick={handleAddFutureDeduction}
                className="px-2.5 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors flex items-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>Add Scheduled Deduction</span>
              </button>
            </div>

            {futureDeductions.length === 0 ? (
              <p className="text-xs text-slate-400 italic bg-slate-50 p-3 rounded-lg border border-slate-100">
                No future scheduled deductions. Future deductions will only apply in their designated payroll month.
              </p>
            ) : (
              <div className="space-y-2">
                {futureDeductions.map((d) => (
                  <div
                    key={d.id}
                    className="flex items-center gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200"
                  >
                    <input
                      type="date"
                      value={d.date}
                      onChange={(e) => handleUpdateFutureDeduction(d.id, 'date', e.target.value)}
                      className="text-xs p-1.5 bg-white border border-slate-200 rounded font-mono"
                    />
                    <input
                      type="text"
                      placeholder="Reason for deduction (e.g. advance, visa fee)"
                      value={d.reason}
                      onChange={(e) => handleUpdateFutureDeduction(d.id, 'reason', e.target.value)}
                      className="text-xs p-1.5 bg-white border border-slate-200 rounded flex-1"
                    />
                    <input
                      type="number"
                      step="0.01"
                      placeholder="Amount (QAR)"
                      value={d.amount}
                      onChange={(e) =>
                        handleUpdateFutureDeduction(d.id, 'amount', parseFloat(e.target.value) || 0)
                      }
                      className="text-xs p-1.5 bg-white border border-slate-200 rounded w-28 font-mono tabular-nums text-rose-600 font-semibold"
                    />
                    <button
                      type="button"
                      onClick={() => handleRemoveFutureDeduction(d.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Section 7: Annual Leave & Flight Tickets */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Plane className="w-4 h-4 text-cyan-600" />
            <h3 className="text-sm font-bold text-slate-900">
              7. Annual Leave &amp; Flight Ticket Entitlement
            </h3>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Annual Entitlement (Days)
              </label>
              <input
                type="number"
                value={leaveEntitlement}
                onChange={(e) => setLeaveEntitlement(parseInt(e.target.value) || 21)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Credit Leave Days
              </label>
              <input
                type="number"
                value={totalCreditLeave}
                onChange={(e) => setTotalCreditLeave(parseInt(e.target.value) || 21)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Flight Ticket Cycle (Years)
              </label>
              <input
                type="number"
                value={ticketCycle}
                onChange={(e) => setTicketCycle(parseInt(e.target.value) || 2)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono tabular-nums"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Next Flight Ticket Date
              </label>
              <input
                type="date"
                value={nextTicketDate}
                onChange={(e) => setNextTicketDate(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Ticket Status</label>
              <select
                value={ticketStatus}
                onChange={(e) => setTicketStatus(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg"
              >
                <option value="Not Eligible">Not Eligible</option>
                <option value="Eligible">Eligible</option>
                <option value="Pending">Pending</option>
                <option value="Approved">Approved</option>
                <option value="Booked">Booked</option>
                <option value="Used">Used</option>
              </select>
            </div>

            <div className="sm:col-span-3">
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Home Airport / Destination
              </label>
              <input
                type="text"
                placeholder="e.g. Manas International Airport (Bishkek, Kyrgyzstan)"
                value={ticketDestination}
                onChange={(e) => setTicketDestination(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg"
              />
            </div>
          </div>
        </div>

        {/* Section 8: Confirmation & Signatures */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-900">8. Contract Confirmation &amp; Signature</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-3">
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Acknowledgment Text
              </label>
              <textarea
                rows={2}
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Signature / Digital Sign-off
              </label>
              <input
                type="text"
                placeholder="Employee signature name"
                value={signature}
                onChange={(e) => setSignature(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-serif italic"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Sign Date</label>
              <input
                type="date"
                value={formDate}
                onChange={(e) => setFormDate(e.target.value)}
                className="w-full text-xs p-2.5 bg-white border border-slate-200 rounded-lg font-mono"
              />
            </div>
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onBack}
            className="px-4 py-2.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="px-5 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-2 shadow-sm"
          >
            <Save className="w-4 h-4" />
            <span>Complete &amp; Register Employee</span>
          </button>
        </div>
      </form>
    </div>
  );
};
