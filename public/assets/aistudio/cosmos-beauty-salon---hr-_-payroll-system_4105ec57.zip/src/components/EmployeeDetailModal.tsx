import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  DollarSign,
  AlertTriangle,
  Calendar,
  Clock,
  History,
  Paperclip,
  Save,
  Trash2,
  Upload,
  Eye,
  Plus,
  UserCheck,
  UserX,
  Plane,
} from 'lucide-react';
import { Employee, PayrollRecord, AttendanceRecord, LeaveRecord, FlightTicketRecord, ExtraTimeTransaction, FutureDeduction, BankInfo, SystemSettings } from '../types';
import {
  db,
  formatCurrency,
  formatDate,
  formatTime12,
  minutesToTimeStr,
  calculateDaysRemaining,
  calculateEmployeeCommissions,
  getDayOfWeek,
} from '../services/db';

interface EmployeeDetailModalProps {
  employeeId: string | null;
  banks: BankInfo[];
  settings: SystemSettings;
  payrolls: PayrollRecord[];
  attendance: AttendanceRecord[];
  leaves: LeaveRecord[];
  tickets: FlightTicketRecord[];
  extraTime: ExtraTimeTransaction[];
  onClose: () => void;
  onRefresh: () => void;
}

type TabType =
  | 'profile'
  | 'commissions'
  | 'deductions'
  | 'leave'
  | 'attendance'
  | 'payroll'
  | 'documents';

export const EmployeeDetailModal: React.FC<EmployeeDetailModalProps> = ({
  employeeId,
  banks,
  settings,
  payrolls,
  attendance,
  leaves,
  tickets,
  extraTime,
  onClose,
  onRefresh,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('profile');
  const [emp, setEmp] = useState<Employee | null>(null);

  // Status toggle modal states
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [lastWorkingDate, setLastWorkingDate] = useState(new Date().toISOString().slice(0, 10));
  const [reasonForLeaving, setReasonForLeaving] = useState('Resigned');
  const [rejoiningDate, setRejoiningDate] = useState(new Date().toISOString().slice(0, 10));
  const [rejoiningPosition, setRejoiningPosition] = useState('');

  // Add custom payroll modal
  const [showAddPayrollModal, setShowAddPayrollModal] = useState(false);
  const [newPayMonth, setNewPayMonth] = useState('October');
  const [newPayYear, setNewPayYear] = useState('2026');

  // Load employee data
  useEffect(() => {
    if (employeeId) {
      const found = db.getEmployee(employeeId);
      if (found) {
        setEmp({ ...found });
      }
    }
  }, [employeeId]);

  if (!employeeId || !emp) return null;

  // Derived calculations
  const pDays = calculateDaysRemaining(emp.passportExpiry);
  const qDays = calculateDaysRemaining(emp.residencyExpiry);
  const commissions = calculateEmployeeCommissions(emp, settings);

  const empPayrolls = payrolls
    .filter((p) => p.employeeId === emp.employeeId)
    .sort((a, b) => b.year.localeCompare(a.year) || b.month.localeCompare(a.month));

  const empAttendance = attendance
    .filter((a) => a.employeeId === emp.employeeId)
    .sort((a, b) => b.date.localeCompare(a.date));

  const empLeaves = leaves
    .filter((l) => l.employeeId === emp.employeeId)
    .sort((a, b) => b.startDate.localeCompare(a.startDate));

  const empTickets = tickets
    .filter((t) => t.employeeId === emp.employeeId)
    .sort((a, b) => (b.eligibleDate || '').localeCompare(a.eligibleDate || ''));

  const empExtra = extraTime
    .filter((et) => et.employeeId === emp.employeeId)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  // Extra time metrics
  let extraBalance = 0;
  let grossExtra = 0;
  let usedExtra = 0;
  empExtra.forEach((et) => {
    if (et.type === 'Earned') {
      grossExtra += et.minutes;
      extraBalance += et.minutes;
    } else if (et.type === 'Used') {
      usedExtra += et.minutes;
      extraBalance -= et.minutes;
    }
  });

  // Leave metrics
  const entitlement = Number(emp.leaveEntitlement) || 21;
  const takenLeaves = empLeaves
    .filter((l) => l.status === 'Approved')
    .reduce((sum, l) => sum + (Number(l.days) || 0), 0);
  const pendingLeaves = empLeaves
    .filter((l) => l.status === 'Pending')
    .reduce((sum, l) => sum + (Number(l.days) || 0), 0);
  const remainingLeaves = entitlement - takenLeaves - pendingLeaves;
  const dailyRate = (Number(emp.basicSalary) || 0) / (settings.leaveDivisor || 30);

  // Field change handler
  const handleFieldChange = (field: keyof Employee, value: unknown) => {
    setEmp((prev) => {
      if (!prev) return prev;
      const updated = { ...prev, [field]: value };
      if (
        [
          'basicSalary',
          'foodAllowance',
          'transportAllowance',
          'carOperationAllowance',
          'otherAllowance',
          'limitedTransport',
        ].includes(field)
      ) {
        updated.totalSalary =
          (Number(updated.basicSalary) || 0) +
          (Number(updated.foodAllowance) || 0) +
          (Number(updated.transportAllowance) || 0) +
          (Number(updated.carOperationAllowance) || 0) +
          (Number(updated.otherAllowance) || 0) +
          (Number(updated.limitedTransport) || 0);
      }
      return updated;
    });
  };

  // Save profile changes
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emp) return;
    await db.saveEmployee(emp);
    alert('✅ Employee profile changes saved successfully!');
    onRefresh();
  };

  // Toggle employment status (Active <-> Former)
  const handleConfirmStatusToggle = async () => {
    if (!emp) return;

    if (emp.status === 'Unemployed') {
      // Reactivate
      const updated: Employee = {
        ...emp,
        status: 'Active',
        rejoiningDate,
        position: rejoiningPosition.trim() ? rejoiningPosition.trim() : emp.position,
        lastWorkingDate: undefined,
        reasonForLeaving: undefined,
      };
      await db.saveEmployee(updated);
      setEmp(updated);
      alert(`✅ ${emp.employeeName} has been reactivated to Active Employees!`);
    } else {
      // Move to Unemployed
      const updated: Employee = {
        ...emp,
        status: 'Unemployed',
        lastWorkingDate,
        reasonForLeaving,
      };
      await db.saveEmployee(updated);
      setEmp(updated);
      alert(`✅ ${emp.employeeName} moved to Unemployed / Former archive.`);
    }

    setShowStatusModal(false);
    onRefresh();
  };

  // Delete employee permanently
  const handleDeleteEmployee = async () => {
    if (
      confirm(
        `⚠️ PERMANENT DELETE WARNING: Are you sure you want to delete ${emp.employeeName} (${emp.employeeId})?\n\nThis will remove their master record, document scans, and all payroll history. This action cannot be reversed.`
      )
    ) {
      if (confirm(`Final confirmation: Delete employee ${emp.employeeName}?`)) {
        await db.deleteEmployee(emp.employeeId);
        alert('Employee record removed.');
        onClose();
        onRefresh();
      }
    }
  };

  // Photo & Document Uploads
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (evt) => {
      const data = evt.target?.result as string;
      const updated: Employee = { ...emp, photoData: data, imageData: data };
      setEmp(updated);
      await db.saveEmployee(updated);
      onRefresh();
    };
    reader.readAsDataURL(file);
  };

  const handleDocumentUpload = (
    docType: 'passportData' | 'qidData' | 'employerDocData',
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 12 * 1024 * 1024) {
      alert('File is too large. Please select a file smaller than 12MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = async (evt) => {
      const data = evt.target?.result as string;
      const attachment = {
        name: file.name,
        data,
        date: new Date().toISOString(),
      };
      const updated: Employee = { ...emp, [docType]: attachment };
      setEmp(updated);
      await db.saveEmployee(updated);
      onRefresh();
      alert(`✅ Uploaded ${file.name}`);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleDeleteDocument = async (docType: 'passportData' | 'qidData' | 'employerDocData') => {
    if (!confirm('Are you sure you want to delete this document attachment?')) return;
    const updated: Employee = { ...emp, [docType]: null };
    setEmp(updated);
    await db.saveEmployee(updated);
    onRefresh();
  };

  // Add Monthly Payroll Record
  const handleAddMonthlyPayroll = async () => {
    const payrollId = `PAY-${emp.employeeId}-${newPayYear}-${newPayMonth}`;
    const basic = Number(emp.basicSalary) || 0;
    const allowances =
      (Number(emp.foodAllowance) || 0) +
      (Number(emp.transportAllowance) || 0) +
      (Number(emp.carOperationAllowance) || 0) +
      (Number(emp.otherAllowance) || 0) +
      (Number(emp.limitedTransport) || 0);

    const comms = calculateEmployeeCommissions(emp, settings);
    const deductions = Number(emp.deductionCurrent) || 0;
    const netSalary = basic + allowances + comms.total - deductions;

    const record: PayrollRecord = {
      id: payrollId,
      employeeId: emp.employeeId,
      month: newPayMonth,
      year: newPayYear,
      basicSalary: basic,
      allowances,
      commissions: comms.total,
      deductions,
      netSalary,
      paidAmount: 0,
      status: 'Draft',
      paymentDate: '',
      notes: `Custom payroll sheet for ${newPayMonth} ${newPayYear}`,
      commissionBreakdown: {
        service: comms.service,
        product: comms.product,
        business: comms.business,
      },
    };

    await db.savePayrollRecord(record);
    setShowAddPayrollModal(false);
    onRefresh();
    alert(`Draft payroll record created for ${newPayMonth} ${newPayYear}!`);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 z-50 flex items-center justify-center p-3 sm:p-5 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-5xl my-auto max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="relative">
              {emp.photoData ? (
                <img
                  src={emp.photoData}
                  alt={emp.employeeName}
                  className="w-12 h-12 rounded-full object-cover border-2 border-white/30"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-slate-800 border-2 border-white/20 flex items-center justify-center text-slate-300">
                  <User className="w-6 h-6" />
                </div>
              )}
              <span
                className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-slate-900 ${
                  emp.status === 'Active' ? 'bg-emerald-500' : 'bg-amber-500'
                }`}
              />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  {emp.employeeName}
                </h2>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-white/10 text-slate-300 font-bold">
                  {emp.employeeId}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {emp.position} · {emp.company} · QID: <span className="font-mono text-slate-300 font-semibold">{emp.residencyQid || 'N/A'}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowStatusModal(true)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors ${
                emp.status === 'Unemployed'
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  : 'bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold'
              }`}
            >
              {emp.status === 'Unemployed' ? (
                <>
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>Reactivate</span>
                </>
              ) : (
                <>
                  <UserX className="w-3.5 h-3.5" />
                  <span>Move to Former</span>
                </>
              )}
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Strip */}
        <div className="bg-slate-50 border-b border-slate-200 px-4 sm:px-6 flex items-center gap-1 overflow-x-auto shrink-0 custom-scrollbar">
          <button
            onClick={() => setActiveTab('profile')}
            className={`py-3 px-3.5 text-xs font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'profile'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Profile &amp; Salary</span>
          </button>

          <button
            onClick={() => setActiveTab('commissions')}
            className={`py-3 px-3.5 text-xs font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'commissions'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>Commissions ({formatCurrency(commissions.total)} QAR)</span>
          </button>

          <button
            onClick={() => setActiveTab('deductions')}
            className={`py-3 px-3.5 text-xs font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'deductions'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Deductions ({formatCurrency(emp.deductionCurrent)} QAR)</span>
          </button>

          <button
            onClick={() => setActiveTab('leave')}
            className={`py-3 px-3.5 text-xs font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'leave'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Leave &amp; Tickets</span>
          </button>

          <button
            onClick={() => setActiveTab('attendance')}
            className={`py-3 px-3.5 text-xs font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'attendance'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Attendance &amp; Extra Time</span>
          </button>

          <button
            onClick={() => setActiveTab('payroll')}
            className={`py-3 px-3.5 text-xs font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'payroll'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>Payroll History ({empPayrolls.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('documents')}
            className={`py-3 px-3.5 text-xs font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'documents'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Paperclip className="w-3.5 h-3.5" />
            <span>Documents &amp; Scans</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 custom-scrollbar bg-slate-50/40">
          {/* TAB 1: PROFILE & SALARY */}
          {activeTab === 'profile' && (
            <form onSubmit={handleSaveProfile} className="space-y-6">
              {/* Profile Image & Summary */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center gap-4">
                <div className="relative group shrink-0">
                  {emp.photoData ? (
                    <img
                      src={emp.photoData}
                      alt={emp.employeeName}
                      className="w-20 h-24 rounded-lg object-cover border border-slate-200 bg-slate-100 shadow-xs"
                    />
                  ) : (
                    <div className="w-20 h-24 rounded-lg bg-slate-100 border border-slate-200 flex flex-col items-center justify-center text-slate-400">
                      <User className="w-8 h-8 text-slate-300 mb-1" />
                      <span className="text-[10px]">No Photo</span>
                    </div>
                  )}
                  <label className="absolute inset-0 bg-black/50 text-white rounded-lg opacity-0 group-hover:opacity-100 flex items-center justify-center text-[10px] font-semibold cursor-pointer transition-opacity">
                    Change
                    <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                  </label>
                </div>

                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      Employee File
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        emp.status === 'Active'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}
                    >
                      {emp.status}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900">{emp.employeeName}</h3>
                  <div className="text-xs text-slate-500 flex flex-wrap gap-x-3 gap-y-1">
                    <span>Position: <strong>{emp.position}</strong></span>
                    <span>·</span>
                    <span>Company: <strong>{emp.company}</strong></span>
                    <span>·</span>
                    <span>Duty: <strong>{emp.duty}</strong></span>
                    <span>·</span>
                    <span>Package: <strong className="text-emerald-700 font-mono">QAR {formatCurrency(emp.totalSalary)}</strong></span>
                  </div>
                </div>
              </div>

              {/* Employment Information */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Employment &amp; Contract Details
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Company</label>
                    <select
                      value={emp.company}
                      onChange={(e) => handleFieldChange('company', e.target.value)}
                      className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg"
                    >
                      <option value="COSMOS">COSMOS</option>
                      <option value="F&G">F&amp;G</option>
                      <option value="Ali Bin Ali">Ali Bin Ali</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Duty Status</label>
                    <select
                      value={emp.duty}
                      onChange={(e) => handleFieldChange('duty', e.target.value)}
                      className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg"
                    >
                      <option value="Duty">Duty</option>
                      <option value="Vacation">Vacation</option>
                      <option value="Sick Leave">Sick Leave</option>
                      <option value="Day Off">Day Off</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-purple-900 mb-1">Assigned Weekly Day Off</label>
                    <select
                      value={emp.weeklyOffDay || 'Friday'}
                      onChange={(e) => handleFieldChange('weeklyOffDay', e.target.value)}
                      className="w-full text-xs p-2 bg-purple-50 border border-purple-200 rounded-lg font-bold text-purple-900"
                    >
                      <option value="Monday">Monday</option>
                      <option value="Tuesday">Tuesday</option>
                      <option value="Wednesday">Wednesday</option>
                      <option value="Thursday">Thursday</option>
                      <option value="Friday">Friday</option>
                      <option value="Saturday">Saturday</option>
                      <option value="Sunday">Sunday</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Accommodation</label>
                    <select
                      value={emp.accommodation}
                      onChange={(e) => handleFieldChange('accommodation', e.target.value)}
                      className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg"
                    >
                      <option value="Live In">Live In</option>
                      <option value="Live Out">Live Out</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Position</label>
                    <input
                      type="text"
                      value={emp.position}
                      onChange={(e) => handleFieldChange('position', e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Contract No.</label>
                    <input
                      type="text"
                      value={emp.contractNo}
                      onChange={(e) => handleFieldChange('contractNo', e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Joining Date</label>
                    <input
                      type="date"
                      value={emp.joiningDate}
                      onChange={(e) => handleFieldChange('joiningDate', e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">End Contract Date</label>
                    <input
                      type="date"
                      value={emp.endContract}
                      onChange={(e) => handleFieldChange('endContract', e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">MPH Certificate</label>
                    <select
                      value={emp.mph}
                      onChange={(e) => handleFieldChange('mph', e.target.value)}
                      className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg font-bold"
                    >
                      <option value="YES">YES</option>
                      <option value="APPLY">APPLY</option>
                      <option value="NO">NO</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Personal & Residency */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Personal, Passport &amp; QID Documentation
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Nationality</label>
                    <input
                      type="text"
                      value={emp.nationality}
                      onChange={(e) => handleFieldChange('nationality', e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg uppercase"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Mobile</label>
                    <input
                      type="text"
                      value={emp.mobile}
                      onChange={(e) => handleFieldChange('mobile', e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Email</label>
                    <input
                      type="email"
                      value={emp.email}
                      onChange={(e) => handleFieldChange('email', e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Passport Number</label>
                    <input
                      type="text"
                      value={emp.passportNumber}
                      onChange={(e) => handleFieldChange('passportNumber', e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg uppercase font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Passport Expiry</label>
                    <input
                      type="date"
                      value={emp.passportExpiry}
                      onChange={(e) => handleFieldChange('passportExpiry', e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Passport Days Alert</label>
                    <div
                      className={`text-xs p-2 font-bold font-mono rounded-lg border ${
                        pDays < 90
                          ? 'bg-rose-50 border-rose-200 text-rose-700'
                          : 'bg-emerald-50 border-emerald-200 text-emerald-700'
                      }`}
                    >
                      Day {pDays} Remaining
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Residency QID</label>
                    <input
                      type="text"
                      value={emp.residencyQid}
                      onChange={(e) => handleFieldChange('residencyQid', e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">QID Expiry Date</label>
                    <input
                      type="date"
                      value={emp.residencyExpiry}
                      onChange={(e) => handleFieldChange('residencyExpiry', e.target.value)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">QID Days Alert</label>
                    <div
                      className={`text-xs p-2 font-bold font-mono rounded-lg border ${
                        qDays < 90
                          ? 'bg-rose-50 border-rose-200 text-rose-700'
                          : 'bg-emerald-50 border-emerald-200 text-emerald-700'
                      }`}
                    >
                      Day {qDays} Remaining
                    </div>
                  </div>
                </div>
              </div>

              {/* Qatar Banking */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Banking &amp; Remuneration IBAN
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Payer Bank</label>
                    <select
                      value={emp.payerBankShort}
                      onChange={(e) => {
                        const s = e.target.value;
                        const b = banks.find((item) => item.short === s);
                        handleFieldChange('payerBankShort', s);
                        if (b) handleFieldChange('payerBank', b.name);
                      }}
                      className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg"
                    >
                      {banks.map((b) => (
                        <option key={b.short} value={b.short}>
                          {b.name} ({b.short})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Payee IBAN</label>
                    <input
                      type="text"
                      value={emp.iban}
                      onChange={(e) => handleFieldChange('iban', e.target.value.toUpperCase())}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono font-semibold tracking-wider"
                    />
                  </div>
                </div>
              </div>

              {/* Monthly Salary Package */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Salary &amp; Monthly Allowances
                  </h4>
                  <div className="text-xs font-bold text-emerald-600 font-mono">
                    Total: QAR {formatCurrency(emp.totalSalary)}
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Basic Salary</label>
                    <input
                      type="number"
                      step="0.01"
                      value={emp.basicSalary}
                      onChange={(e) => handleFieldChange('basicSalary', parseFloat(e.target.value) || 0)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Food Allowance</label>
                    <input
                      type="number"
                      step="0.01"
                      value={emp.foodAllowance}
                      onChange={(e) => handleFieldChange('foodAllowance', parseFloat(e.target.value) || 0)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Transportation</label>
                    <input
                      type="number"
                      step="0.01"
                      value={emp.transportAllowance}
                      onChange={(e) => handleFieldChange('transportAllowance', parseFloat(e.target.value) || 0)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Car Operation</label>
                    <input
                      type="number"
                      step="0.01"
                      value={emp.carOperationAllowance}
                      onChange={(e) =>
                        handleFieldChange('carOperationAllowance', parseFloat(e.target.value) || 0)
                      }
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Other Allowance</label>
                    <input
                      type="number"
                      step="0.01"
                      value={emp.otherAllowance}
                      onChange={(e) => handleFieldChange('otherAllowance', parseFloat(e.target.value) || 0)}
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-500 mb-1">Limited Transport</label>
                    <input
                      type="number"
                      step="0.01"
                      value={emp.limitedTransport}
                      onChange={(e) =>
                        handleFieldChange('limitedTransport', parseFloat(e.target.value) || 0)
                      }
                      className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={handleDeleteEmployee}
                  className="px-3.5 py-2 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg border border-rose-200 transition-colors flex items-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Employee Record</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg"
                  >
                    Close
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save Profile Changes</span>
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* TAB 2: COMMISSIONS */}
          {activeTab === 'commissions' && (
            <div className="space-y-4">
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  1️⃣ Salon Service Sales Commission (Standard: {commissions.serviceRate}%)
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs mt-3">
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[11px]">Sales Target</span>
                    <strong className="text-slate-900 font-mono text-sm">
                      QAR {formatCurrency(commissions.serviceTarget)}
                    </strong>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[11px]">Actual Sales Achieved</span>
                    <strong className="text-slate-900 font-mono text-sm">
                      QAR {formatCurrency(commissions.serviceActual)}
                    </strong>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[11px]">Achievement Rate</span>
                    <strong className="text-slate-900 font-mono text-sm">
                      {commissions.serviceAchievement.toFixed(1)}%
                    </strong>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <span className="text-blue-600 block text-[11px] font-semibold">Commission Due</span>
                    <strong className="text-blue-700 font-mono text-base">
                      QAR {formatCurrency(commissions.service)}
                    </strong>
                  </div>
                </div>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  2️⃣ Retail Product Sales Commission (Standard: {commissions.productRate}%)
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs mt-3">
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[11px]">Retail Products Sold</span>
                    <strong className="text-slate-900 font-mono text-sm">
                      QAR {formatCurrency(commissions.productSales)}
                    </strong>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[11px]">Commission Rate</span>
                    <strong className="text-slate-900 font-mono text-sm">{commissions.productRate}%</strong>
                  </div>
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                    <span className="text-emerald-600 block text-[11px] font-semibold">
                      Product Commission
                    </span>
                    <strong className="text-emerald-700 font-mono text-base">
                      QAR {formatCurrency(commissions.product)}
                    </strong>
                  </div>
                </div>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  3️⃣ Business Target Bonus (Goal: QAR {formatCurrency(commissions.businessTarget)} @{' '}
                  {commissions.businessRate}%)
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs mt-3">
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[11px]">Business Target</span>
                    <strong className="text-slate-900 font-mono text-sm">
                      QAR {formatCurrency(commissions.businessTarget)}
                    </strong>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[11px]">Actual Business Gross</span>
                    <strong className="text-slate-900 font-mono text-sm">
                      QAR {formatCurrency(commissions.businessGross)}
                    </strong>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[11px]">Target Met?</span>
                    <strong
                      className={`text-sm ${
                        commissions.businessEligible ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {commissions.businessEligible ? '✅ Achieved' : '❌ Below Target'}
                    </strong>
                  </div>
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <span className="text-amber-700 block text-[11px] font-semibold">Business Bonus</span>
                    <strong className="text-amber-800 font-mono text-base">
                      QAR {formatCurrency(commissions.business)}
                    </strong>
                  </div>
                </div>
              </div>

              {/* Total Commission Banner */}
              <div className="bg-linear-to-r from-blue-600 to-indigo-700 p-6 rounded-xl text-white shadow-md flex items-center justify-between">
                <div>
                  <span className="text-xs uppercase tracking-wider text-blue-100 font-semibold">
                    Total Monthly Commission Payable
                  </span>
                  <div className="text-2xl font-bold font-mono tracking-tight mt-1">
                    QAR {formatCurrency(commissions.total)}
                  </div>
                </div>
                <div className="text-right text-xs text-blue-100">
                  <span>Service + Products + Business</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: DEDUCTIONS */}
          {activeTab === 'deductions' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="text-[11px] text-slate-400 font-semibold uppercase">
                    Current Deduction
                  </div>
                  <div className="text-lg font-bold text-rose-600 font-mono tabular-nums">
                    QAR {formatCurrency(emp.deductionCurrent)}
                  </div>
                </div>
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="text-[11px] text-slate-400 font-semibold uppercase">
                    Staff Tips
                  </div>
                  <div className="text-lg font-bold text-emerald-600 font-mono tabular-nums">
                    QAR {formatCurrency(emp.tips)}
                  </div>
                </div>
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="text-[11px] text-slate-400 font-semibold uppercase">
                    Outstanding Balance
                  </div>
                  <div className="text-lg font-bold text-rose-600 font-mono tabular-nums">
                    QAR {formatCurrency(emp.outstanding)}
                  </div>
                </div>
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="text-[11px] text-slate-400 font-semibold uppercase">
                    Future Deductions
                  </div>
                  <div className="text-lg font-bold text-slate-700 font-mono tabular-nums">
                    QAR {formatCurrency(emp.deductionFuture)}
                  </div>
                </div>
              </div>

              {/* Scheduled Future Deductions */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Future Month Scheduled Deductions
                </h4>
                {emp.futureDeductions && emp.futureDeductions.length > 0 ? (
                  <div className="space-y-2">
                    {emp.futureDeductions.map((d) => (
                      <div
                        key={d.id}
                        className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs"
                      >
                        <div>
                          <strong className="text-slate-900">{formatDate(d.date)}</strong>
                          <span className="text-slate-500 ml-2">{d.reason || 'No description'}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-rose-600">
                            QAR {formatCurrency(d.amount)}
                          </span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-50 text-amber-700 border border-amber-200">
                            {d.status}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">No future deductions scheduled.</p>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: LEAVE & TICKETS */}
          {activeTab === 'leave' && (
            <div className="space-y-5">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="text-[11px] text-slate-400 font-semibold uppercase">
                    Entitlement
                  </div>
                  <div className="text-lg font-bold text-slate-900">{entitlement} Days</div>
                </div>
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="text-[11px] text-slate-400 font-semibold uppercase">
                    Taken Days
                  </div>
                  <div className="text-lg font-bold text-rose-600">{takenLeaves} Days</div>
                </div>
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="text-[11px] text-slate-400 font-semibold uppercase">
                    Remaining Balance
                  </div>
                  <div className="text-lg font-bold text-emerald-600">{remainingLeaves} Days</div>
                </div>
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="text-[11px] text-slate-400 font-semibold uppercase">
                    Daily Wage Rate (÷30)
                  </div>
                  <div className="text-lg font-bold text-blue-600 font-mono">
                    QAR {formatCurrency(dailyRate)}
                  </div>
                </div>
              </div>

              {/* Leave History Table */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Leave Request Records
                </h4>
                <div className="overflow-x-auto custom-scrollbar">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                      <tr>
                        <th className="p-2">Period</th>
                        <th className="p-2">Start</th>
                        <th className="p-2">End</th>
                        <th className="p-2 text-right">Days</th>
                        <th className="p-2">Type</th>
                        <th className="p-2">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {empLeaves.map((l) => (
                        <tr key={l.leaveId}>
                          <td className="p-2 font-mono text-slate-600">{l.period}</td>
                          <td className="p-2 font-mono text-slate-600">{formatDate(l.startDate)}</td>
                          <td className="p-2 font-mono text-slate-600">{formatDate(l.endDate)}</td>
                          <td className="p-2 text-right font-bold text-slate-800">{l.days} d</td>
                          <td className="p-2 text-slate-700">{l.leaveType}</td>
                          <td className="p-2">
                            <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700">
                              {l.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {empLeaves.length === 0 && (
                    <p className="text-xs text-slate-400 text-center py-6">No leaves recorded yet.</p>
                  )}
                </div>
              </div>

              {/* Flight Ticket Summary */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Plane className="w-3.5 h-3.5 text-blue-600" />
                  <span>Home Flight Ticket Entitlement</span>
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[11px]">Cycle</span>
                    <strong>{emp.ticketCycle || 2} Years</strong>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[11px]">Next Eligible</span>
                    <strong className="font-mono">
                      {emp.nextTicketDate ? formatDate(emp.nextTicketDate) : '-'}
                    </strong>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[11px]">Status</span>
                    <span className="font-bold text-emerald-700">{emp.ticketStatus}</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <span className="text-slate-400 block text-[11px]">Destination</span>
                    <strong className="truncate block">{emp.ticketDestination || '-'}</strong>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: ATTENDANCE */}
          {activeTab === 'attendance' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="text-[11px] text-slate-400 font-semibold uppercase">
                    Net Extra-Time Balance
                  </div>
                  <div
                    className={`text-xl font-bold font-mono ${
                      extraBalance >= 0 ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    {minutesToTimeStr(extraBalance)}
                  </div>
                </div>
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="text-[11px] text-slate-400 font-semibold uppercase">
                    Gross Extra Hours Earned
                  </div>
                  <div className="text-xl font-bold text-blue-600 font-mono">
                    {minutesToTimeStr(grossExtra)}
                  </div>
                </div>
                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  <div className="text-[11px] text-slate-400 font-semibold uppercase">
                    Hours Used for Offsets
                  </div>
                  <div className="text-xl font-bold text-slate-700 font-mono">
                    {minutesToTimeStr(usedExtra)}
                  </div>
                </div>
              </div>

              {/* Recent Shifts Table */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Recent Attendance Records
                </h4>
                <div className="overflow-x-auto custom-scrollbar">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                      <tr>
                        <th className="p-2">Date</th>
                        <th className="p-2">Day</th>
                        <th className="p-2 text-amber-800 bg-amber-50/50">Time In (Morning)</th>
                        <th className="p-2 text-indigo-800 bg-indigo-50/50">Time Out (Night)</th>
                        <th className="p-2 text-right">Work</th>
                        <th className="p-2 text-right text-slate-500">Scheduled</th>
                        <th className="p-2 text-right text-emerald-600">Extra</th>
                        <th className="p-2 text-right text-rose-600">Short</th>
                        <th className="p-2">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {empAttendance.slice(0, 20).map((a) => {
                        const extraMin = a.extraMinutes || 0;
                        const shortMin = a.shortMinutes !== undefined ? a.shortMinutes : (a.totalWorkMinutes < a.scheduledWorkMinutes ? a.scheduledWorkMinutes - a.totalWorkMinutes : 0);

                        return (
                          <tr key={a.attId}>
                            <td className="p-2 font-mono text-slate-600 font-medium">{formatDate(a.date)}</td>
                            <td className="p-2 text-slate-500">{getDayOfWeek(a.date)}</td>
                            <td className="p-2 font-mono text-slate-800 font-semibold bg-amber-50/20">
                              {a.timeIn || a.morningTimeIn ? formatTime12(a.timeIn || a.morningTimeIn) : '—'}
                            </td>
                            <td className="p-2 font-mono text-slate-800 font-semibold bg-indigo-50/20">
                              {a.timeOut || a.nightTimeOut ? formatTime12(a.timeOut || a.nightTimeOut) : '—'}
                            </td>
                            <td className="p-2 text-right font-mono tabular-nums font-semibold text-slate-800">
                              {minutesToTimeStr(a.totalWorkMinutes)}
                            </td>
                            <td className="p-2 text-right font-mono tabular-nums text-slate-500">
                              {minutesToTimeStr(a.scheduledWorkMinutes)}
                            </td>
                            <td
                              className={`p-2 text-right font-mono font-bold tabular-nums ${
                                extraMin > 0 ? 'text-emerald-600' : 'text-slate-400'
                              }`}
                            >
                              {extraMin > 0 ? `+${minutesToTimeStr(extraMin)}` : '0m'}
                            </td>
                            <td
                              className={`p-2 text-right font-mono font-bold tabular-nums ${
                                shortMin > 0 ? 'text-rose-600' : 'text-slate-400'
                              }`}
                            >
                              {shortMin > 0 ? `-${minutesToTimeStr(shortMin)}` : '0m'}
                            </td>
                            <td className="p-2">
                              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                {a.status}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  {empAttendance.length === 0 && (
                    <p className="text-xs text-slate-400 text-center py-6">
                      No shift records logged yet.
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: PAYROLL HISTORY */}
          {activeTab === 'payroll' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Monthly Wage Disbursements
                </h4>
                <button
                  onClick={() => setShowAddPayrollModal(true)}
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1 shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Generate Monthly Record</span>
                </button>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="overflow-x-auto custom-scrollbar">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                      <tr>
                        <th className="p-2.5">Period</th>
                        <th className="p-2.5 text-right">Basic</th>
                        <th className="p-2.5 text-right">Allowances</th>
                        <th className="p-2.5 text-right">Commissions</th>
                        <th className="p-2.5 text-right text-rose-600">Deductions</th>
                        <th className="p-2.5 text-right font-bold text-slate-900 bg-slate-100/60">
                          Net Salary
                        </th>
                        <th className="p-2.5 text-right text-emerald-600">Paid</th>
                        <th className="p-2.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {empPayrolls.map((p) => (
                        <tr key={p.id}>
                          <td className="p-2.5 font-bold text-slate-900 font-mono">
                            {p.month} {p.year}
                          </td>
                          <td className="p-2.5 text-right font-mono tabular-nums">
                            QAR {formatCurrency(p.basicSalary)}
                          </td>
                          <td className="p-2.5 text-right font-mono tabular-nums">
                            QAR {formatCurrency(p.allowances)}
                          </td>
                          <td className="p-2.5 text-right font-mono tabular-nums text-amber-700 font-medium">
                            QAR {formatCurrency(p.commissions)}
                          </td>
                          <td className="p-2.5 text-right font-mono tabular-nums text-rose-600 font-medium">
                            QAR {formatCurrency(p.deductions)}
                          </td>
                          <td className="p-2.5 text-right font-mono tabular-nums font-bold text-slate-900 bg-slate-50">
                            QAR {formatCurrency(p.netSalary)}
                          </td>
                          <td className="p-2.5 text-right font-mono tabular-nums text-emerald-600 font-semibold">
                            QAR {formatCurrency(p.paidAmount)}
                          </td>
                          <td className="p-2.5">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                                p.status === 'Paid'
                                  ? 'bg-emerald-50 text-emerald-700'
                                  : 'bg-amber-50 text-amber-700'
                              }`}
                            >
                              {p.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {empPayrolls.length === 0 && (
                    <p className="text-xs text-slate-400 text-center py-8">
                      No payroll records generated for this employee yet.
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: DOCUMENTS */}
          {activeTab === 'documents' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-500">
                Official employee identification, passport, QID scans, and employer contracts are saved securely in browser storage.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {/* Employee Passport Card */}
                <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
                  <div>
                    <span className="text-xs font-bold text-slate-900 block mb-1">
                      🛂 Employee Passport
                    </span>
                    <span className="text-[11px] text-slate-400 block">
                      {emp.passportData ? emp.passportData.name : 'No scan attached'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-100">
                    <label className="px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded cursor-pointer">
                      Upload
                      <input
                        type="file"
                        accept="image/*,.pdf"
                        onChange={(e) => handleDocumentUpload('passportData', e)}
                        className="hidden"
                      />
                    </label>
                    {emp.passportData && (
                      <>
                        <a
                          href={emp.passportData.data}
                          target="_blank"
                          rel="noreferrer"
                          className="px-2.5 py-1.5 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded"
                        >
                          View
                        </a>
                        <button
                          type="button"
                          onClick={() => handleDeleteDocument('passportData')}
                          className="p-1.5 text-slate-400 hover:text-rose-600 ml-auto"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {/* Employee QID Card */}
                <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
                  <div>
                    <span className="text-xs font-bold text-slate-900 block mb-1">
                      🪪 Qatar QID Residency Card
                    </span>
                    <span className="text-[11px] text-slate-400 block">
                      {emp.qidData ? emp.qidData.name : 'No scan attached'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-100">
                    <label className="px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded cursor-pointer">
                      Upload
                      <input
                        type="file"
                        accept="image/*,.pdf"
                        onChange={(e) => handleDocumentUpload('qidData', e)}
                        className="hidden"
                      />
                    </label>
                    {emp.qidData && (
                      <>
                        <a
                          href={emp.qidData.data}
                          target="_blank"
                          rel="noreferrer"
                          className="px-2.5 py-1.5 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded"
                        >
                          View
                        </a>
                        <button
                          type="button"
                          onClick={() => handleDeleteDocument('qidData')}
                          className="p-1.5 text-slate-400 hover:text-rose-600 ml-auto"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                  </div>
                </div>

                {/* Employer Contract Document */}
                <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between">
                  <div>
                    <span className="text-xs font-bold text-slate-900 block mb-1">
                      📄 Labor Contract / Official Permit
                    </span>
                    <span className="text-[11px] text-slate-400 block">
                      {emp.employerDocData ? emp.employerDocData.name : 'No file attached'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-100">
                    <label className="px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded cursor-pointer">
                      Upload
                      <input
                        type="file"
                        accept="image/*,.pdf,.doc,.docx"
                        onChange={(e) => handleDocumentUpload('employerDocData', e)}
                        className="hidden"
                      />
                    </label>
                    {emp.employerDocData && (
                      <>
                        <a
                          href={emp.employerDocData.data}
                          target="_blank"
                          rel="noreferrer"
                          className="px-2.5 py-1.5 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded"
                        >
                          View
                        </a>
                        <button
                          type="button"
                          onClick={() => handleDeleteDocument('employerDocData')}
                          className="p-1.5 text-slate-400 hover:text-rose-600 ml-auto"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal: Status Toggle (Move to Former or Reactivate) */}
      {showStatusModal && (
        <div className="fixed inset-0 bg-slate-950/80 z-60 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl p-5 max-w-md w-full space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              {emp.status === 'Unemployed'
                ? `Reactivate ${emp.employeeName}`
                : `Move ${emp.employeeName} to Former / Unemployed`}
            </h3>

            {emp.status === 'Unemployed' ? (
              <div className="space-y-3">
                <p className="text-xs text-slate-500">
                  This will restore {emp.employeeName} to the active employee directory with active payroll processing.
                </p>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Rejoining Date
                  </label>
                  <input
                    type="date"
                    value={rejoiningDate}
                    onChange={(e) => setRejoiningDate(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Updated Position (optional)
                  </label>
                  <input
                    type="text"
                    placeholder="Leave blank to maintain current position"
                    value={rejoiningPosition}
                    onChange={(e) => setRejoiningPosition(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-slate-500">
                  This moves the staff record to the Unemployed / Former archive. All past payrolls, certificates, and attendance data will be safely kept.
                </p>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Last Working Date
                  </label>
                  <input
                    type="date"
                    value={lastWorkingDate}
                    onChange={(e) => setLastWorkingDate(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Reason for Leaving
                  </label>
                  <select
                    value={reasonForLeaving}
                    onChange={(e) => setReasonForLeaving(e.target.value)}
                    className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg font-medium"
                  >
                    <option value="Resigned">Resigned</option>
                    <option value="Contract Completed">Contract Completed (2 Years)</option>
                    <option value="Terminated">Terminated</option>
                    <option value="Transferred Sponsorship">Transferred Sponsorship</option>
                    <option value="Medical Reasons">Medical / Personal Reasons</option>
                  </select>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowStatusModal(false)}
                className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmStatusToggle}
                className="px-4 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
              >
                Confirm Status Change
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add Monthly Payroll Sheet */}
      {showAddPayrollModal && (
        <div className="fixed inset-0 bg-slate-950/80 z-60 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl p-5 max-w-sm w-full space-y-4">
            <h3 className="text-sm font-bold text-slate-900">
              Create Payroll Sheet for {emp.employeeName}
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Month</label>
                <select
                  value={newPayMonth}
                  onChange={(e) => setNewPayMonth(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg"
                >
                  {[
                    'January',
                    'February',
                    'March',
                    'April',
                    'May',
                    'June',
                    'July',
                    'August',
                    'September',
                    'October',
                    'November',
                    'December',
                  ].map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Year</label>
                <input
                  type="number"
                  value={newPayYear}
                  onChange={(e) => setNewPayYear(e.target.value)}
                  className="w-full text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowAddPayrollModal(false)}
                className="px-3 py-1.5 text-xs text-slate-600 bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleAddMonthlyPayroll}
                className="px-4 py-1.5 text-xs font-bold text-white bg-blue-600 rounded-lg"
              >
                Generate Sheet
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
