import React, { useState, useMemo } from 'react';
import {
  CreditCard,
  Zap,
  CheckCheck,
  CheckCircle2,
  Trash2,
  Eye,
  Filter,
  DollarSign,
  AlertCircle,
  FileSpreadsheet,
} from 'lucide-react';
import { Employee, PayrollRecord, SystemSettings } from '../types';
import { db, formatCurrency, calculateEmployeeCommissions } from '../services/db';

interface MonthlyPayrollViewProps {
  employees: Employee[];
  payrolls: PayrollRecord[];
  settings: SystemSettings;
  onRefresh: () => void;
  onOpenEmployee: (empId: string) => void;
}

const MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export const MonthlyPayrollView: React.FC<MonthlyPayrollViewProps> = ({
  employees,
  payrolls,
  settings,
  onRefresh,
  onOpenEmployee,
}) => {
  const currentMonthName = MONTHS[new Date().getMonth()];
  const currentYearVal = new Date().getFullYear().toString();

  const [selectedMonth, setSelectedMonth] = useState(currentMonthName);
  const [selectedYear, setSelectedYear] = useState(currentYearVal);
  const [statusFilter, setStatusFilter] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Filtered payrolls
  const filteredPayrolls = useMemo(() => {
    return payrolls.filter((p) => {
      const matchMonth = selectedMonth ? p.month === selectedMonth : true;
      const matchYear = selectedYear ? p.year === selectedYear : true;
      const matchStatus = statusFilter ? p.status === statusFilter : true;
      return matchMonth && matchYear && matchStatus;
    });
  }, [payrolls, selectedMonth, selectedYear, statusFilter]);

  // Aggregate sums
  const stats = useMemo(() => {
    let net = 0;
    let paid = 0;
    let outstanding = 0;

    filteredPayrolls.forEach((p) => {
      const remaining = Number(p.netSalary) - Number(p.paidAmount);
      net += Number(p.netSalary) || 0;
      paid += Number(p.paidAmount) || 0;
      if (remaining > 0) outstanding += remaining;
    });

    return {
      totalCount: filteredPayrolls.length,
      net,
      paid,
      outstanding,
    };
  }, [filteredPayrolls]);

  // Checkbox toggle
  const toggleSelectAll = () => {
    if (selectedIds.length === filteredPayrolls.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredPayrolls.map((p) => p.id));
    }
  };

  const toggleSelectOne = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Generate Payroll for Month
  const handleGeneratePayroll = async () => {
    const activeEmps = employees.filter((e) => e.status !== 'Unemployed');
    if (activeEmps.length === 0) {
      alert('No active employees found to generate payroll for.');
      return;
    }

    if (
      !confirm(
        `⚡ Generate payroll records for ${activeEmps.length} active salon employees for ${selectedMonth} ${selectedYear}?\n\nExisting records will not be overwritten.`
      )
    ) {
      return;
    }

    let created = 0;
    let skipped = 0;

    for (const emp of activeEmps) {
      const payrollId = `PAY-${emp.employeeId}-${selectedYear}-${selectedMonth}`;
      const existing = payrolls.find((p) => p.id === payrollId);

      if (existing) {
        skipped++;
        continue;
      }

      const basic = Number(emp.basicSalary) || 0;
      const allowances =
        (Number(emp.foodAllowance) || 0) +
        (Number(emp.transportAllowance) || 0) +
        (Number(emp.carOperationAllowance) || 0) +
        (Number(emp.otherAllowance) || 0) +
        (Number(emp.limitedTransport) || 0);

      const comms = calculateEmployeeCommissions(emp, settings);
      const deductions = Number(emp.deductionCurrent) || 0;
      const netSalary = basic + allowances + comms.total - deductions;

      const record: PayrollRecord = {
        id: payrollId,
        employeeId: emp.employeeId,
        month: selectedMonth,
        year: selectedYear,
        basicSalary: basic,
        allowances,
        commissions: comms.total,
        deductions,
        netSalary,
        paidAmount: 0,
        status: 'Draft',
        paymentDate: '',
        notes: `Generated automatically for ${selectedMonth} ${selectedYear}`,
        commissionBreakdown: {
          service: comms.service,
          product: comms.product,
          business: comms.business,
        },
      };

      await db.savePayrollRecord(record);
      created++;
    }

    await db.logAudit(
      'PAYROLL_GENERATED',
      `Generated payroll for ${selectedMonth} ${selectedYear} (${created} created, ${skipped} skipped)`
    );
    alert(
      `✅ Monthly Payroll Generation Complete!\n\n• ${created} new payroll sheets created\n• ${skipped} existing records preserved`
    );
    onRefresh();
  };

  // Batch: Mark as Paid
  const handleBatchMarkPaid = async () => {
    if (selectedIds.length === 0) {
      alert('Please select at least one payroll record.');
      return;
    }

    if (!confirm(`Mark ${selectedIds.length} payroll record(s) as Paid in full?`)) return;

    for (const id of selectedIds) {
      const p = payrolls.find((item) => item.id === id);
      if (p) {
        await db.savePayrollRecord({
          ...p,
          status: 'Paid',
          paidAmount: p.netSalary,
          paymentDate: new Date().toISOString().slice(0, 10),
        });
      }
    }

    await db.logAudit('PAYROLL_BATCH_PAID', `Marked ${selectedIds.length} payroll records as Paid`);
    setSelectedIds([]);
    onRefresh();
  };

  // Batch: Mark as Approved
  const handleBatchMarkApproved = async () => {
    if (selectedIds.length === 0) {
      alert('Please select at least one payroll record.');
      return;
    }

    for (const id of selectedIds) {
      const p = payrolls.find((item) => item.id === id);
      if (p) {
        await db.savePayrollRecord({
          ...p,
          status: 'Approved',
        });
      }
    }

    await db.logAudit('PAYROLL_BATCH_APPROVED', `Marked ${selectedIds.length} payroll records as Approved`);
    setSelectedIds([]);
    onRefresh();
  };

  // Batch: Delete
  const handleBatchDelete = async () => {
    if (selectedIds.length === 0) {
      alert('Please select at least one payroll record.');
      return;
    }

    if (!confirm(`Delete ${selectedIds.length} selected payroll record(s)? This cannot be undone.`))
      return;

    for (const id of selectedIds) {
      await db.deletePayrollRecord(id);
    }

    setSelectedIds([]);
    onRefresh();
  };

  return (
    <div className="space-y-6">
      {/* Control Panel */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-blue-600" />
              <span>Monthly Payroll Processing &amp; Wages</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Select wage cycle, auto-calculate service &amp; product commissions, apply current deductions, and approve batch payments.
            </p>
          </div>

          <button
            onClick={handleGeneratePayroll}
            className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
          >
            <Zap className="w-4 h-4 fill-current" />
            <span>⚡ Generate {selectedMonth} {selectedYear} Payroll</span>
          </button>
        </div>

        {/* Filters and controls row */}
        <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-slate-100">
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Month</label>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg font-medium"
            >
              {MONTHS.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Year</label>
            <input
              type="number"
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="w-24 text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg font-mono font-medium"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Status Filter</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs p-2 bg-slate-50 border border-slate-200 rounded-lg font-medium"
            >
              <option value="">All Statuses</option>
              <option value="Draft">Draft</option>
              <option value="Approved">Approved</option>
              <option value="Paid">Paid</option>
              <option value="Partially Paid">Partially Paid</option>
              <option value="Cancelled">Cancelled</option>
            </select>
          </div>

          <div className="flex-1" />

          {/* Batch action buttons */}
          <div className="flex flex-wrap items-center gap-2 pt-4 sm:pt-0">
            <button
              onClick={handleBatchMarkPaid}
              disabled={selectedIds.length === 0}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg flex items-center gap-1 transition-colors ${
                selectedIds.length > 0
                  ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed'
              }`}
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>Mark as Paid ({selectedIds.length})</span>
            </button>

            <button
              onClick={handleBatchMarkApproved}
              disabled={selectedIds.length === 0}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg flex items-center gap-1 transition-colors ${
                selectedIds.length > 0
                  ? 'bg-blue-600 text-white hover:bg-blue-700'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Approve ({selectedIds.length})</span>
            </button>

            <button
              onClick={handleBatchDelete}
              disabled={selectedIds.length === 0}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg flex items-center gap-1 transition-colors ${
                selectedIds.length > 0
                  ? 'bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed'
              }`}
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete</span>
            </button>
          </div>
        </div>
      </div>

      {/* Stats KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Filtered Records
          </div>
          <div className="text-xl font-bold text-slate-900 tabular-nums">
            {stats.totalCount}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Total Net Wages
          </div>
          <div className="text-xl font-bold text-blue-600 tabular-nums">
            QAR {formatCurrency(stats.net)}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Total Paid Disbursed
          </div>
          <div className="text-xl font-bold text-emerald-600 tabular-nums">
            QAR {formatCurrency(stats.paid)}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
            Outstanding Due
          </div>
          <div className="text-xl font-bold text-rose-600 tabular-nums">
            QAR {formatCurrency(stats.outstanding)}
          </div>
        </div>
      </div>

      {/* Payroll Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto max-h-[600px] custom-scrollbar">
          <table className="w-full text-xs text-left border-collapse min-w-[1200px]">
            <thead className="bg-slate-50 text-slate-600 font-semibold sticky top-0 z-10 border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={
                      filteredPayrolls.length > 0 &&
                      selectedIds.length === filteredPayrolls.length
                    }
                    onChange={toggleSelectAll}
                    className="w-4 h-4 rounded text-blue-600 cursor-pointer"
                  />
                </th>
                <th className="py-2.5 px-3">Employee ID</th>
                <th className="py-2.5 px-3">Name</th>
                <th className="py-2.5 px-3">Month / Year</th>
                <th className="py-2.5 px-3 text-right">Basic</th>
                <th className="py-2.5 px-3 text-right">Allowances</th>
                <th className="py-2.5 px-3 text-right">Commissions</th>
                <th className="py-2.5 px-3 text-right text-rose-600">Deductions</th>
                <th className="py-2.5 px-3 text-right font-bold text-slate-900 bg-slate-100/60">
                  Net Payable
                </th>
                <th className="py-2.5 px-3 text-right text-emerald-600">Paid Amount</th>
                <th className="py-2.5 px-3 text-right">Remaining</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPayrolls.map((p) => {
                const emp = employees.find((e) => e.employeeId === p.employeeId);
                const remaining = Number(p.netSalary) - Number(p.paidAmount);
                const isSelected = selectedIds.includes(p.id);

                return (
                  <tr
                    key={p.id}
                    onClick={() => onOpenEmployee(p.employeeId)}
                    className={`hover:bg-blue-50/40 cursor-pointer transition-colors ${
                      isSelected ? 'bg-blue-50/60' : ''
                    }`}
                  >
                    <td
                      className="py-2.5 px-3 text-center"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelectOne(p.id)}
                        className="w-4 h-4 rounded text-blue-600 cursor-pointer"
                      />
                    </td>
                    <td className="py-2.5 px-3 font-bold font-mono text-slate-900">
                      {p.employeeId}
                    </td>
                    <td className="py-2.5 px-3 font-semibold text-slate-900">
                      {emp ? emp.employeeName : 'Unknown'}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 font-medium">
                      {p.month} {p.year}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums">
                      QAR {formatCurrency(p.basicSalary)}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums">
                      QAR {formatCurrency(p.allowances)}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-medium text-amber-700">
                      QAR {formatCurrency(p.commissions)}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-medium text-rose-600">
                      QAR {formatCurrency(p.deductions)}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-bold text-slate-900 bg-slate-100/60">
                      QAR {formatCurrency(p.netSalary)}
                    </td>
                    <td className="py-2.5 px-3 text-right tabular-nums font-semibold text-emerald-600">
                      QAR {formatCurrency(p.paidAmount)}
                    </td>
                    <td
                      className={`py-2.5 px-3 text-right tabular-nums font-semibold ${
                        remaining > 0 ? 'text-rose-600' : 'text-emerald-600'
                      }`}
                    >
                      QAR {formatCurrency(remaining)}
                    </td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                          p.status === 'Paid'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : p.status === 'Approved'
                            ? 'bg-blue-50 text-blue-700 border border-blue-200'
                            : p.status === 'Cancelled'
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {p.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onOpenEmployee(p.employeeId)}
                          className="px-2 py-1 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 rounded transition-colors"
                        >
                          Details
                        </button>
                        <button
                          onClick={async () => {
                            if (confirm(`Delete payroll sheet for ${p.employeeId} (${p.month} ${p.year})?`)) {
                              await db.deletePayrollRecord(p.id);
                              onRefresh();
                            }
                          }}
                          className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                          title="Delete payroll record"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {filteredPayrolls.length === 0 && (
            <div className="p-12 text-center text-slate-400">
              <AlertCircle className="w-8 h-8 mx-auto text-slate-300 mb-2" />
              <p className="text-sm font-medium">
                No payroll records found for {selectedMonth} {selectedYear}.
              </p>
              <p className="text-xs text-slate-400 mt-1">
                Click "⚡ Generate {selectedMonth} {selectedYear} Payroll" above to automatically create records for all active staff.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
