export interface FutureDeduction {
  id: string;
  date: string;
  amount: number;
  reason: string;
  status: 'Scheduled' | 'Applied' | 'Cancelled';
}

export interface DocumentAttachment {
  name: string;
  data: string; // base64 / data URL
  date: string;
}

export interface Employee {
  no: number | string;
  employerId: string;
  company: string;
  duty: string;
  accommodation: string;
  contractNo: string;
  employeeId: string;
  contractType: string;
  joiningDate: string;
  endContract: string;
  mph: string;
  expireMph: string;
  position: string;
  employeeName: string;
  nationality: string;
  mobile: string;
  whatsapp: string;
  email: string;
  passportNumber: string;
  passportExpiry: string;
  passportDays: string;
  residencyQid: string;
  residencyExpiry: string;
  residencyDays: string;
  payerBank: string;
  payerBankShort: string;
  iban: string;
  basicSalary: number;
  foodAllowance: number;
  transportAllowance: number;
  carOperationAllowance: number;
  otherAllowance: number;
  limitedTransport: number;
  totalSalary: number;
  saleCommissionRate: number;
  saleTargetRate: number;
  totalSalesRate: number;
  targetSales: number;
  prodSaleCommission: number;
  prodSaleTarget: number;
  prodTotalSales: number;
  businessTargetRate: number;
  businessGross: number;
  businessBonus: number;
  deductionCurrent: number;
  deductionFuture: number;
  futureDeductions: FutureDeduction[];
  tips: number;
  outstanding: number;
  leaveEntitlement: number;
  annualLeavePaid: string;
  salariesWages: number;
  totalCreditLeave: number;
  lastLeaveDate: string;
  annualLeaveDays: number;
  annualLeaveStatus: string;
  annualLeavePaidAmt: number;
  annualLeaveRemaining: number;
  annualLeaveFees: number;
  ticketCycle: number;
  nextTicketDate: string;
  ticketStatus: string;
  ticketDestination: string;
  confirm: string;
  signature: string;
  date: string;
  status: 'Active' | 'Unemployed' | 'On Leave';
  photoData?: string | null;
  imageData?: string | null;
  passportData?: DocumentAttachment | null;
  qidData?: DocumentAttachment | null;
  employerDocData?: DocumentAttachment | null;
  lastWorkingDate?: string;
  reasonForLeaving?: string;
  rejoiningDate?: string;
  weeklyOffDay?: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday' | string;
}

export interface PayrollRecord {
  id: string;
  employeeId: string;
  month: string;
  year: string;
  basicSalary: number;
  allowances: number;
  commissions: number;
  deductions: number;
  netSalary: number;
  paidAmount: number;
  status: 'Draft' | 'Approved' | 'Paid' | 'Cancelled' | 'Partially Paid';
  paymentDate: string;
  notes: string;
  commissionBreakdown: {
    service: number;
    product: number;
    business: number;
  };
}

export interface AttendanceRecord {
  attId: string;
  employeeId: string;
  employeeName: string;
  date: string;
  shiftType?: 'Split Shift' | 'Morning Shift' | 'Night Shift' | 'Single Shift';
  // Morning shift
  morningTimeIn?: string;
  morningTimeOut?: string;
  morningScheduledStart?: string;
  morningScheduledEnd?: string;
  morningWorkMinutes?: number;
  // Night shift
  nightTimeIn?: string;
  nightTimeOut?: string;
  nightScheduledStart?: string;
  nightScheduledEnd?: string;
  nightWorkMinutes?: number;
  // Single shift fallback
  scheduledStart: string;
  scheduledEnd: string;
  timeIn: string;
  timeOut: string;
  breakStart: string;
  breakEnd: string;
  // Aggregated day totals
  totalWorkMinutes: number;
  scheduledWorkMinutes: number;
  extraMinutes: number;
  shortMinutes?: number;
  status: 'Present' | 'Absent' | 'Late' | 'Half Day' | 'Leave' | 'Holiday' | 'Day Off';
  remarks: string;
  createdAt: string;
  createdBy: string;
}

export interface ExtraTimeTransaction {
  extraId: string;
  employeeId: string;
  date: string;
  type: 'Earned' | 'Used';
  minutes: number;
  reason: string;
  balanceAfter: number;
  approvedBy: string;
  createdAt: string;
}

export interface LeaveRecord {
  leaveId: string;
  employeeId: string;
  employeeName: string;
  startDate: string;
  endDate: string;
  days: number;
  leaveType: string;
  paidStatus: 'Paid' | 'Unpaid';
  status: 'Pending' | 'Approved' | 'Cancelled';
  period: string;
  remarks: string;
  requestedDate: string;
  approvedBy?: string | null;
  approvedDate?: string | null;
}

export interface FlightTicketRecord {
  ticketId: string;
  employeeId: string;
  employeeName: string;
  period: string;
  eligibleDate: string;
  bookedDate: string;
  destination: string;
  cost: number;
  status: 'Not Eligible' | 'Eligible' | 'Pending' | 'Approved' | 'Booked' | 'Used';
  createdAt: string;
}

export interface Certificate {
  certId: string;
  certType: 'salary' | 'employment';
  certTypeName: string;
  employeeId: string;
  employeeName: string;
  employeePosition: string;
  employeeQid: string;
  employeeNationality: string;
  employeeJoiningDate: string;
  recipient: string;
  correspondingDate: string;
  reference: string;
  signatoryName: string;
  signatoryTitle: string;
  salaryData: {
    basicSalary: number;
    foodAllowance: number;
    transportAllowance: number;
    carOperationAllowance: number;
    otherAllowance: number;
    totalSalary: number;
  };
  includeBasic: boolean;
  includeFood: boolean;
  includeTransport: boolean;
  includeCar: boolean;
  includeOther: boolean;
  createdAt: string;
  htmlContent?: string;
}

export interface BankInfo {
  name: string;
  short: string;
}

export interface SystemSettings {
  companyName: string;
  companyAddress: string;
  companyPhone: string;
  companyEmail: string;
  signatoryName: string;
  signatoryTitle: string;
  certValidity: number;
  certCounter: number;
  salesCommRate: number;
  productCommRate: number;
  businessTarget: number;
  businessCommRate: number;
  leaveEntitlement: number;
  leaveDivisor: number;
  ticketCycle: number;
  attOpening: string;
  attClosing: string;
  attBreakStart: string;
  attBreakEnd: string;
  attLateThreshold: number;
  attMorningStart: string;
  attMorningEnd: string;
  attNightStart: string;
  attNightEnd: string;
}

export interface AuditLogItem {
  id?: number;
  timestamp: string;
  action: string;
  details: string;
}
