import React, { useState, useEffect, useCallback } from 'react';
import {
  Employee,
  PayrollRecord,
  AttendanceRecord,
  LeaveRecord,
  FlightTicketRecord,
  ExtraTimeTransaction,
  Certificate,
  SystemSettings,
  BankInfo,
  AuditLogItem,
} from './types';
import { db, DEFAULT_SETTINGS, DEFAULT_QATAR_BANKS } from './services/db';
import { exportEmployeesToExcel } from './services/excel';

// Components
import { Sidebar, ViewType } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { DashboardView } from './components/DashboardView';
import { AddEmployeeView } from './components/AddEmployeeView';
import { ActiveEmployeesView } from './components/ActiveEmployeesView';
import { UnemployedView } from './components/UnemployedView';
import { MonthlyPayrollView } from './components/MonthlyPayrollView';
import { AttendanceView } from './components/AttendanceView';
import { LeaveManagementView } from './components/LeaveManagementView';
import { CertificateGeneratorView } from './components/CertificateGeneratorView';
import { CertificateArchiveView } from './components/CertificateArchiveView';
import { ExcelImportExportView } from './components/ExcelImportExportView';
import { BackupRestoreView } from './components/BackupRestoreView';
import { AuditLogView } from './components/AuditLogView';
import { SettingsView } from './components/SettingsView';
import { EmployeeDetailModal } from './components/EmployeeDetailModal';
import { PrintCertificateModal } from './components/PrintCertificateModal';

export default function App() {
  const [activeView, setActiveView] = useState<ViewType>('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Core Data States
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [payrolls, setPayrolls] = useState<PayrollRecord[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [leaves, setLeaves] = useState<LeaveRecord[]>([]);
  const [tickets, setTickets] = useState<FlightTicketRecord[]>([]);
  const [extraTime, setExtraTime] = useState<ExtraTimeTransaction[]>([]);
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [settings, setSettings] = useState<SystemSettings>(DEFAULT_SETTINGS);
  const [banks, setBanks] = useState<BankInfo[]>(DEFAULT_QATAR_BANKS);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);

  // Modals
  const [selectedEmpId, setSelectedEmpId] = useState<string | null>(null);
  const [activePrintCert, setActivePrintCert] = useState<Certificate | null>(null);

  // Refresh all state from DB
  const refreshAllData = useCallback(() => {
    setEmployees(db.getEmployees());
    setPayrolls(db.getPayrolls());
    setAttendance(db.getAttendance());
    setLeaves(db.getLeaves());
    setTickets(db.getTickets());
    setExtraTime(db.getExtraTimeTransactions());
    setCertificates(db.getCertificates());
    setSettings(db.getSettings());
    setBanks(db.getBanks());
    setAuditLogs(db.getAuditLogs());
  }, []);

  // Initialize DB on mount
  useEffect(() => {
    const initApp = async () => {
      await db.init();
      refreshAllData();
    };
    initApp();
  }, [refreshAllData]);

  // Counts for sidebar badges
  const activeCount = employees.filter((e) => e.status !== 'Unemployed').length;
  const unemployedCount = employees.filter((e) => e.status === 'Unemployed').length;

  // Handlers
  const handleLoadSample = async () => {
    if (confirm('Load/reset official Cosmos Beauty Salon sample employees?')) {
      await db.loadSampleData();
      refreshAllData();
      alert('✅ Sample employees and payroll data loaded successfully!');
    }
  };

  const handleExportAllExcel = () => {
    try {
      exportEmployeesToExcel(employees);
    } catch (err: unknown) {
      alert((err as Error).message);
    }
  };

  const handleToggleStatus = (empId: string) => {
    setSelectedEmpId(empId);
  };

  const handleReactivate = async (empId: string) => {
    const emp = employees.find((e) => e.employeeId === empId);
    if (!emp) return;

    if (confirm(`Reactivate ${emp.employeeName} back to Active Employees?`)) {
      await db.saveEmployee({
        ...emp,
        status: 'Active',
        rejoiningDate: new Date().toISOString().slice(0, 10),
        lastWorkingDate: undefined,
        reasonForLeaving: undefined,
      });
      refreshAllData();
      alert(`✅ ${emp.employeeName} is now active!`);
    }
  };

  const handleTriggerPrint = (cert: Certificate) => {
    setActivePrintCert(cert);
    setTimeout(() => {
      window.print();
    }, 250);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col lg:flex-row font-sans text-slate-800">
      {/* Sidebar Navigation */}
      <Sidebar
        activeView={activeView}
        onSelectView={(v) => {
          setActiveView(v);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        activeCount={activeCount}
        unemployedCount={unemployedCount}
        isOpenMobile={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 lg:ml-64 flex flex-col min-w-0 min-h-screen">
        <TopBar
          activeView={activeView}
          onOpenMobile={() => setIsMobileSidebarOpen(true)}
          onNavigate={(v) => setActiveView(v)}
          onLoadSample={handleLoadSample}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1600px] w-full mx-auto">
          {activeView === 'dashboard' && (
            <DashboardView
              employees={employees}
              onOpenEmployee={(id) => setSelectedEmpId(id)}
              onNavigateAdd={() => setActiveView('add-employee')}
              onLoadSample={handleLoadSample}
              onExportExcel={handleExportAllExcel}
            />
          )}

          {activeView === 'add-employee' && (
            <AddEmployeeView
              banks={banks}
              onBack={() => setActiveView('dashboard')}
              onSaved={() => {
                refreshAllData();
                setActiveView('dashboard');
              }}
            />
          )}

          {activeView === 'active-employees' && (
            <ActiveEmployeesView
              employees={employees}
              onOpenEmployee={(id) => setSelectedEmpId(id)}
              onNavigateAdd={() => setActiveView('add-employee')}
              onToggleStatus={handleToggleStatus}
            />
          )}

          {activeView === 'unemployed' && (
            <UnemployedView
              employees={employees}
              onOpenEmployee={(id) => setSelectedEmpId(id)}
              onReactivate={handleReactivate}
            />
          )}

          {activeView === 'monthly-payroll' && (
            <MonthlyPayrollView
              employees={employees}
              payrolls={payrolls}
              settings={settings}
              onRefresh={refreshAllData}
              onOpenEmployee={(id) => setSelectedEmpId(id)}
            />
          )}

          {activeView === 'attendance' && (
            <AttendanceView
              employees={employees}
              attendance={attendance}
              settings={settings}
              onRefresh={refreshAllData}
            />
          )}

          {activeView === 'leave-management' && (
            <LeaveManagementView
              employees={employees}
              leaves={leaves}
              tickets={tickets}
              onRefresh={refreshAllData}
              onOpenEmployee={(id) => setSelectedEmpId(id)}
            />
          )}

          {activeView === 'certificate-generator' && (
            <CertificateGeneratorView
              employees={employees}
              settings={settings}
              onRefresh={refreshAllData}
              onNavigateArchive={() => setActiveView('certificate-archive')}
              onTriggerPrint={handleTriggerPrint}
            />
          )}

          {activeView === 'certificate-archive' && (
            <CertificateArchiveView
              certificates={certificates}
              onRefresh={refreshAllData}
              onReprint={handleTriggerPrint}
            />
          )}

          {activeView === 'import-export' && (
            <ExcelImportExportView
              employees={employees}
              onRefresh={refreshAllData}
            />
          )}

          {activeView === 'backup-restore' && (
            <BackupRestoreView onRefresh={refreshAllData} />
          )}

          {activeView === 'audit-log' && <AuditLogView logs={auditLogs} />}

          {activeView === 'settings' && (
            <SettingsView
              settings={settings}
              banks={banks}
              onRefresh={refreshAllData}
            />
          )}
        </main>
      </div>

      {/* Employee Detail Modal */}
      {selectedEmpId && (
        <EmployeeDetailModal
          employeeId={selectedEmpId}
          banks={banks}
          settings={settings}
          payrolls={payrolls}
          attendance={attendance}
          leaves={leaves}
          tickets={tickets}
          extraTime={extraTime}
          onClose={() => setSelectedEmpId(null)}
          onRefresh={refreshAllData}
        />
      )}

      {/* Print Certificate Modal & Dedicated Container */}
      {activePrintCert && (
        <PrintCertificateModal
          certificate={activePrintCert}
          settings={settings}
          onClose={() => setActivePrintCert(null)}
        />
      )}
    </div>
  );
}
